(globalThis.webpackChunkwebapp=globalThis.webpackChunkwebapp||[]).push([["gantry-v2-vendors-async-client","gantry-v2-vendors-async-app-popouts","gantry-v2-vendors-async-single-channel-client","vendors-node_modules_qrcode_lib_browser_js-_d0550","vendors-node_modules_mcp-ui_client_dist_index_mjs-node_modules_framer-motion_dist_es_animatio-37cdd0","vendors-node_modules_framer-motion_dist_es_animation_hooks_use-animate_mjs-node_modules_frame-16416c","vendors-node_modules_qrcode_lib_browser_js-node_modules_tinyspeck_slack-desktop-types_constan-8799a6","vendors-node_modules_qrcode_lib_browser_js-_d0551","vendors-node_modules_qrcode_lib_browser_js-_d0552","vendors-node_modules_qrcode_lib_browser_js-_d0553","vendors-node_modules_qrcode_lib_browser_js-_d0554","vendors-node_modules_framer-motion_dist_es_animation_hooks_use-animate_mjs"],{0x225316c11:(r,i,d)=>{"use strict";d.d(i,{eo:()=>Ut});var p,_,w,E,C,I,R,k,F,P,M,N,D,V,z,j,$,G,q=d(0x1d3a4ced9),H=d(0xbad225b5),Y=Object.defineProperty,pe=r=>{throw TypeError(r)},L=(r,i,d)=>{let p;return(p="symbol"!=typeof i?i+"":i)in r?Y(r,p,{enumerable:!0,configurable:!0,writable:!0,value:d}):r[p]=d},oe=(r,i,d)=>i.has(r)||pe("Cannot "+d),b=(r,i,d)=>(oe(r,i,"read from private field"),d?d.call(r):i.get(r)),S=(r,i,d)=>i.has(r)?pe("Cannot add the same private member more than once"):i instanceof WeakSet?i.add(r):i.set(r,d),Z=(r,i,d,p)=>(oe(r,i,"write to private field"),p?p.call(r,d):i.set(r,d),d),y=(r,i,d)=>(oe(r,i,"access private method"),d);let K="mcpui.dev/ui-";function Qe(r){let i;try{i=new URL(r)}catch(r){return console.error("Error parsing URL:",r),!1}return"http:"===i.protocol||"https:"===i.protocol}function et(r,i){if("text/html"!==r.mimeType&&"text/uri-list"!==r.mimeType)return{error:"Resource must be of type text/html (for HTML content) or text/uri-list (for URL content)."};if("text/uri-list"===r.mimeType){let d="";if("string"==typeof r.text&&""!==r.text.trim())d=r.text;else if("string"!=typeof r.blob)return{error:"URL resource expects a non-empty text or blob field containing the URL."};else try{d=new TextDecoder().decode(Uint8Array.from(atob(r.blob),r=>r.charCodeAt(0)))}catch(r){return console.error("Error decoding base64 blob for URL content:",r),{error:"Error decoding URL from blob."}}if(""===d.trim())return{error:"URL content is empty."};let p=d.split(`
`).map(r=>r.trim()).filter(r=>r&&!r.startsWith("#")&&Qe(r));if(0===p.length)return{error:"No valid URLs found in uri-list content."};p.length>1&&console.warn(`Multiple URLs found in uri-list content. Using the first URL: "${p[0]}". Other URLs ignored:`,p.slice(1));let _=p[0];if(i&&""!==i.trim())try{let r=new URL(i);if(!("u">typeof window)||r.host!==window.location.host)return r.searchParams.set("url",_),{iframeSrc:r.toString(),iframeRenderMode:"src"};console.error("For security, the proxy origin must not be the same as the host origin. Using original URL instead.")}catch(r){console.error(`Invalid proxy URL provided: "${i}". Falling back to direct URL.`,r instanceof Error?r.message:String(r))}return{iframeSrc:_,iframeRenderMode:"src"}}if("text/html"!==r.mimeType)return{error:"Unsupported mimeType. Expected text/html or text/uri-list."};{let d="";if("string"==typeof r.text)d=r.text;else if("string"!=typeof r.blob)return{error:"HTML resource requires text or blob content."};else try{d=new TextDecoder().decode(Uint8Array.from(atob(r.blob),r=>r.charCodeAt(0)))}catch(r){return console.error("Error decoding base64 blob for HTML content:",r),{error:"Error decoding HTML content from blob."}}if(i&&""!==i.trim())try{let r=new URL(i);if(!("u">typeof window)||r.host!==window.location.host)return r.searchParams.set("contentType","rawhtml"),{iframeSrc:r.toString(),iframeRenderMode:"src",htmlString:d};console.error("For security, the proxy origin must not be the same as the host origin. Using srcDoc rendering instead.")}catch(r){console.error(`Invalid proxy URL provided: "${i}". Falling back to srcDoc rendering.`,r instanceof Error?r.message:String(r))}return{htmlString:d,iframeRenderMode:"srcDoc"}}}function tt(r){if("string"==typeof r.text&&""!==r.text.trim())return{code:r.text};if("string"==typeof r.blob)try{return{code:new TextDecoder().decode(Uint8Array.from(atob(r.blob),r=>r.charCodeAt(0)))}}catch(r){return console.error("Error decoding base64 blob for remote DOM content:",r),{error:"Error decoding remote DOM content from blob."}}return{error:"Remote DOM resource requires non-empty text or blob content."}}function rt(r){return r._meta??{}}function nt(r){let i=rt(r),d={};return Object.entries(i).forEach(([r,i])=>{r.startsWith(K)&&(d[r.slice(K.length)]=i)}),d}let X="ui-message-response",Q="ui-lifecycle-iframe-render-data",Ne=({resource:r,onUIAction:i,style:d,proxy:p,iframeRenderData:_,autoResizeIframe:w,sandboxPermissions:E,iframeProps:C})=>{let I=(0,H.useRef)(null);(0,H.useImperativeHandle)(null==C?void 0:C.ref,()=>I.current);let{error:R,iframeSrc:k,iframeRenderMode:F,htmlString:P}=(0,H.useMemo)(()=>et(r,p),[r,p]),M=(0,H.useMemo)(()=>nt(r),[r]),N=M["preferred-frame-size"]??["100%","100%"],D=M["initial-render-data"]??void 0,V=(0,H.useMemo)(()=>{if(!(!_&&!D))return{...D,..._}},[_,D]),z=(0,H.useMemo)(()=>{if(k&&V){let r=new URL(k);return r.searchParams.set("waitForRenderData","true"),r.toString()}return k},[k,V]),j=(0,H.useCallback)(r=>{var i;V&&U(Q,r.currentTarget.contentWindow,z?new URL(z).origin:"*",void 0,{renderData:V}),null==(i=null==C?void 0:C.onLoad)||i.call(C,r)},[V,z,null==C?void 0:C.onLoad]),$=(0,H.useMemo)(()=>"srcDoc"===F?_e(E??"","allow-scripts"):_e(E??"","allow-scripts allow-same-origin"),[E,F]);return(0,H.useEffect)(()=>{async function T(r){let{source:d,origin:p,data:_}=r;if(I.current&&d===I.current.contentWindow){if((null==_?void 0:_.type)==="ui-proxy-iframe-ready"){"src"===F&&P&&null!=z&&z.includes("contentType=rawhtml")&&U("ui-html-content",d,p,void 0,{html:P,sandbox:$});return}if((null==_?void 0:_.type)==="ui-lifecycle-iframe-ready"){V&&U(Q,d,p,void 0,{renderData:V});return}if((null==_?void 0:_.type)==="ui-request-render-data")return void U(Q,d,p,_.messageId,{renderData:V});if((null==_?void 0:_.type)==="ui-size-change"){let{width:r,height:i}=_.payload;if(w&&I.current){let d=("boolean"==typeof w||w.height)&&i,p=("boolean"==typeof w||w.width)&&r;d&&(I.current.style.height=`${i}px`),p&&(I.current.style.width=`${r}px`)}return}if(!_)return;if(i){let r=_.messageId;U("ui-message-received",d,p,r);try{let w=await i(_);U(X,d,p,r,{response:w})}catch(i){console.error("Error handling UI action result in HTMLResourceRenderer:",i),U(X,d,p,r,{error:i})}}}}return window.addEventListener("message",T),()=>window.removeEventListener("message",T)},[i,V,F,P,z,$]),R?(0,q.jsx)("p",{className:"text-red-500",children:R}):"srcDoc"===F?null==P?R?null:(0,q.jsx)("p",{className:"text-orange-500",children:"No HTML content to display."}):(0,q.jsx)("iframe",{srcDoc:P,sandbox:$,style:{width:N[0],height:N[1],...d},title:"MCP HTML Resource (Embedded Content)",...C,ref:I,onLoad:j}):"src"===F?null==z?R?null:(0,q.jsx)("p",{className:"text-orange-500",children:"No URL provided for HTML resource."}):(0,q.jsx)("iframe",{src:z,sandbox:$,style:{width:N[0],height:N[1],...d},title:"MCP HTML Resource (URL)",...C,ref:I,onLoad:j}):(0,q.jsx)("p",{className:"text-gray-500",children:"Initializing HTML resource display..."})};function U(r,i,d,p,_){null==i||i.postMessage({type:r,messageId:p??void 0,payload:_},d&&"null"!==d?d:"*")}function _e(r,i){return[...new Set([...r.split(" "),...i.split(" ")])].filter(Boolean).map(r=>r.trim()).join(" ")}Ne.displayName="HTMLResourceRenderer";let ee=1;function De({call:r,insertChild:i,removeChild:d,updateText:p,updateProperty:_}){let w={0:i,1:d,2:p,3:_};return{call:r,mutate(r){for(let[i,...d]of r)w[i](...d)}}}let dt=class dt{constructor({retain:r,release:i,methods:d}={}){L(this,"root",{id:"~",type:9,children:[],version:0,properties:{},attributes:{},eventListeners:{}}),L(this,"attached",new Map([["~",this.root]])),L(this,"subscribers",new Map),L(this,"parents",new Map),L(this,"implementations",new Map);const{attached:p,parents:_,subscribers:w}=this;function u(r){let i=w.get(r.id);if(i)for(let d of i)d(r)}function l(i,d){let w;switch(i.type){case 3:case 8:{let{id:r,type:d,data:p}=i;w={id:r,type:d,data:p,version:0};break}case 1:{let{id:d,type:p,element:_,children:E,properties:C,attributes:I,eventListeners:R}=i;null==r||r(C),null==r||r(R);let k=[];for(let r of(w={id:d,type:p,element:_,version:0,children:k,properties:{...C},attributes:{...I},eventListeners:{...R}},E))k.push(l(r,w));break}default:throw Error(`Unknown node type: ${JSON.stringify(i)}`)}return p.set(w.id,w),_.set(w.id,d.id),w}function f(r){if(p.delete(r.id),_.delete(r.id),i&&("properties"in r&&i(r.properties),"eventListeners"in r&&i(r.eventListeners)),"children"in r)for(let i of r.children)f(i)}this.connection=De({call:(r,i,...d)=>{let p=this.implementations.get(r),_=null==p?void 0:p[i];if("function"!=typeof _)throw Error(`Node ${r} does not implement the ${i}() method`);return _(...d)},insertChild:(r,i,d)=>{let _=p.get(r),{children:w}=_,E=l(i,_);d===w.length?w.push(E):w.splice(d,0,E),_.version+=1,this.parents.set(i.id,_.id),u(_)},removeChild:(r,i)=>{let d=p.get(r),{children:_}=d,[w]=_.splice(i,1);w&&(d.version+=1,u(d),f(w))},updateProperty:(d,_,w,E=ee)=>{let C,I,R=p.get(d);switch(null==r||r(w),E){case ee:C=R.properties;break;case 2:C=R.attributes;break;case 3:C=R.eventListeners}let k=C[_];if(C[_]=w,R.version+=1,"slot"===_){let r=this.parents.get(d);(I=null==r?r:p.get(r))&&(I.version+=1)}u(R),I&&u(I),null==i||i(k)},updateText:(r,i)=>{let d=p.get(r);d.data=i,d.version+=1,u(d)}}),d&&this.implement(this.root,d)}get({id:r}){return this.attached.get(r)}implement({id:r},i){null==i?this.implementations.delete(r):this.implementations.set(r,i)}subscribe({id:r},i,{signal:d}={}){let p=this.subscribers.get(r);null==p&&(p=new Set,this.subscribers.set(r,p)),p.add(i),null==d||d.addEventListener("abort",()=>{p.delete(i),0===p.size&&this.subscribers.delete(r)})}};let er=new WeakMap,ea=new WeakMap,en=new WeakMap;let ut=class ut{constructor({root:r,retain:i,release:d,call:p,cache:_}={}){L(this,"attached",new Map),this.root=r??document.createDocumentFragment();const{attached:w}=this,E=new Map;function l(r){let d,p=w.get(r.id);if(p)return p;switch(r.type){case 1:if(d=document.createElement(r.element),r.properties)for(let p of(ea.set(d,r.properties),Object.keys(r.properties))){let _=r.properties[p];null==i||i(_),J(d,p,_,ee)}else ea.set(d,{});if(r.attributes)for(let p of Object.keys(r.attributes)){let _=r.attributes[p];null==i||i(_),J(d,p,_,2)}if(en.set(d,{}),r.eventListeners)for(let p of Object.keys(r.eventListeners)){let _=r.eventListeners[p];null==i||i(_),J(d,p,_,3)}for(let i of r.children)d.appendChild(l(i));break;case 3:d=document.createTextNode(r.data);break;case 8:d=document.createComment(r.data);break;default:throw Error(`Unknown node type: ${JSON.stringify(r)}`)}return er.set(d,r.id),w.set(r.id,d),d}function f(r){let i=er.get(r);i&&w.delete(i);let p=ea.get(r);if(p&&d&&d(p),r instanceof Element)for(let i of r.childNodes)f(i)}this.connection=De({call:(r,i,...d)=>{let _="~"===r&&11!==this.root.nodeType?this.root:w.get(r);return p?p(_,i,...d):_[i](...d)},insertChild:(r,i,d)=>{let p="~"===r?this.root:w.get(r),_=E.get(r);_&&clearTimeout(_),p.insertBefore(l(i),p.childNodes[d]||null)},removeChild:(r,i)=>{let d=("~"===r?this.root:w.get(r)).childNodes[i];if(d.remove(),null!=_&&_.maxAge){let i=E.get(r);i&&clearTimeout(i);let p=setTimeout(()=>{f(d)},_.maxAge);E.set(r,p)}else f(d)},updateProperty:(r,p,_,E=ee)=>{let C=w.get(r);null==i||i(_);let I=ea.get(C),R=I[p];I[p]=_,J(C,p,_,E),null==d||d(R)},updateText:(r,i)=>{w.get(r).data=i}})}connect(r){let i=this.root;this.root=r,i.childNodes.forEach(i=>{r.appendChild(i)})}disconnect(){if(11===this.root.nodeType)return this.root;let r=this.root,i=new DocumentFragment;return this.root=i,r.childNodes.forEach(r=>{i.appendChild(r)}),i}};function J(r,i,d,p){switch(p){case ee:r[i]=d;break;case 2:null==d?r.removeAttribute(i):r.setAttribute(i,d);break;case 3:{let p=en.get(r),_=null==p?void 0:p[i];if(_&&r.removeEventListener(i,_),null!=d){let a=i=>{var p;if(i.target!==r)return;let _=d(i.detail);null==(p=i.resolve)||p.call(i,_)};p&&(p[i]=a),r.addEventListener(i,a)}}}}function me(r,i){let[d,p]=(0,H.useState)(()=>{let d=i.get(r);return{id:r.id,version:null==d?void 0:d.version,value:d,receiver:i}}),_=d.value;if(d.receiver!==i||d.id!==r.id){let d=i.get(r);_=d,p({receiver:i,id:r.id,version:null==d?void 0:d.version,value:_})}return(0,H.useDebugValue)(_),(0,H.useEffect)(()=>{let d=new AbortController,a=()=>{d.signal.aborted||p(d=>{let{id:p,version:_,receiver:w}=d,{id:E}=r;if(w!==i||p!==E)return d;let C=i.get(r),I=null==C?void 0:C.version;return _===I?d:{receiver:i,value:C,id:E,version:I}})};return i.subscribe(r,a,{signal:d.signal}),a(),()=>{d.abort()}},[i,r.id]),_}function mt({remote:r,receiver:i}){let d=me(r,i);return d?(0,q.jsx)(q.Fragment,{children:d.data}):null}function se(r,{receiver:i,components:d}){switch(r.type){case 1:{let p=d.get(r.element);if(null==p)throw Error(`No component found for remote element: ${r.element}`);return(0,q.jsx)(p,{element:r,receiver:i,components:d},r.id)}case 3:return(0,q.jsx)(mt,{remote:r,receiver:i},r.id);case 8:return null;default:throw Error(`Unknown remote node type: ${String(r)}`)}}function pt(r,i){if(!r)return;let{children:d,properties:p,attributes:_,eventListeners:w}=r,E=[],C={...p,..._,children:E};if(i.eventProps)for(let[r,d]of Object.entries(i.eventProps)){let i=null==d?void 0:d.event;if(null==i)continue;let p=w[i];p&&(C[r]=be(p))}else for(let[r,i]of Object.entries(w))C[`on${r[0].toUpperCase()}${r.slice(1)}`]=be(i);for(let r of d)if(1===r.type&&"string"==typeof r.attributes.slot){let d=r.attributes.slot,p=se(r,i);C[d]=C[d]?(0,q.jsxs)(q.Fragment,{children:[C[d],p]}):p}else E.push(se(r,i));return C}function be(r){return function(...i){if(1===i.length&&i[0]instanceof Event){let d=i[0];return d.target!==d.currentTarget?void 0:"detail"in d?r(d.detail):r()}return r(...i)}}let ei=Symbol.for("remote-dom.element"),es=Symbol.for("remote-dom.element.attached");function _t(r,{name:i,eventProps:d}={}){let p=(0,H.memo)(function({element:i,receiver:p,components:_}){let w=(0,H.useRef)(),E=me(i,p),C=E??i,I=C.id,R=pt(C,{receiver:p,components:_,eventProps:d});if(R[ei]=C,R[es]=null!=E,null==w.current){let r={id:I,receiver:p};r.instanceRef=Et(r),w.current=r}return w.current.id=I,w.current.receiver=p,(0,H.useEffect)(()=>{var r;let i={id:I};return p.implement(i,null==(r=w.current)?void 0:r.instanceRef.current),()=>{p.implement(i,null)}},[I,p]),(0,q.jsx)(r,{ref:w.current.instanceRef,...R})});return p.displayName=i??`RemoteComponentRenderer(${r.displayName??r.name??"Component"})`,p}function Et(r){let i=null;return{get current(){return i},set current(t){i=t,r.receiver.implement(r,t)}}}function bt(r){let{receiver:i}=r,{children:d}=me(i.root,i);return(0,q.jsx)(q.Fragment,{children:d.map(i=>se(i,r))})}let eo=`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
</head>
<body>
  <div id="root"></div>
  <script>
"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __typeError = (msg) => {
    throw TypeError(msg);
  };
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
  var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
  var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
  var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
  var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);

  // ../../../node_modules/.pnpm/@remote-dom+core@1.8.1_@preact+signals-core@1.10.0/node_modules/@remote-dom/core/build/esm/elements/RemoteEvent.mjs
  var RemoteEvent = class extends CustomEvent {
    /**
     * The last value received from a \`respondWith()\` call.
     */
    /**
     * Provides the \`response\` value to be sent as the return value for
     * the remote property function that triggered this event.
     */
    respondWith(response) {
      this.response = response;
    }
  };

  // ../../../node_modules/.pnpm/@remote-dom+core@1.8.1_@preact+signals-core@1.10.0/node_modules/@remote-dom/core/build/esm/constants.mjs
  var MUTATION_TYPE_INSERT_CHILD = 0;
  var MUTATION_TYPE_REMOVE_CHILD = 1;
  var MUTATION_TYPE_UPDATE_TEXT = 2;
  var MUTATION_TYPE_UPDATE_PROPERTY = 3;
  var UPDATE_PROPERTY_TYPE_PROPERTY = 1;
  var UPDATE_PROPERTY_TYPE_ATTRIBUTE = 2;
  var UPDATE_PROPERTY_TYPE_EVENT_LISTENER = 3;
  var ROOT_ID = "~";

  // ../../../node_modules/.pnpm/@remote-dom+core@1.8.1_@preact+signals-core@1.10.0/node_modules/@remote-dom/core/build/esm/elements/internals.mjs
  var REMOTE_CONNECTIONS = /* @__PURE__ */ new WeakMap();
  var REMOTE_IDS = /* @__PURE__ */ new WeakMap();
  var id = 0;
  function remoteId(node) {
    let remoteID = REMOTE_IDS.get(node);
    if (remoteID == null) {
      remoteID = String(id++);
      REMOTE_IDS.set(node, remoteID);
    }
    return remoteID;
  }
  var REMOTE_PROPERTIES = /* @__PURE__ */ new WeakMap();
  function remoteProperties(node) {
    return REMOTE_PROPERTIES.get(node);
  }
  var REMOTE_ATTRIBUTES = /* @__PURE__ */ new WeakMap();
  function remoteAttributes(node) {
    let attributes = REMOTE_ATTRIBUTES.get(node);
    if (attributes != null) return attributes;
    if (!(node instanceof Element) || node.tagName.includes("-")) return void 0;
    attributes = {};
    for (const {
      name,
      value
    } of node.attributes) {
      attributes[name] = value;
    }
    return attributes;
  }
  var REMOTE_EVENT_LISTENERS = /* @__PURE__ */ new WeakMap();
  function remoteEventListeners(node) {
    return REMOTE_EVENT_LISTENERS.get(node);
  }
  function updateRemoteElementProperty(node, property, value) {
    let properties = REMOTE_PROPERTIES.get(node);
    if (properties == null) {
      properties = {};
      REMOTE_PROPERTIES.set(node, properties);
    }
    if (properties[property] === value) return;
    properties[property] = value;
    const connection = REMOTE_CONNECTIONS.get(node);
    if (connection == null) return;
    connection.mutate([[MUTATION_TYPE_UPDATE_PROPERTY, remoteId(node), property, value, UPDATE_PROPERTY_TYPE_PROPERTY]]);
  }
  function updateRemoteElementAttribute(node, attribute, value) {
    let attributes = REMOTE_ATTRIBUTES.get(node);
    if (attributes == null) {
      attributes = {};
      REMOTE_ATTRIBUTES.set(node, attributes);
    }
    if (attributes[attribute] === value) return;
    if (value == null) {
      delete attributes[attribute];
    } else {
      attributes[attribute] = String(value);
    }
    const connection = REMOTE_CONNECTIONS.get(node);
    if (connection == null) return;
    connection.mutate([[MUTATION_TYPE_UPDATE_PROPERTY, remoteId(node), attribute, value, UPDATE_PROPERTY_TYPE_ATTRIBUTE]]);
  }
  function updateRemoteElementEventListener(node, event, listener) {
    let eventListeners = REMOTE_EVENT_LISTENERS.get(node);
    if (eventListeners == null) {
      eventListeners = {};
      REMOTE_EVENT_LISTENERS.set(node, eventListeners);
    }
    if (eventListeners[event] === listener) return;
    if (listener == null) {
      delete eventListeners[event];
    } else {
      eventListeners[event] = listener;
    }
    const connection = REMOTE_CONNECTIONS.get(node);
    if (connection == null) return;
    connection.mutate([[MUTATION_TYPE_UPDATE_PROPERTY, remoteId(node), event, listener, UPDATE_PROPERTY_TYPE_EVENT_LISTENER]]);
  }
  function connectRemoteNode(node, connection) {
    const existingConnection = REMOTE_CONNECTIONS.get(node);
    if (existingConnection === connection) return;
    REMOTE_CONNECTIONS.set(node, connection);
    if (node.childNodes) {
      for (let i = 0; i < node.childNodes.length; i++) {
        connectRemoteNode(node.childNodes[i], connection);
      }
    }
  }
  function disconnectRemoteNode(node) {
    const existingConnection = REMOTE_CONNECTIONS.get(node);
    if (existingConnection == null) return;
    REMOTE_CONNECTIONS.delete(node);
    if (node.childNodes) {
      for (let i = 0; i < node.childNodes.length; i++) {
        disconnectRemoteNode(node.childNodes[i]);
      }
    }
  }
  function serializeRemoteNode(node) {
    const {
      nodeType
    } = node;
    switch (nodeType) {
      // Element
      case 1: {
        return {
          id: remoteId(node),
          type: nodeType,
          element: node.localName,
          properties: cloneMaybeObject(remoteProperties(node)),
          attributes: cloneMaybeObject(remoteAttributes(node)),
          eventListeners: cloneMaybeObject(remoteEventListeners(node)),
          children: Array.from(node.childNodes).map(serializeRemoteNode)
        };
      }
      // TextNode
      case 3:
      // Comment
      // eslint-disable-next-line no-fallthrough
      case 8: {
        return {
          id: remoteId(node),
          type: nodeType,
          data: node.data
        };
      }
      default: {
        throw new Error(\`Cannot serialize node of type \${node.nodeType} (\${typeof node.nodeType})\`);
      }
    }
  }
  function cloneMaybeObject(maybeObject) {
    return maybeObject ? {
      ...maybeObject
    } : void 0;
  }
  function callRemoteElementMethod(node, method, ...args) {
    const id2 = REMOTE_IDS.get(node);
    const connection = REMOTE_CONNECTIONS.get(node);
    if (id2 == null || connection == null) {
      throw new Error(\`Cannot call method \${method} on an unconnected node\`);
    }
    return connection.call(id2, method, ...args);
  }

  // ../../../node_modules/.pnpm/@remote-dom+core@1.8.1_@preact+signals-core@1.10.0/node_modules/@remote-dom/core/build/esm/elements/RemoteElement.mjs
  var EMPTY_DEFINITION = Object.freeze({});
  var RemoteElement = class extends HTMLElement {
    static get observedAttributes() {
      return this.finalize().__observedAttributes;
    }
    /**
     * The resolved property definitions for this remote element.
     */
    static get remotePropertyDefinitions() {
      return this.finalize().__remotePropertyDefinitions;
    }
    /**
     * The resolved attribute definitions for this remote element.
     */
    static get remoteAttributeDefinitions() {
      return this.finalize().__remoteAttributeDefinitions;
    }
    /**
     * The resolved event listener definitions for this remote element.
     */
    static get remoteEventDefinitions() {
      return this.finalize().__remoteEventDefinitions;
    }
    /**
     * The resolved slot definitions for this remote element.
     */
    static get remoteSlotDefinitions() {
      return this.finalize().__remoteSlotDefinitions;
    }
    /**
     * Creates a new definition for a property that will be synchronized between
     * this remote element and its host representation.
     */
    static createProperty(name, definition) {
      saveRemoteProperty(name, definition, this.observedAttributes, this.remotePropertyDefinitions, this.__attributeToPropertyMap, this.__eventToPropertyMap);
    }
    /**
     * Consumes all the static members defined on the class and converts them
     * into the internal representation used to handle properties, attributes,
     * and event listeners.
     */
    static finalize() {
      if (this.hasOwnProperty("__finalized")) {
        return this;
      }
      this.__finalized = true;
      const {
        slottable,
        remoteSlots,
        remoteProperties: remoteProperties2,
        remoteAttributes: remoteAttributes2,
        remoteEvents,
        remoteMethods
      } = this;
      const SuperConstructor = Object.getPrototypeOf(this);
      const observedAttributes = /* @__PURE__ */ new Set();
      if (slottable) observedAttributes.add("slot");
      const attributeToPropertyMap = /* @__PURE__ */ new Map();
      const eventToPropertyMap = /* @__PURE__ */ new Map();
      const remoteSlotDefinitions = /* @__PURE__ */ new Map();
      const remotePropertyDefinitions = /* @__PURE__ */ new Map();
      const remoteAttributeDefinitions = /* @__PURE__ */ new Map();
      const remoteEventDefinitions = /* @__PURE__ */ new Map();
      if (typeof SuperConstructor.finalize === "function") {
        SuperConstructor.finalize();
        SuperConstructor.observedAttributes.forEach((attribute) => {
          observedAttributes.add(attribute);
        });
        SuperConstructor.remotePropertyDefinitions.forEach((definition, property) => {
          remotePropertyDefinitions.set(property, definition);
        });
        SuperConstructor.remoteAttributeDefinitions.forEach((definition, event) => {
          remoteAttributeDefinitions.set(event, definition);
        });
        SuperConstructor.remoteEventDefinitions.forEach((definition, event) => {
          remoteEventDefinitions.set(event, definition);
        });
        SuperConstructor.remoteSlotDefinitions.forEach((definition, slot) => {
          remoteSlotDefinitions.set(slot, definition);
        });
      }
      if (remoteSlots != null) {
        const slotNames = Array.isArray(remoteSlots) ? remoteSlots : Object.keys(remoteSlots);
        slotNames.forEach((slotName) => {
          remoteSlotDefinitions.set(slotName, EMPTY_DEFINITION);
        });
      }
      if (remoteProperties2 != null) {
        if (Array.isArray(remoteProperties2)) {
          remoteProperties2.forEach((propertyName) => {
            saveRemoteProperty(propertyName, void 0, observedAttributes, remotePropertyDefinitions, attributeToPropertyMap, eventToPropertyMap);
          });
        } else {
          Object.keys(remoteProperties2).forEach((propertyName) => {
            saveRemoteProperty(propertyName, remoteProperties2[propertyName], observedAttributes, remotePropertyDefinitions, attributeToPropertyMap, eventToPropertyMap);
          });
        }
      }
      if (remoteAttributes2 != null) {
        remoteAttributes2.forEach((attribute) => {
          remoteAttributeDefinitions.set(attribute, EMPTY_DEFINITION);
          observedAttributes.add(attribute);
        });
      }
      if (remoteEvents != null) {
        if (Array.isArray(remoteEvents)) {
          remoteEvents.forEach((event) => {
            remoteEventDefinitions.set(event, EMPTY_DEFINITION);
          });
        } else {
          Object.keys(remoteEvents).forEach((event) => {
            remoteEventDefinitions.set(event, remoteEvents[event]);
          });
        }
      }
      if (remoteMethods != null) {
        if (Array.isArray(remoteMethods)) {
          for (const method of remoteMethods) {
            this.prototype[method] = function(...args) {
              return this.callRemoteMethod(method, ...args);
            };
          }
        } else {
          Object.assign(this, remoteMethods);
        }
      }
      Object.defineProperties(this, {
        __observedAttributes: {
          value: [...observedAttributes],
          enumerable: false
        },
        __remoteSlotDefinitions: {
          value: remoteSlotDefinitions,
          enumerable: false
        },
        __remotePropertyDefinitions: {
          value: remotePropertyDefinitions,
          enumerable: false
        },
        __remoteAttributeDefinitions: {
          value: remoteAttributeDefinitions,
          enumerable: false
        },
        __remoteEventDefinitions: {
          value: remoteEventDefinitions,
          enumerable: false
        },
        __attributeToPropertyMap: {
          value: attributeToPropertyMap,
          enumerable: false
        },
        __eventToPropertyMap: {
          value: eventToPropertyMap,
          enumerable: false
        }
      });
      return this;
    }
    // Just need to use these types so TS doesn\u{2019}t lose track of them.
    /** @internal */
    /** @internal */
    /** @internal */
    /** @internal */
    constructor() {
      super();
      this.constructor.finalize();
      const propertyDescriptors = {};
      const initialPropertiesToSet = {};
      const prototype = Object.getPrototypeOf(this);
      const ThisClass = this.constructor;
      for (const [property, description] of ThisClass.remotePropertyDefinitions.entries()) {
        const aliasedName = description.name;
        if (prototype.hasOwnProperty(property)) {
          continue;
        }
        if (property === aliasedName) {
          initialPropertiesToSet[property] = description.default;
        }
        const propertyDescriptor = {
          configurable: true,
          enumerable: property === aliasedName,
          get: () => {
            return remoteProperties(this)?.[aliasedName];
          },
          set: (value) => {
            updateRemoteElementProperty(this, aliasedName, value);
          }
        };
        propertyDescriptors[property] = propertyDescriptor;
      }
      for (const [event, definition] of ThisClass.remoteEventDefinitions.entries()) {
        const propertyFromDefinition = definition.property ?? true;
        if (!propertyFromDefinition) continue;
        const property = propertyFromDefinition === true ? \`on\${event}\` : propertyFromDefinition;
        propertyDescriptors[property] = {
          configurable: true,
          enumerable: true,
          get: () => {
            return getRemoteEvents(this).properties.get(property) ?? null;
          },
          set: (value) => {
            const remoteEvents = getRemoteEvents(this);
            const currentListener = remoteEvents.properties.get(property);
            if (typeof value === "function") {
              let handler = function(...args) {
                return value.call(this, ...args);
              };
              remoteEvents.properties.set(property, handler);
              this.addEventListener(event, handler);
            } else {
              remoteEvents.properties.delete(property);
            }
            if (currentListener) {
              this.removeEventListener(event, currentListener);
            }
          }
        };
      }
      Object.defineProperties(this, propertyDescriptors);
      Object.assign(this, initialPropertiesToSet);
    }
    attributeChangedCallback(attribute, _oldValue, newValue) {
      if (attribute === "slot" && this.constructor.slottable) {
        updateRemoteElementAttribute(this, attribute, newValue ? String(newValue) : void 0);
        return;
      }
      const {
        remotePropertyDefinitions,
        remoteAttributeDefinitions,
        __attributeToPropertyMap: attributeToPropertyMap
      } = this.constructor;
      if (remoteAttributeDefinitions.has(attribute)) {
        updateRemoteElementAttribute(this, attribute, newValue);
        return;
      }
      const property = attributeToPropertyMap.get(attribute);
      const propertyDefinition = property == null ? property : remotePropertyDefinitions.get(property);
      if (propertyDefinition == null) return;
      this[property] = convertAttributeValueToProperty(newValue, propertyDefinition.type);
    }
    connectedCallback() {
      for (const [event, descriptor] of this.constructor.remoteEventDefinitions.entries()) {
        if (descriptor.bubbles) {
          this.addEventListener(event, noopBubblesEventListener);
        }
      }
    }
    disconnectedCallback() {
      for (const [event, descriptor] of this.constructor.remoteEventDefinitions.entries()) {
        if (descriptor.bubbles) {
          this.removeEventListener(event, noopBubblesEventListener);
        }
      }
    }
    addEventListener(type, listener, options) {
      const {
        remoteEventDefinitions,
        __eventToPropertyMap: eventToPropertyMap
      } = this.constructor;
      const listenerDefinition = remoteEventDefinitions.get(type);
      const property = eventToPropertyMap.get(type);
      if (listenerDefinition == null && property == null) {
        return super.addEventListener(type, listener, options);
      }
      const remoteEvents = getRemoteEvents(this);
      const remoteEvent = getRemoteEventRecord.call(this, type, {
        property,
        definition: listenerDefinition
      });
      const normalizedListener = typeof options === "object" && options?.once ? (...args) => {
        const result = typeof listener === "object" ? listener.handleEvent(...args) : listener.call(this, ...args);
        removeRemoteListener.call(this, type, listener, listenerRecord);
        return result;
      } : listener;
      const listenerRecord = [normalizedListener, remoteEvent];
      remoteEvent.listeners.add(listener);
      remoteEvents.listeners.set(listener, listenerRecord);
      super.addEventListener(type, normalizedListener, options);
      if (typeof options === "object" && options.signal) {
        options.signal.addEventListener("abort", () => {
          removeRemoteListener.call(this, type, listener, listenerRecord);
        }, {
          once: true
        });
      }
      if (listenerDefinition) {
        updateRemoteElementEventListener(this, type, remoteEvent.dispatch);
      } else {
        updateRemoteElementProperty(this, property, remoteEvent.dispatch);
      }
    }
    removeEventListener(type, listener, options) {
      const listenerRecord = REMOTE_EVENTS.get(this)?.listeners.get(listener);
      const normalizedListener = listenerRecord ? listenerRecord[0] : listener;
      super.removeEventListener(type, normalizedListener, options);
      if (listenerRecord == null) return;
      removeRemoteListener.call(this, type, listener, listenerRecord);
    }
    /**
     * Updates a single remote property on an element node. If the element is
     * connected to a remote root, this function will also make a \`mutate()\` call
     * to communicate the change to the host.
     */
    updateRemoteProperty(name, value) {
      updateRemoteElementProperty(this, name, value);
    }
    /**
     * Updates a single remote attribute on an element node. If the element is
     * connected to a remote root, this function will also make a \`mutate()\` call
     * to communicate the change to the host.
     */
    updateRemoteAttribute(name, value) {
      updateRemoteElementAttribute(this, name, value);
    }
    /**
     * Performs a method through \`RemoteConnection.call()\`, using the remote ID and
     * connection for the provided node.
     */
    callRemoteMethod(method, ...args) {
      return callRemoteElementMethod(this, method, ...args);
    }
  };
  __publicField(RemoteElement, "slottable", true);
  __publicField(RemoteElement, "__finalized", true);
  __publicField(RemoteElement, "__observedAttributes", []);
  __publicField(RemoteElement, "__attributeToPropertyMap", /* @__PURE__ */ (() => /* @__PURE__ */ new Map())());
  __publicField(RemoteElement, "__eventToPropertyMap", /* @__PURE__ */ (() => /* @__PURE__ */ new Map())());
  __publicField(RemoteElement, "__remotePropertyDefinitions", /* @__PURE__ */ (() => /* @__PURE__ */ new Map())());
  __publicField(RemoteElement, "__remoteAttributeDefinitions", /* @__PURE__ */ (() => /* @__PURE__ */ new Map())());
  __publicField(RemoteElement, "__remoteEventDefinitions", /* @__PURE__ */ (() => /* @__PURE__ */ new Map())());
  __publicField(RemoteElement, "__remoteSlotDefinitions", /* @__PURE__ */ (() => /* @__PURE__ */ new Map())());
  var REMOTE_EVENTS = /* @__PURE__ */ new WeakMap();
  function getRemoteEvents(element) {
    let events = REMOTE_EVENTS.get(element);
    if (events) return events;
    events = {
      events: /* @__PURE__ */ new Map(),
      properties: /* @__PURE__ */ new Map(),
      listeners: /* @__PURE__ */ new WeakMap()
    };
    REMOTE_EVENTS.set(element, events);
    return events;
  }
  function getRemoteEventRecord(type, {
    property,
    definition
  }) {
    const remoteEvents = getRemoteEvents(this);
    let remoteEvent = remoteEvents.events.get(type);
    if (remoteEvent == null) {
      remoteEvent = {
        name: type,
        property,
        definition,
        listeners: /* @__PURE__ */ new Set(),
        dispatch: (arg) => {
          const event = definition?.dispatchEvent?.call(this, arg) ?? new RemoteEvent(type, {
            detail: arg,
            bubbles: definition?.bubbles
          });
          this.dispatchEvent(event);
          return event.response;
        }
      };
      remoteEvents.events.set(type, remoteEvent);
    }
    return remoteEvent;
  }
  function removeRemoteListener(type, listener, listenerRecord) {
    const remoteEvents = getRemoteEvents(this);
    const remoteEvent = listenerRecord[1];
    remoteEvent.listeners.delete(listener);
    remoteEvents.listeners.delete(listener);
    if (remoteEvent.listeners.size > 0) return;
    remoteEvents.events.delete(type);
    if (remoteEvent.property) {
      if (remoteProperties(this)?.[remoteEvent.property] === remoteEvent.dispatch) {
        updateRemoteElementProperty(this, remoteEvent.property, void 0);
      }
    } else {
      if (remoteEventListeners(this)?.[type] === remoteEvent.dispatch) {
        updateRemoteElementEventListener(this, type, void 0);
      }
    }
  }
  function saveRemoteProperty(name, description, observedAttributes, remotePropertyDefinitions, attributeToPropertyMap, eventToPropertyMap) {
    if (remotePropertyDefinitions.has(name)) {
      return remotePropertyDefinitions.get(name);
    }
    const looksLikeEventCallback = name[0] === "o" && name[1] === "n";
    const resolvedDescription = description ?? {};
    let {
      alias
    } = resolvedDescription;
    const {
      type = looksLikeEventCallback ? Function : String,
      attribute = type !== Function,
      event = looksLikeEventCallback,
      default: defaultValue = type === Boolean ? false : void 0
    } = resolvedDescription;
    if (alias == null) {
      const lowercaseProperty = name.toLowerCase();
      if (lowercaseProperty !== name) {
        alias = [lowercaseProperty];
      }
      if (looksLikeEventCallback) {
        alias ?? (alias = []);
        alias.unshift(\`_\${name}\`);
      }
    }
    let attributeName;
    if (attribute === true) {
      attributeName = camelToKebabCase(name);
    } else if (typeof attribute === "string") {
      attributeName = attribute;
    }
    if (attributeName) {
      if (Array.isArray(observedAttributes)) {
        observedAttributes.push(attributeName);
      } else {
        observedAttributes.add(attributeName);
      }
      attributeToPropertyMap.set(attributeName, name);
    }
    let eventName;
    if (event === true) {
      eventName = camelToKebabCase(looksLikeEventCallback ? name.slice(2) : name);
    } else if (typeof event === "string") {
      eventName = event;
    }
    if (eventName) {
      eventToPropertyMap.set(eventName, name);
    }
    const definition = {
      name,
      type,
      alias,
      event: eventName,
      attribute: attributeName,
      default: defaultValue
    };
    remotePropertyDefinitions.set(name, definition);
    if (alias) {
      for (const propertyAlias of alias) {
        remotePropertyDefinitions.set(propertyAlias, definition);
      }
    }
    return definition;
  }
  function convertAttributeValueToProperty(value, type) {
    if (value == null) return void 0;
    switch (type) {
      case Boolean:
        return value != null && value !== "false";
      case Object:
      case Array:
        try {
          return JSON.parse(value);
        } catch {
          return void 0;
        }
      case String:
        return String(value);
      case Number:
        return Number.parseFloat(value);
      case Function:
        return void 0;
      default: {
        return type.parse?.(value);
      }
    }
  }
  function camelToKebabCase(str) {
    return str.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
  }
  function noopBubblesEventListener() {
  }

  // ../../../node_modules/.pnpm/@remote-dom+core@1.8.1_@preact+signals-core@1.10.0/node_modules/@remote-dom/core/build/esm/elements/RemoteMutationObserver.mjs
  var RemoteMutationObserver = class extends MutationObserver {
    constructor(connection) {
      super((records) => {
        const addedNodes = [];
        const remoteRecords = [];
        for (const record of records) {
          const targetId = remoteId(record.target);
          if (record.type === "childList") {
            const position = record.previousSibling ? indexOf(record.previousSibling, record.target.childNodes) + 1 : 0;
            record.removedNodes.forEach((node) => {
              disconnectRemoteNode(node);
              remoteRecords.push([MUTATION_TYPE_REMOVE_CHILD, targetId, position]);
            });
            record.addedNodes.forEach((node, index) => {
              if (addedNodes.some((addedNode) => {
                return addedNode === node || addedNode.contains(node);
              })) {
                return;
              }
              addedNodes.push(node);
              connectRemoteNode(node, connection);
              remoteRecords.push([MUTATION_TYPE_INSERT_CHILD, targetId, serializeRemoteNode(node), position + index]);
            });
          } else if (record.type === "characterData") {
            remoteRecords.push([MUTATION_TYPE_UPDATE_TEXT, targetId, record.target.textContent ?? ""]);
          } else if (record.type === "attributes" && record.attributeName != null && record.target instanceof Element && !record.target.tagName.includes("-")) {
            remoteRecords.push([MUTATION_TYPE_UPDATE_PROPERTY, targetId, record.attributeName, record.target.getAttribute(record.attributeName)]);
          }
        }
        connection.mutate(remoteRecords);
      });
      this.connection = connection;
    }
    /**
     * Starts watching changes to the element, and communicates changes to the
     * host environment. By default, this method will also communicate any initial
     * children of the element to the host environment.
     */
    observe(target, options) {
      REMOTE_IDS.set(target, ROOT_ID);
      if (options?.initial !== false && target.childNodes.length > 0) {
        const records = [];
        for (let i = 0; i < target.childNodes.length; i++) {
          const node = target.childNodes[i];
          connectRemoteNode(node, this.connection);
          records.push([MUTATION_TYPE_INSERT_CHILD, ROOT_ID, serializeRemoteNode(node), i]);
        }
        this.connection.mutate(records);
      }
      super.observe(target, {
        subtree: true,
        childList: true,
        attributes: true,
        characterData: true,
        ...options
      });
    }
  };
  function indexOf(node, list) {
    for (let i = 0; i < list.length; i++) {
      if (list[i] === node) return i;
    }
    return -1;
  }

  // ../../../node_modules/.pnpm/@quilted+threads@3.1.3_@preact+signals-core@1.10.0/node_modules/@quilted/threads/build/esm/constants.mjs
  var MESSAGE_CALL = 1;
  var MESSAGE_CALL_RESULT = 2;
  var MESSAGE_FUNCTION_CALL = 3;
  var MESSAGE_FUNCTION_RESULT = 4;
  var MESSAGE_FUNCTION_RELEASE = 5;
  var SERIALIZE_METHOD = Symbol.for("quilt.threads.serialize");
  var TRANSFERABLE = Symbol.for("quilt.threads.transferable");

  // ../../../node_modules/.pnpm/@quilted+events@2.1.3/node_modules/@quilted/events/build/esm/abort/NestedAbortController.mjs
  var NestedAbortController = class extends AbortController {
    constructor(...parents) {
      super();
      const abortedSignal = parents.find((signal) => signal.aborted);
      if (abortedSignal) {
        this.abort(abortedSignal.reason);
      } else {
        const abort = (event) => this.abort(event.target.reason);
        const options = {
          signal: this.signal
        };
        for (const signal of parents) {
          signal.addEventListener("abort", abort, options);
        }
      }
    }
  };

  // ../../../node_modules/.pnpm/@quilted+threads@3.1.3_@preact+signals-core@1.10.0/node_modules/@quilted/threads/build/esm/errors.mjs
  var ThreadClosedError = class extends Error {
    constructor() {
      super("You attempted to call a function on a closed thread.");
    }
  };

  // ../../../node_modules/.pnpm/@quilted+threads@3.1.3_@preact+signals-core@1.10.0/node_modules/@quilted/threads/build/esm/nanoid.mjs
  var a = "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict";
  function nanoid(e = 21) {
    let t = "", r = crypto.getRandomValues(new Uint8Array(e));
    for (let n = 0; n < e; n++) t += a[63 & r[n]];
    return t;
  }

  // ../../../node_modules/.pnpm/@quilted+threads@3.1.3_@preact+signals-core@1.10.0/node_modules/@quilted/threads/build/esm/functions/ThreadFunctionsAutomatic.mjs
  var _functionsToId, _idsToFunction, _idsToProxy, _finalization, _ThreadFunctionsAutomatic_instances, finalizationRegistry_fn;
  var ThreadFunctionsAutomatic = class {
    constructor() {
      __privateAdd(this, _ThreadFunctionsAutomatic_instances);
      __privateAdd(this, _functionsToId, /* @__PURE__ */ (() => /* @__PURE__ */ new Map())());
      __privateAdd(this, _idsToFunction, /* @__PURE__ */ (() => /* @__PURE__ */ new Map())());
      __privateAdd(this, _idsToProxy, /* @__PURE__ */ (() => /* @__PURE__ */ new Map())());
      __privateAdd(this, _finalization, /* @__PURE__ */ (() => /* @__PURE__ */ new WeakMap())());
    }
    get(id2) {
      return __privateGet(this, _idsToFunction).get(id2);
    }
    release(id2) {
      const func = __privateGet(this, _idsToFunction).get(id2);
      if (func) {
        __privateGet(this, _idsToFunction).delete(id2);
        __privateGet(this, _functionsToId).delete(func);
      }
      return Boolean(func);
    }
    serialize(func) {
      let id2 = __privateGet(this, _functionsToId).get(func);
      if (id2 == null) {
        id2 = nanoid();
        __privateGet(this, _functionsToId).set(func, id2);
        __privateGet(this, _idsToFunction).set(id2, func);
      }
      return id2;
    }
    deserialize(id2, thread) {
      let proxy = __privateGet(this, _idsToProxy).get(id2)?.deref();
      if (proxy) return proxy;
      proxy = (...args) => {
        if (!__privateGet(this, _idsToProxy).has(id2)) {
          throw new Error("You attempted to call a function that was already revoked.");
        }
        return thread.call((callID, args2, transferable) => {
          thread.messages.send([MESSAGE_FUNCTION_CALL, callID, id2, args2], transferable);
        }, args);
      };
      __privateMethod(this, _ThreadFunctionsAutomatic_instances, finalizationRegistry_fn).call(this, thread)?.register(proxy, id2);
      __privateGet(this, _idsToProxy).set(id2, new WeakRef(proxy));
      return proxy;
    }
  };
  _functionsToId = new WeakMap();
  _idsToFunction = new WeakMap();
  _idsToProxy = new WeakMap();
  _finalization = new WeakMap();
  _ThreadFunctionsAutomatic_instances = new WeakSet();
  finalizationRegistry_fn = function(thread) {
    let finalization = __privateGet(this, _finalization).get(thread);
    if (typeof FinalizationRegistry === "undefined") {
      return void 0;
    }
    if (!finalization) {
      finalization = new FinalizationRegistry((id2) => {
        thread.messages.send([MESSAGE_FUNCTION_RELEASE, id2]);
      });
      __privateGet(this, _finalization).set(thread, finalization);
    }
    return finalization;
  };

  // ../../../node_modules/.pnpm/@quilted+threads@3.1.3_@preact+signals-core@1.10.0/node_modules/@quilted/threads/build/esm/serialization/shared.mjs
  function isIterator(value) {
    return value != null && (Symbol.asyncIterator in value || Symbol.iterator in value) && typeof value.next === "function";
  }
  function isBasicObject(value) {
    if (value == null || typeof value !== "object") return false;
    const prototype = Object.getPrototypeOf(value);
    return prototype == null || prototype === Object.prototype;
  }

  // ../../../node_modules/.pnpm/@quilted+threads@3.1.3_@preact+signals-core@1.10.0/node_modules/@quilted/threads/build/esm/serialization/ThreadSerializationStructuredClone.mjs
  var FUNCTION = "_@f";
  var ASYNC_ITERATOR = "_@i";
  var _customSerializer, _customDeserializer, _ThreadSerializationStructuredClone_instances, serializeInternal_fn, deserializeInternal_fn;
  var ThreadSerializationStructuredClone = class {
    constructor(options) {
      __privateAdd(this, _ThreadSerializationStructuredClone_instances);
      __privateAdd(this, _customSerializer);
      __privateAdd(this, _customDeserializer);
      __privateSet(this, _customSerializer, options?.serialize);
      __privateSet(this, _customDeserializer, options?.deserialize);
    }
    /**
     * Serializes a value into a structured cloning-compatible format that can be transferred between threads.
     */
    serialize(value, thread, transferable) {
      return __privateMethod(this, _ThreadSerializationStructuredClone_instances, serializeInternal_fn).call(this, value, thread, transferable);
    }
    /**
     * Deserializes a structured cloning-compatible value from another thread.
     */
    deserialize(value, thread) {
      return __privateMethod(this, _ThreadSerializationStructuredClone_instances, deserializeInternal_fn).call(this, value, thread);
    }
  };
  _customSerializer = new WeakMap();
  _customDeserializer = new WeakMap();
  _ThreadSerializationStructuredClone_instances = new WeakSet();
  serializeInternal_fn = function(value, thread, transferable, seen = /* @__PURE__ */ new Map(), isApplyingDefault = false) {
    if (value == null) return value;
    if (seen.has(value)) return seen.get(value);
    seen.set(value, void 0);
    if (typeof value === "object") {
      if (__privateGet(this, _customSerializer) && !isApplyingDefault) {
        const customValue = __privateGet(this, _customSerializer).call(this, value, (value2) => __privateMethod(this, _ThreadSerializationStructuredClone_instances, serializeInternal_fn).call(this, value2, thread, transferable, seen, true), thread, transferable);
        if (customValue !== void 0) {
          seen.set(value, customValue);
          return customValue;
        }
      }
      if (value[TRANSFERABLE]) {
        transferable?.push(value);
        seen.set(value, value);
        return value;
      }
      const serializeValue = (value2) => {
        return __privateMethod(this, _ThreadSerializationStructuredClone_instances, serializeInternal_fn).call(this, value2, thread, transferable, seen);
      };
      if (typeof value[SERIALIZE_METHOD] === "function") {
        const result = value[SERIALIZE_METHOD]({
          serialize: serializeValue
        });
        seen.set(value, result);
        return result;
      }
      if (Array.isArray(value)) {
        const result = value.map((item) => serializeValue(item));
        seen.set(value, result);
        return result;
      }
      if (value instanceof Map) {
        const entries = [...value.entries()].map(([key, value2]) => {
          return [serializeValue(key), serializeValue(value2)];
        });
        const result = new Map(entries);
        seen.set(value, result);
        return result;
      }
      if (value instanceof Set) {
        const entries = [...value].map((entry) => serializeValue(entry));
        const result = new Set(entries);
        seen.set(value, result);
        return result;
      }
      const valueIsIterator = isIterator(value);
      if (isBasicObject(value) || valueIsIterator) {
        const result = {};
        for (const key of Object.keys(value)) {
          result[key] = serializeValue(value[key]);
        }
        if (valueIsIterator) {
          result.next ?? (result.next = serializeValue(value.next.bind(value)));
          result.return ?? (result.return = serializeValue(value.return.bind(value)));
          result.throw ?? (result.throw = serializeValue(value.throw.bind(value)));
          result[ASYNC_ITERATOR] = true;
        }
        seen.set(value, result);
        return result;
      }
    }
    if (typeof value === "function") {
      const serialized = thread.functions.serialize(value, thread, transferable);
      const result = {
        [FUNCTION]: serialized
      };
      seen.set(value, result);
      return result;
    }
    seen.set(value, value);
    return value;
  };
  deserializeInternal_fn = function(value, thread, isApplyingDefault = false) {
    if (value == null) return value;
    if (typeof value === "object") {
      if (__privateGet(this, _customDeserializer) && !isApplyingDefault) {
        const customValue = __privateGet(this, _customDeserializer).call(this, value, (value2) => __privateMethod(this, _ThreadSerializationStructuredClone_instances, deserializeInternal_fn).call(this, value2, thread, true), thread);
        if (customValue !== void 0) {
          return customValue;
        }
      }
      if (value == null) {
        return value;
      }
      if (Array.isArray(value)) {
        return value.map((value2) => __privateMethod(this, _ThreadSerializationStructuredClone_instances, deserializeInternal_fn).call(this, value2, thread));
      }
      if (value instanceof Map) {
        return new Map([...value].map(([key, value2]) => [__privateMethod(this, _ThreadSerializationStructuredClone_instances, deserializeInternal_fn).call(this, key, thread), __privateMethod(this, _ThreadSerializationStructuredClone_instances, deserializeInternal_fn).call(this, value2, thread)]));
      }
      if (value instanceof Set) {
        return new Set([...value].map((entry) => __privateMethod(this, _ThreadSerializationStructuredClone_instances, deserializeInternal_fn).call(this, entry, thread)));
      }
      if (FUNCTION in value) {
        const func = thread.functions.deserialize(value[FUNCTION], thread);
        return func;
      }
      if (!isBasicObject(value)) {
        return value;
      }
      const result = {};
      for (const key of Object.keys(value)) {
        if (key === ASYNC_ITERATOR) {
          result[Symbol.asyncIterator] = () => result;
        } else {
          result[key] = __privateMethod(this, _ThreadSerializationStructuredClone_instances, deserializeInternal_fn).call(this, value[key], thread);
        }
      }
      return result;
    }
    return value;
  };

  // ../../../node_modules/.pnpm/@quilted+threads@3.1.3_@preact+signals-core@1.10.0/node_modules/@quilted/threads/build/esm/Thread.mjs
  var _abort, _idsToResolver, _Thread_instances, callLocal_fn, handlerForCall_fn, resolveCall_fn, waitForResult_fn;
  var Thread = class {
    constructor(messages, {
      imports,
      exports,
      functions = new ThreadFunctionsAutomatic(),
      serialization = new ThreadSerializationStructuredClone(),
      signal
    } = {}) {
      __privateAdd(this, _Thread_instances);
      __privateAdd(this, _abort);
      __privateAdd(this, _idsToResolver, /* @__PURE__ */ (() => /* @__PURE__ */ new Map())());
      this.messages = messages;
      __privateSet(this, _abort, signal ? new NestedAbortController(signal) : new AbortController());
      this.exports = exports ?? {};
      this.imports = createThreadImports(__privateMethod(this, _Thread_instances, handlerForCall_fn).bind(this), imports);
      this.functions = functions;
      this.serialization = serialization;
      this.functions.start?.(this);
      this.serialization.start?.(this);
      this.signal.addEventListener("abort", () => {
        for (const id2 of __privateGet(this, _idsToResolver).keys()) {
          __privateMethod(this, _Thread_instances, resolveCall_fn).call(this, id2, void 0, new ThreadClosedError());
        }
        __privateGet(this, _idsToResolver).clear();
      }, {
        once: true
      });
      messages.listen(async (rawData) => {
        const isThreadMessageData = Array.isArray(rawData) && typeof rawData[0] === "number";
        if (!isThreadMessageData) {
          return;
        }
        const data = rawData;
        switch (data[0]) {
          case MESSAGE_CALL: {
            const [, id2, property, args] = data;
            const func = this.exports[property] ?? (() => {
              throw new Error(\`No '\${property}' method is exported from this thread\`);
            });
            await __privateMethod(this, _Thread_instances, callLocal_fn).call(this, func, args, (value, error, transferable) => {
              this.messages.send([MESSAGE_CALL_RESULT, id2, value, error], transferable);
            });
            break;
          }
          case MESSAGE_FUNCTION_CALL: {
            const [, callID, funcID, args] = data;
            const func = this.functions.get(funcID, this) ?? missingThreadFunction;
            await __privateMethod(this, _Thread_instances, callLocal_fn).call(this, func, args, (value, error, transferable) => {
              this.messages.send([MESSAGE_FUNCTION_RESULT, callID, value, error], transferable);
            });
            break;
          }
          case MESSAGE_CALL_RESULT:
          case MESSAGE_FUNCTION_RESULT: {
            __privateMethod(this, _Thread_instances, resolveCall_fn).call(this, ...data.slice(1));
            break;
          }
          case MESSAGE_FUNCTION_RELEASE: {
            const id2 = data[1];
            this.functions.release(id2, this);
            break;
          }
        }
      }, {
        signal: this.signal
      });
    }
    /**
     * An object that exposes the methods that can be called on the paired thread.
     * This object will automatically encode and decode arguments and return values
     * as necessary.
     */
    /**
     * An object that exposes the methods that can be called on this thread by the
     * paired thread. To set these methods, pass the \`exports\` option when creating
     * a new \`Thread\`.
     */
    /**
     * An object that provides the message-passing interface that allows communication
     * to flow between environments.
     */
    /**
     * An object that manages how functions are proxied between threads.
     */
    /**
     * An object that manages how values are serialized and deserialized between threads.
     */
    /**
     * An \`AbortSignal\` that indicates whether the communication channel is still open.
     */
    get signal() {
      return __privateGet(this, _abort).signal;
    }
    /**
     * A boolean indicating whether the communication channel is still open.
     */
    get closed() {
      return __privateGet(this, _abort).signal.aborted;
    }
    /**
     * Closes the communication channel between the two threads. This will prevent
     * any further communication between the threads, and will clean up any memory
     * associated with in-progress communication. It will also reject any inflight
     * function calls between threads with a \`ThreadClosedError\`.
     */
    close() {
      __privateGet(this, _abort).abort();
    }
    /**
     * Requests that the thread provide the context needed to make a function
     * call between threads. You provide this method a function to call and the
     * unserialized arguments you wish to call it with, and the thread will call
     * the function you provided with a serialized call ID, the serialized arguments,
     * and any transferable objects that need to be passed between threads.
     */
    call(func, args) {
      if (this.closed) {
        return Promise.reject(new ThreadClosedError());
      }
      const transferable = [];
      const serialized = this.serialization.serialize(args, this, transferable);
      const id2 = nanoid();
      const done = __privateMethod(this, _Thread_instances, waitForResult_fn).call(this, id2);
      func(id2, serialized, transferable);
      return done;
    }
  };
  _abort = new WeakMap();
  _idsToResolver = new WeakMap();
  _Thread_instances = new WeakSet();
  callLocal_fn = async function(func, args, withResult) {
    try {
      const result = this.functions.call ? await this.functions.call(func, args, this) : await func(...this.serialization.deserialize(args, this));
      const transferable = [];
      const serialized = this.serialization.serialize(result, this, transferable);
      withResult(serialized, void 0, transferable);
    } catch (error) {
      withResult(void 0, this.serialization.serialize(error, this));
    }
  };
  handlerForCall_fn = function(property) {
    return (...args) => {
      try {
        if (typeof property !== "string" && typeof property !== "number") {
          throw new Error(\`Can\u{2019}t call a symbol method on a thread: \${property.toString()}\`);
        }
        return this.call((id2, serializedArgs, transferable) => {
          this.messages.send([MESSAGE_CALL, id2, property, serializedArgs], transferable);
        }, args);
      } catch (error) {
        return Promise.reject(error);
      }
    };
  };
  resolveCall_fn = function(...args) {
    const callID = args[0];
    const resolver = __privateGet(this, _idsToResolver).get(callID);
    if (resolver) {
      resolver(...args);
      __privateGet(this, _idsToResolver).delete(callID);
    }
  };
  waitForResult_fn = function(id2) {
    const promise = new Promise((resolve, reject) => {
      __privateGet(this, _idsToResolver).set(id2, (_, value, error) => {
        if (error == null) {
          resolve(this.serialization.deserialize(value, this));
        } else {
          reject(this.serialization.deserialize(error, this));
        }
      });
    });
    Object.defineProperty(promise, Symbol.asyncIterator, {
      async *value() {
        const result = await promise;
        Object.defineProperty(result, Symbol.asyncIterator, {
          value: () => result
        });
        yield* result;
      }
    });
    return promise;
  };
  function createThreadImports(handlerForImport, imported) {
    let call;
    if (imported == null) {
      if (typeof Proxy !== "function") {
        throw new Error(\`You must pass an array of callable methods in environments without Proxies.\`);
      }
      const cache = /* @__PURE__ */ new Map();
      call = new Proxy({}, {
        get(_target, property) {
          if (cache.has(property)) {
            return cache.get(property);
          }
          const handler = handlerForImport(property);
          cache.set(property, handler);
          return handler;
        }
      });
    } else {
      call = {};
      for (const method of imported) {
        Object.defineProperty(call, method, {
          value: handlerForImport(method),
          writable: false,
          configurable: true,
          enumerable: true
        });
      }
    }
    return call;
  }
  function missingThreadFunction() {
    throw new Error(\`You attempted to call a function that is not stored. It may have already been released.\`);
  }

  // ../../../node_modules/.pnpm/@quilted+threads@3.1.3_@preact+signals-core@1.10.0/node_modules/@quilted/threads/build/esm/threads/window/shared.mjs
  var CHECK_MESSAGE = "quilt.threads.ping";
  var RESPONSE_MESSAGE = "quilt.threads.pong";

  // ../../../node_modules/.pnpm/@quilted+threads@3.1.3_@preact+signals-core@1.10.0/node_modules/@quilted/threads/build/esm/threads/window/ThreadNestedWindow.mjs
  function nestedWindowToThreadTarget(parent, {
    targetOrigin = "*"
  } = {}) {
    const ready = () => {
      const respond = () => parent.postMessage(RESPONSE_MESSAGE, targetOrigin);
      self.addEventListener("message", ({
        data,
        source
      }) => {
        if (source !== parent) return;
        if (data === CHECK_MESSAGE) respond();
      });
      respond();
    };
    if (document.readyState === "complete") {
      ready();
    } else {
      document.addEventListener("readystatechange", () => {
        if (document.readyState === "complete") {
          ready();
        }
      });
    }
    return {
      send(message, transfer) {
        return parent.postMessage(message, targetOrigin, transfer);
      },
      listen(listen, {
        signal
      }) {
        self.addEventListener("message", (event) => {
          if (event.data === CHECK_MESSAGE) return;
          listen(event.data);
        }, {
          signal
        });
      }
    };
  }

  // ../../../node_modules/.pnpm/@quilted+threads@3.1.3_@preact+signals-core@1.10.0/node_modules/@quilted/threads/build/esm/threads/ThreadNestedIframe.mjs
  var ThreadNestedIframe = class extends Thread {
    constructor({
      parent = globalThis.parent,
      targetOrigin = "*",
      ...options
    } = {}) {
      if (typeof self === "undefined" || parent == null) {
        throw new Error("You are not inside an iframe, because there is no parent window.");
      }
      super(nestedWindowToThreadTarget(parent, {
        targetOrigin
      }), options);
      this.parent = parent;
    }
  };

  // scripts/iframe-entry.js
  new ThreadNestedIframe({
    exports: {
      async render(options, receiver, hostApi) {
        if (options.remoteElements) {
          options.remoteElements.forEach((def) => {
            if (customElements.get(def.tagName)) return;
            const remoteElement = class extends RemoteElement {
              static get remoteAttributes() {
                return def.remoteAttributes || [];
              }
              static get remoteEvents() {
                return def.remoteEvents || [];
              }
            };
            Object.defineProperty(remoteElement, "name", {
              value: \`Remote\${def.tagName.replace(
                /(^w|-w)/g,
                (c) => c.replace("-", "").toUpperCase()
              )}\`
            });
            customElements.define(def.tagName, remoteElement);
          });
        }
        const root = document.querySelector("#root");
        const observer = new RemoteMutationObserver(receiver);
        observer.observe(root);
        const { code } = options;
        if (code && root) {
          try {
            const scriptFunction = new Function("root", "console", code);
            scriptFunction(root, console);
          } catch (e) {
            console.error("Error executing remote script:", e);
          }
        }
      }
    }
  });
})();

  </script>
</body>
</html>`,el=Symbol.for("quilt.threads.serialize"),ec=Symbol.for("quilt.threads.transferable");let Tt=class Tt extends AbortController{constructor(...r){super();const i=r.find(r=>r.aborted);if(i)this.abort(i.reason);else{const n=r=>this.abort(r.target.reason),i={signal:this.signal};for(const d of r)d.addEventListener("abort",n,i)}}};let Re=class Re extends Error{constructor(){super("You attempted to call a function on a closed thread.")}};function ze(r=21){let i="",d=crypto.getRandomValues(new Uint8Array(r));for(let p=0;p<r;p++)i+="useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict"[63&d[p]];return i}let Rt=class Rt{constructor(){S(this,C),S(this,p,new Map),S(this,_,new Map),S(this,w,new Map),S(this,E,new WeakMap)}get(r){return b(this,_).get(r)}release(r){let i=b(this,_).get(r);return i&&(b(this,_).delete(r),b(this,p).delete(i)),!!i}serialize(r){let i=b(this,p).get(r);return null==i&&(i=ze(),b(this,p).set(r,i),b(this,_).set(i,r)),i}deserialize(r,i){var d,p;let _=null==(d=b(this,w).get(r))?void 0:d.deref();return _||(_=(...d)=>{if(!b(this,w).has(r))throw Error("You attempted to call a function that was already revoked.");return i.call((d,p,_)=>{i.messages.send([3,d,r,p],_)},d)},null==(p=y(this,C,I).call(this,i))||p.register(_,r),b(this,w).set(r,new WeakRef(_)),_)}};function wt(r){return null!=r&&(Symbol.asyncIterator in r||Symbol.iterator in r)&&"function"==typeof r.next}function we(r){if(null==r||"object"!=typeof r)return!1;let i=Object.getPrototypeOf(r);return null==i||i===Object.prototype}p=new WeakMap,_=new WeakMap,w=new WeakMap,E=new WeakMap,C=new WeakSet,I=function(r){let i=b(this,E).get(r);if(!(typeof FinalizationRegistry>"u"))return i||(i=new FinalizationRegistry(i=>{r.messages.send([5,i])}),b(this,E).set(r,i)),i};let St=class St{constructor(r){S(this,F),S(this,R),S(this,k),Z(this,R,null==r?void 0:r.serialize),Z(this,k,null==r?void 0:r.deserialize)}serialize(r,i,d){return y(this,F,P).call(this,r,i,d)}deserialize(r,i){return y(this,F,M).call(this,r,i)}};R=new WeakMap,k=new WeakMap,F=new WeakSet,P=function(r,i,d,p=new Map,_=!1){if(null==r)return r;if(p.has(r))return p.get(r);if(p.set(r,void 0),"object"==typeof r){if(b(this,R)&&!_){let _=b(this,R).call(this,r,r=>y(this,F,P).call(this,r,i,d,p,!0),i,d);if(void 0!==_)return p.set(r,_),_}if(r[ec])return null==d||d.push(r),p.set(r,r),r;let a=r=>y(this,F,P).call(this,r,i,d,p);if("function"==typeof r[el]){let i=r[el]({serialize:a});return p.set(r,i),i}if(Array.isArray(r)){let i=r.map(r=>a(r));return p.set(r,i),i}if(r instanceof Map){let i=new Map([...r.entries()].map(([r,i])=>[a(r),a(i)]));return p.set(r,i),i}if(r instanceof Set){let i=new Set([...r].map(r=>a(r)));return p.set(r,i),i}let w=wt(r);if(we(r)||w){let i={};for(let d of Object.keys(r))i[d]=a(r[d]);return w&&(i.next??(i.next=a(r.next.bind(r))),i.return??(i.return=a(r.return.bind(r))),i.throw??(i.throw=a(r.throw.bind(r))),i["_@i"]=!0),p.set(r,i),i}}if("function"==typeof r){let _={"_@f":i.functions.serialize(r,i,d)};return p.set(r,_),_}return p.set(r,r),r},M=function(r,i,d=!1){if(null==r)return r;if("object"==typeof r){if(b(this,k)&&!d){let d=b(this,k).call(this,r,r=>y(this,F,M).call(this,r,i,!0),i);if(void 0!==d)return d}if(null==r)return r;if(Array.isArray(r))return r.map(r=>y(this,F,M).call(this,r,i));if(r instanceof Map)return new Map([...r].map(([r,d])=>[y(this,F,M).call(this,r,i),y(this,F,M).call(this,d,i)]));if(r instanceof Set)return new Set([...r].map(r=>y(this,F,M).call(this,r,i)));if("_@f"in r)return i.functions.deserialize(r["_@f"],i);if(!we(r))return r;let p={};for(let d of Object.keys(r))"_@i"===d?p[Symbol.asyncIterator]=()=>p:p[d]=y(this,F,M).call(this,r[d],i);return p}return r};let Mt=class Mt{constructor(r,{imports:i,exports:d,functions:p=new Rt,serialization:_=new St,signal:w}={}){var E,C,I,R;S(this,V),S(this,N),S(this,D,new Map),this.messages=r,Z(this,N,w?new Tt(w):new AbortController),this.exports=d??{},this.imports=At(y(this,V,j).bind(this),i),this.functions=p,this.serialization=_,null==(C=(E=this.functions).start)||C.call(E,this),null==(R=(I=this.serialization).start)||R.call(I,this),this.signal.addEventListener("abort",()=>{for(let r of b(this,D).keys())y(this,V,$).call(this,r,void 0,new Re);b(this,D).clear()},{once:!0}),r.listen(async r=>{if(Array.isArray(r)&&"number"==typeof r[0])switch(r[0]){case 1:{let[,i,d,p]=r,_=this.exports[d]??(()=>{throw Error(`No '${d}' method is exported from this thread`)});await y(this,V,z).call(this,_,p,(r,d,p)=>{this.messages.send([2,i,r,d],p)});break}case 3:{let[,i,d,p]=r,_=this.functions.get(d,this)??Nt;await y(this,V,z).call(this,_,p,(r,d,p)=>{this.messages.send([4,i,r,d],p)});break}case 2:case 4:y(this,V,$).call(this,...r.slice(1));break;case 5:{let i=r[1];this.functions.release(i,this)}}},{signal:this.signal})}get signal(){return b(this,N).signal}get closed(){return b(this,N).signal.aborted}close(){b(this,N).abort()}call(r,i){if(this.closed)return Promise.reject(new Re);let d=[],p=this.serialization.serialize(i,this,d),_=ze(),w=y(this,V,G).call(this,_);return r(_,p,d),w}};function At(r,i){let d;if(null==i){if("function"!=typeof Proxy)throw Error("You must pass an array of callable methods in environments without Proxies.");let i=new Map;d=new Proxy({},{get(d,p){if(i.has(p))return i.get(p);let _=r(p);return i.set(p,_),_}})}else for(let p of(d={},i))Object.defineProperty(d,p,{value:r(p),writable:!1,configurable:!0,enumerable:!0});return d}function Nt(){throw Error("You attempted to call a function that is not stored. It may have already been released.")}N=new WeakMap,D=new WeakMap,V=new WeakSet,z=async function(r,i,d){try{let p=this.functions.call?await this.functions.call(r,i,this):await r(...this.serialization.deserialize(i,this)),_=[],w=this.serialization.serialize(p,this,_);d(w,void 0,_)}catch(r){d(void 0,this.serialization.serialize(r,this))}},j=function(r){return(...i)=>{try{if("string"!=typeof r&&"number"!=typeof r)throw Error(`Can\u{2019}t call a symbol method on a thread: ${r.toString()}`);return this.call((i,d,p)=>{this.messages.send([1,i,r,d],p)},i)}catch(r){return Promise.reject(r)}}},$=function(...r){let i=r[0],d=b(this,D).get(i);d&&(d(...r),b(this,D).delete(i))},G=function(r){let i=new Promise((i,d)=>{b(this,D).set(r,(r,p,_)=>{null==_?i(this.serialization.deserialize(p,this)):d(this.serialization.deserialize(_,this))})});return Object.defineProperty(i,Symbol.asyncIterator,{async *value(){let r=await i;Object.defineProperty(r,Symbol.asyncIterator,{value:()=>r}),yield*r}}),i};let ed="quilt.threads.pong";function Pt(r,{targetOrigin:i="*"}={}){let d=!1,n=function(d,p){r.postMessage(d,i,p)},p=new Promise(i=>{let p=new AbortController;globalThis.window.addEventListener("message",_=>{_.source===r&&_.data===ed&&(d=!0,p.abort(),i())},{signal:p.signal}),p.signal.addEventListener("abort",()=>i(),{once:!0}),n("quilt.threads.ping")});return{send:(r,i)=>d?n(r,i):p.then(()=>{if(d)return n(r,i)}),listen(i,{signal:d}){self.addEventListener("message",d=>{d.source===r&&d.data!==ed&&i(d.data)},{signal:d})}}}let Ot=class Ot extends Mt{constructor(r,{targetOrigin:i="*",...d}={}){super(Pt(r.contentWindow,{targetOrigin:i}),d),this.iframe=r}};let eh=H.forwardRef(({content:r,children:i,...d},p)=>(0,q.jsx)("span",{ref:p,...d,children:r||i}));eh.displayName="UIText";let eu=H.forwardRef(({label:r,onPress:i,onClick:d,children:p,..._},w)=>(0,q.jsx)("button",{ref:w,onClick:r=>{i&&i(),d&&d(r)},style:{padding:"8px 16px",backgroundColor:"#007bff",color:"white",border:"none",borderRadius:"4px",cursor:"pointer"},..._,children:r||p}));eu.displayName="UIButton";let ef=H.forwardRef(({direction:r="vertical",spacing:i="8",align:d="stretch",justify:p="flex-start",children:_,...w},E)=>(0,q.jsx)("div",{ref:E,style:{display:"flex",flexDirection:"horizontal"===r?"row":"column",gap:`${i}px`,alignItems:d,justifyContent:p},...w,children:_}));ef.displayName="UIStack";let ep=H.forwardRef(({src:r,alt:i,width:d,height:p,children:_,...w},E)=>(0,q.jsx)("img",{ref:E,src:r,alt:i,width:d,height:p,style:{maxWidth:"100%",height:"auto",borderRadius:"8px",boxShadow:"0 2px 8px rgba(0, 0, 0, 0.1)"},...w}));ep.displayName="UIImage";let em={name:"basic",elements:[{tagName:"ui-text",component:eh,propMapping:{content:"content"},eventMapping:{}},{tagName:"ui-button",component:eu,propMapping:{label:"label"},eventMapping:{press:"onPress"}},{tagName:"ui-stack",component:ef,propMapping:{direction:"direction",spacing:"spacing",align:"align",justify:"justify"},eventMapping:{}},{tagName:"ui-image",component:ep,propMapping:{src:"src",alt:"alt",width:"width",height:"height"},eventMapping:{}}]},Dt=({receiver:r})=>{let i=(0,H.useRef)(null);return(0,H.useEffect)(()=>{if(i.current)return r.connect(i.current),()=>{r.disconnect()}},[r]),(0,q.jsx)("div",{ref:i,"data-testid":"standard-dom-renderer-container"})},Ct=({resource:r,library:i,remoteElements:d=[],onUIAction:p})=>{let _=(0,H.useRef)(null),w=(0,H.useRef)(null),[E,C]=(0,H.useState)(null),I=(0,H.useMemo)(()=>(r.mimeType||"").includes("framework=react")?"react":"webcomponents",[r.mimeType]),R=`${null==i?void 0:i.name}-${I}`,{receiver:k,components:F}=(0,H.useMemo)(()=>{if("react"!==I)return{receiver:new ut,components:null};{let r=new dt,d=i||em,p=new Map;return d&&d.elements.forEach(r=>{let i=_t(r.component);p.set(r.tagName,i)}),{receiver:r,components:p}}},[r,i,d]);return(0,H.useEffect)(()=>{function c(r){var i;if(_.current&&r.source===_.current.contentWindow){let d=r.data;if(!d)return;null==(i=null==p?void 0:p(d))||i.catch(r=>{console.error("Error handling UI action result in RemoteDOMResourceRenderer:",r)})}}return window.addEventListener("message",c),()=>window.removeEventListener("message",c)},[p]),(0,H.useEffect)(()=>{let r=w.current;return w.current=null,()=>{null==r||r.close()}},[R]),E?(0,q.jsx)("p",{className:"text-red-500",children:E}):(0,q.jsxs)(q.Fragment,{children:[(0,q.jsx)("iframe",{ref:_,srcDoc:eo,sandbox:"allow-scripts",style:{display:"none"},title:"Remote DOM Sandbox",onLoad:()=>{let p=_.current;if(!p||w.current)return;let E=new Ot(p);w.current=E;let{code:R,error:F}=tt(r);if(F)return void C(F);if(R&&null!=k&&k.connection){let r={code:R,remoteElements:d,useReactRenderer:"react"===I,componentLibrary:null==i?void 0:i.name};E.imports.render(r,k.connection).catch(r=>console.error("Error calling remote render:",r))}}},R),"react"===I&&F?(0,q.jsx)(bt,{receiver:k,components:F}):(0,q.jsx)(Dt,{receiver:k})]})};function Lt(r){var i;return r.contentType?r.contentType:"text/html"===r.mimeType?"rawHtml":"text/uri-list"===r.mimeType?"externalUrl":null!=(i=r.mimeType)&&i.startsWith("application/vnd.mcp-ui.remote-dom")?"remoteDom":void 0}let Ut=r=>{let{resource:i,onUIAction:d,supportedContentTypes:p,htmlProps:_,remoteDomProps:w}=r,E=Lt(i);if(p&&E&&!p.includes(E))return(0,q.jsxs)("p",{className:"text-red-500",children:["Unsupported content type: ",E,"."]});switch(E){case"rawHtml":case"externalUrl":return(0,q.jsx)(Ne,{resource:i,onUIAction:d,..._});case"remoteDom":return(0,q.jsx)(Ct,{resource:i,onUIAction:d,library:(null==w?void 0:w.library)||em,...w});default:return(0,q.jsx)("p",{className:"text-red-500",children:"Unsupported resource type."})}};Ut.displayName="UIResourceRenderer"},0xe09cf4d9:r=>{"use strict";var i={single_source_shortest_paths:function(r,d,p){var _,w,E,C,I,R,k,F={},P={};P[d]=0;var M=i.PriorityQueue.make();for(M.push(d,0);!M.empty();)for(E in w=(_=M.pop()).value,C=_.cost,I=r[w]||{})I.hasOwnProperty(E)&&(R=C+I[E],k=P[E],(void 0===P[E]||k>R)&&(P[E]=R,M.push(E,R),F[E]=w));if(void 0!==p&&void 0===P[p])throw Error("Could not find a path from "+d+" to "+p+".");return F},extract_shortest_path_from_predecessor_list:function(r,i){for(var d=[],p=i;p;)d.push(p),r[p],p=r[p];return d.reverse(),d},find_path:function(r,d,p){var _=i.single_source_shortest_paths(r,d,p);return i.extract_shortest_path_from_predecessor_list(_,p)},PriorityQueue:{make:function(r){var d,p=i.PriorityQueue,_={};for(d in r=r||{},p)p.hasOwnProperty(d)&&(_[d]=p[d]);return _.queue=[],_.sorter=r.sorter||p.default_sorter,_},default_sorter:function(r,i){return r.cost-i.cost},push:function(r,i){this.queue.push({value:r,cost:i}),this.queue.sort(this.sorter)},pop:function(){return this.queue.shift()},empty:function(){return 0===this.queue.length}}};r.exports=i},0x1f5644800:r=>{"use strict";r.exports=function(r){for(var i=[],d=r.length,p=0;p<d;p++){var _=r.charCodeAt(p);if(_>=55296&&_<=56319&&d>p+1){var w=r.charCodeAt(p+1);w>=56320&&w<=57343&&(_=(_-55296)*1024+w-56320+65536,p+=1)}if(_<128){i.push(_);continue}if(_<2048){i.push(_>>6|192),i.push(63&_|128);continue}if(_<55296||_>=57344&&_<65536){i.push(_>>12|224),i.push(_>>6&63|128),i.push(63&_|128);continue}if(_>=65536&&_<=1114111){i.push(_>>18|240),i.push(_>>12&63|128),i.push(_>>6&63|128),i.push(63&_|128);continue}i.push(239,191,189)}return new Uint8Array(i).buffer}},0xf633086:(r,i,d)=>{"use strict";d.d(i,{i:()=>Q,W:()=>createScopedAnimate});let GroupAnimation=class GroupAnimation{constructor(r){this.stop=()=>this.runAll("stop"),this.animations=r.filter(Boolean)}get finished(){return Promise.all(this.animations.map(r=>r.finished))}getAll(r){return this.animations[0][r]}setAll(r,i){for(let d=0;d<this.animations.length;d++)this.animations[d][r]=i}attachTimeline(r){let i=this.animations.map(i=>i.attachTimeline(r));return()=>{i.forEach((r,i)=>{r&&r(),this.animations[i].stop()})}}get time(){return this.getAll("time")}set time(r){this.setAll("time",r)}get speed(){return this.getAll("speed")}set speed(r){this.setAll("speed",r)}get state(){return this.getAll("state")}get startTime(){return this.getAll("startTime")}get duration(){return getMax(this.animations,"duration")}get iterationDuration(){return getMax(this.animations,"iterationDuration")}runAll(r){this.animations.forEach(i=>i[r]())}play(){this.runAll("play")}pause(){this.runAll("pause")}cancel(){this.runAll("cancel")}complete(){this.runAll("complete")}};function getMax(r,i){let d=0;for(let p=0;p<r.length;p++){let _=r[p][i];null!==_&&_>d&&(d=_)}return d}let GroupAnimationWithThen=class GroupAnimationWithThen extends GroupAnimation{then(r,i){return this.finished.finally(r).then(()=>{})}};var p=d(0x237f627ea),_=d(0x19464ab68),w=d(0x1d20571d9),E=d(0x14deba9cd),C=d(0x20e73737a),I=d(0x1ff254d56),R=d(0x1c6a7b003),k=d(0xb7581171),F=d(0x9cf81b81),P=d(0x1076b4948),M=d(0x9a6e620b);function getEasingForSegment(r,i){var d;let p;return(0,M.h)(r)?r[d=r.length,((i-0)%(p=d-0)+p)%p+0]:r}var N=d(0x1eea6fd0),D=d(0x14592786c);function isDOMKeyframes(r){return"object"==typeof r&&!Array.isArray(r)}function resolveSubjects(r,i,d,p){return null==r?[]:"string"==typeof r&&isDOMKeyframes(i)?(0,D.K)(r,d,p):r instanceof NodeList?Array.from(r):Array.isArray(r)?r.filter(r=>null!=r):[r]}function calculateRepeatDuration(r,i,d){return r*(i+1)}function calcNextTime(r,i,d,p){return"number"==typeof i?i:i.startsWith("-")||i.startsWith("+")?Math.max(0,r+parseFloat(i)):"<"===i?d:i.startsWith("<")?Math.max(0,d+parseFloat(i.slice(1))):p.get(i)??r}var V=d(0x1f195998);function eraseKeyframes(r,i,d){for(let _=0;_<r.length;_++){let w=r[_];w.at>i&&w.at<d&&((0,p.Ai)(r,w),_--)}}function addKeyframes(r,i,d,p,_,w){eraseKeyframes(r,_,w);for(let E=0;E<i.length;E++)r.push({value:i[E],at:(0,V.k)(_,w,p[E]),easing:getEasingForSegment(d,E)})}function normalizeTimes(r,i){for(let d=0;d<r.length;d++)r[d]=r[d]/(i+1)}function compareByTime(r,i){return r.at!==i.at?r.at-i.at:null===r.value?1:null===i.value?-1:0}function createAnimationsFromSequence(r,{defaultTransition:i={},...d}={},p,_){let w=i.duration||.3,M=new Map,D=new Map,V={},z=new Map,j=0,$=0,G=0;for(let d=0;d<r.length;d++){let M=r[d];if("string"==typeof M){z.set(M,$);continue}if(!Array.isArray(M)){z.set(M.name,calcNextTime($,M.at,j,z));continue}let[N,q,H={}]=M;void 0!==H.at&&($=calcNextTime($,H.at,j,z));let Y=0,resolveValueSequence=(r,d,p,k=0,M=0)=>{let N=keyframesAsList(r),{delay:D=0,times:V=(0,E.Z)(N),type:z=i.type||"keyframes",repeat:j,repeatType:q,repeatDelay:H=0,...K}=d,{ease:X=i.ease||"easeOut",duration:Q}=d,ee="function"==typeof D?D(k,M):D,er=N.length,ea=(0,C.W)(z)?z:_?.[z||"keyframes"];if(er<=2&&ea){let r=100;2===er&&isNumberKeyframesArray(N)&&(r=Math.abs(N[1]-N[0]));let d={...i,...K};void 0!==Q&&(d.duration=(0,F.f)(Q));let p=(0,I.X)(d,r,ea);X=p.ease,Q=p.duration}Q??(Q=w);let en=$+ee;1===V.length&&0===V[0]&&(V[1]=1);let ei=V.length-N.length;if(ei>0&&(0,R.f)(V,ei),1===N.length&&N.unshift(null),j){(0,P.V)(j<20,"Repeat count too high, must be less than 20","repeat-count-high"),Q=calculateRepeatDuration(Q,j);let r=[...N],i=[...V],d=[...X=Array.isArray(X)?[...X]:[X]];for(let p=0;p<j;p++){N.push(...r);for(let _=0;_<r.length;_++)V.push(i[_]+(p+1)),X.push(0===_?"linear":getEasingForSegment(d,_-1))}normalizeTimes(V,j)}let es=en+Q;addKeyframes(p,N,X,V,en,es),Y=Math.max(ee+Q,Y),G=Math.max(es,G)};if((0,k.S)(N))resolveValueSequence(q,H,getValueSequence("default",getSubjectSequence(N,D)));else{let r=resolveSubjects(N,q,p,V),i=r.length;for(let d=0;d<i;d++){let p=getSubjectSequence(r[d],D);for(let r in q)resolveValueSequence(q[r],getValueTransition(H,r),getValueSequence(r,p),d,i)}}j=$,$+=Y}return D.forEach((r,p)=>{for(let _ in r){let w=r[_];w.sort(compareByTime);let E=[],C=[],I=[];for(let r=0;r<w.length;r++){let{at:i,value:d,easing:p}=w[r];E.push(d),C.push((0,N.q)(0,G,i)),I.push(p||"easeOut")}0!==C[0]&&(C.unshift(0),E.unshift(E[0]),I.unshift("easeInOut")),1!==C[C.length-1]&&(C.push(1),E.push(null)),M.has(p)||M.set(p,{keyframes:{},transition:{}});let R=M.get(p);R.keyframes[_]=E;let{type:k,...F}=i;R.transition[_]={...F,duration:G,ease:I,times:C,...d}}}),M}function getSubjectSequence(r,i){return i.has(r)||i.set(r,{}),i.get(r)}function getValueSequence(r,i){return i[r]||(i[r]=[]),i[r]}function keyframesAsList(r){return Array.isArray(r)?r:[r]}function getValueTransition(r,i){return r&&r[i]?{...r,...r[i]}:{...r}}let isNumber=r=>"number"==typeof r,isNumberKeyframesArray=r=>r.every(isNumber);var z=d(0x18717355),j=d(0x2390b2946),$=d(0x1aeb52a67),G=d(0x1d5605eb8),q=d(0x6c510d0d),H=d(0x456239df),Y=d(0x489c0276),K=d(0x13d06e617),X=d(0x41d4c320);function isObjectKey(r,i){return r in i}let ObjectVisualElement=class ObjectVisualElement extends X.BX{constructor(){super(...arguments),this.type="object"}readValueFromInstance(r,i){if(isObjectKey(i,r)){let d=r[i];if("string"==typeof d||"number"==typeof d)return d}}getBaseTargetFromProps(){}removeValueFromRenderState(r,i){delete i.output[r]}measureInstanceViewportBox(){return(0,K.ge)()}build(r,i){Object.assign(r.output,i)}renderInstance(r,{output:i}){Object.assign(r,i)}sortInstanceNodePosition(){return 0}};function createDOMVisualElement(r){let i={presenceContext:null,props:{},visualState:{renderState:{transform:{},transformOrigin:{},style:{},vars:{},attrs:{}},latestValues:{}}},d=(0,G.x)(r)&&!(0,q.h)(r)?new H.l(i):new Y.M(i);d.mount(r),j.C.set(r,d)}function createObjectVisualElement(r){let i=new ObjectVisualElement({presenceContext:null,props:{},visualState:{renderState:{output:{}},latestValues:{}}});i.mount(r),j.C.set(r,i)}function isSingleValue(r,i){return(0,k.S)(r)||"number"==typeof r||"string"==typeof r&&!isDOMKeyframes(i)}function animateSubject(r,i,d,p){let _=[];if(isSingleValue(r,i))_.push((0,z.z)(r,isDOMKeyframes(i)&&i.default||i,d&&d.default||d));else{if(null==r)return _;let w=resolveSubjects(r,i,p),E=w.length;(0,P.V)(!!E,"No valid elements provided.","no-valid-elements");for(let r=0;r<E;r++){let p=w[r],C=p instanceof Element?createDOMVisualElement:createObjectVisualElement;j.C.has(p)||C(p);let I=j.C.get(p),R={...d};"delay"in R&&"function"==typeof R.delay&&(R.delay=R.delay(r,E)),_.push(...(0,$.$)(I,{...i,transition:R},{}))}}return _}function animateSequence(r,i,d){let p=[];return createAnimationsFromSequence(r.map(r=>{if(Array.isArray(r)&&"function"==typeof r[0]){let i=r[0],d=(0,_.OQ)(0);return(d.on("change",i),1===r.length)?[d,[0,1]]:2===r.length?[d,[0,1],r[1]]:[d,r[1],r[2]]}return r}),i,d,{spring:w.o}).forEach(({keyframes:r,transition:i},d)=>{p.push(...animateSubject(d,r,i))}),p}function isSequence(r){return Array.isArray(r)&&r.some(Array.isArray)}function createScopedAnimate(r={}){let{scope:i,reduceMotion:d}=r;return function(r,_,w){let E,C=[];if(isSequence(r))C=animateSequence(r,void 0!==d?{reduceMotion:d,..._}:_,i);else{let{onComplete:p,...I}=w||{};"function"==typeof p&&(E=p),C=animateSubject(r,_,void 0!==d?{reduceMotion:d,...I}:I,i)}let I=new GroupAnimationWithThen(C);return E&&I.finished.then(E),i&&(i.animations.push(I),I.finished.then(()=>{(0,p.Ai)(i.animations,I)})),I}}let Q=createScopedAnimate()},0x18e3ee0e4:(r,i,d)=>{"use strict";d.d(i,{l:()=>useAnimate});var p=d(0xbad225b5),_=d(0x218c688eb);function useUnmountEffect(r){return(0,p.useEffect)(()=>()=>r(),[])}var w=d(0x44cac612),E=d(0x1b4a8c568),C=d(0x2493e5df);function useReducedMotion(){E.r.current||(0,C.Uu)();let[r]=(0,p.useState)(E.O.current);return r}function useReducedMotionConfig(){let r=useReducedMotion(),{reducedMotion:i}=(0,p.useContext)(w.Q);return"never"!==i&&("always"===i||r)}var I=d(0xf633086);function useAnimate(){let r=(0,_.M)(()=>({current:null,animations:[]})),i=useReducedMotionConfig()??void 0,d=(0,p.useMemo)(()=>(0,I.W)({scope:r,reduceMotion:i}),[r,i]);return useUnmountEffect(()=>{r.animations.forEach(r=>r.stop()),r.animations.length=0}),[r,d]}},0x24f54b9b2:(r,i,d)=>{"use strict";d.d(i,{x:()=>F});var p=d(0x1d3a4ced9),_=d(0x1076b4948),w=d(0xbad225b5),E=d(0x1cf81f71d),C=d(0x1cefa8f4c),I=d(0x218c688eb),R=d(0x1f195998),k=d(0x237f627ea);function checkReorder(r,i,d,p){if(!p)return r;let _=r.findIndex(r=>r.value===i);if(-1===_)return r;let w=p>0?1:-1,E=r[_+w];if(!E)return r;let C=r[_],I=E.layout,F=(0,R.k)(I.min,I.max,.5);return 1===w&&C.layout.max+d>F||-1===w&&C.layout.min+d<F?(0,k.Pe)(r,_,_+w):r}function ReorderGroupComponent({children:r,as:i="ul",axis:d="y",onReorder:R,values:k,...F},P){let M=(0,I.M)(()=>C.P[i]),N=[],D=(0,w.useRef)(!1),V=(0,w.useRef)(null);(0,_.V)(!!k,"Reorder.Group must be provided a values prop","reorder-values"),(0,w.useEffect)(()=>{D.current=!1});let z={overflowAnchor:"none",...F.style};return(0,p.jsx)(M,{...F,style:z,ref:r=>{V.current=r,"function"==typeof P?P(r):P&&(P.current=r)},ignoreStrict:!0,children:(0,p.jsx)(E.T.Provider,{value:{axis:d,groupRef:V,registerItem:(r,i)=>{let p=N.findIndex(i=>r===i.value);-1!==p?N[p].layout=i[d]:N.push({value:r,layout:i[d]}),N.sort(compareMin)},updateOrder:(r,i,d)=>{if(D.current)return;let p=checkReorder(N,r,i,d);N!==p&&(D.current=!0,R(p.map(getValue).filter(r=>-1!==k.indexOf(r))))}},children:r})})}let F=(0,w.forwardRef)(ReorderGroupComponent);function getValue(r){return r.value}function compareMin(r,i){return r.layout.min-i.layout.min}},0xc30f5ec6:(r,i,d)=>{"use strict";d.d(i,{N:()=>V});var p=d(0x1d3a4ced9),_=d(0xb7581171),w=d(0x1076b4948),E=d(0xbad225b5),C=d(0x1cf81f71d),I=d(0x1cefa8f4c),R=d(0x218c688eb),k=d(0x6c771e79),F=d(0x2388e3f8c);let P=new Set(["auto","scroll"]),M=new WeakMap,N=new WeakMap,D=null;function resetAutoScrollState(){if(D){let r=findScrollableAncestor(D,"y");r&&(N.delete(r),M.delete(r));let i=findScrollableAncestor(D,"x");i&&i!==r&&(N.delete(i),M.delete(i)),D=null}}function isScrollableElement(r,i){let d=getComputedStyle(r),p="x"===i?d.overflowX:d.overflowY,_=r===document.body||r===document.documentElement;return P.has(p)||_}function findScrollableAncestor(r,i){let d=r?.parentElement;for(;d;){if(isScrollableElement(d,i))return d;d=d.parentElement}return null}function getScrollAmount(r,i,d){let p=i.getBoundingClientRect(),_="x"===d?Math.max(0,p.left):Math.max(0,p.top),w="x"===d?Math.min(window.innerWidth,p.right):Math.min(window.innerHeight,p.bottom),E=r-_,C=w-r;if(E<50){let r=1-E/50;return{amount:-25*r*r,edge:"start"}}if(C<50){let r=1-C/50;return{amount:25*r*r,edge:"end"}}return{amount:0,edge:null}}function autoScrollIfNeeded(r,i,d,p){if(!r)return;D=r;let _=findScrollableAncestor(r,d);if(!_)return;let{amount:w,edge:E}=getScrollAmount(i-("x"===d?window.scrollX:window.scrollY),_,d);if(null===E){N.delete(_),M.delete(_);return}let C=N.get(_),I=_===document.body||_===document.documentElement;if(C!==E){if(!("start"===E&&p<0||"end"===E&&p>0))return;N.set(_,E);let r="x"===d?_.scrollWidth-(I?window.innerWidth:_.clientWidth):_.scrollHeight-(I?window.innerHeight:_.clientHeight);M.set(_,r)}if(w>0){let r=M.get(_);if(("x"===d?I?window.scrollX:_.scrollLeft:I?window.scrollY:_.scrollTop)>=r)return}"x"===d?I?window.scrollBy({left:w}):_.scrollLeft+=w:I?window.scrollBy({top:w}):_.scrollTop+=w}function useDefaultMotionValue(r,i=0){return(0,_.S)(r)?r:(0,k.d)(i)}function ReorderItemComponent({children:r,style:i={},value:d,as:_="li",onDrag:k,onDragEnd:P,layout:M=!0,...N},D){let V=(0,R.M)(()=>I.P[_]),z=(0,E.useContext)(C.T),j={x:useDefaultMotionValue(i.x),y:useDefaultMotionValue(i.y)},$=(0,F.G)([j.x,j.y],([r,i])=>r||i?1:"unset");(0,w.V)(!!z,"Reorder.Item must be a child of Reorder.Group","reorder-item-child");let{axis:G,registerItem:q,updateOrder:H,groupRef:Y}=z;return(0,p.jsx)(V,{drag:G,...N,dragSnapToOrigin:!0,style:{...i,x:j.x,y:j.y,zIndex:$},layout:M,onDrag:(r,i)=>{let{velocity:p,point:_}=i;H(d,j[G].get(),p[G]),autoScrollIfNeeded(Y.current,_[G],G,p[G]),k&&k(r,i)},onDragEnd:(r,i)=>{resetAutoScrollState(),P&&P(r,i)},onLayoutMeasure:r=>{q(d,r)},ref:D,ignoreStrict:!0,children:r})}let V=(0,E.forwardRef)(ReorderItemComponent)},0x1cf81f71d:(r,i,d)=>{"use strict";d.d(i,{T:()=>p});let p=(0,d(0xbad225b5).createContext)(null)},0x1af4ebf4c:(r,i,d)=>{"use strict";d.d(i,{m:()=>useDragControls});var p=d(0x218c688eb);let DragControls=class DragControls{constructor(){this.componentControls=new Set}subscribe(r){return this.componentControls.add(r),()=>this.componentControls.delete(r)}start(r,i){this.componentControls.forEach(d=>{d.start(r.nativeEvent||r,i)})}cancel(){this.componentControls.forEach(r=>{r.cancel()})}stop(){this.componentControls.forEach(r=>{r.stop()})}};let createDragControls=()=>new DragControls;function useDragControls(){return(0,p.M)(createDragControls)}},0x6c771e79:(r,i,d)=>{"use strict";d.d(i,{d:()=>useMotionValue});var p=d(0x19464ab68),_=d(0xbad225b5),w=d(0x44cac612),E=d(0x218c688eb);function useMotionValue(r){let i=(0,E.M)(()=>(0,p.OQ)(r)),{isStatic:d}=(0,_.useContext)(w.Q);if(d){let[,d]=(0,_.useState)(r);(0,_.useEffect)(()=>i.on("change",d),[])}return i}},0x2388e3f8c:(r,i,d)=>{"use strict";d.d(i,{G:()=>useTransform});var p=d(0xa6431895);function transform(...r){let i=!Array.isArray(r[0]),d=i?0:-1,_=r[0+d],w=r[1+d],E=r[2+d],C=r[3+d],I=(0,p.G)(w,E,C);return i?I(_):I}var _=d(0x218c688eb),w=d(0xe543721),E=d(0x84b95480),C=d(0x6c771e79);function useCombineMotionValues(r,i){let d=(0,C.d)(i()),updateValue=()=>d.set(i());return updateValue(),(0,E.E)(()=>{let scheduleUpdate=()=>w.Gt.preRender(updateValue,!1,!0),i=r.map(r=>r.on("change",scheduleUpdate));return()=>{i.forEach(r=>r()),(0,w.WG)(updateValue)}}),d}var I=d(0x19464ab68);function useComputed(r){I.bt.current=[],r();let i=useCombineMotionValues(I.bt.current,r);return I.bt.current=void 0,i}function useTransform(r,i,d,p){if("function"==typeof r)return useComputed(r);if(void 0!==d&&!Array.isArray(d)&&"function"!=typeof i)return useMapTransform(r,i,d,p);let _="function"==typeof i?i:transform(i,d,p);return Array.isArray(r)?useListTransform(r,_):useListTransform([r],([r])=>_(r))}function useListTransform(r,i){let d=(0,_.M)(()=>[]);return useCombineMotionValues(r,()=>{d.length=0;let p=r.length;for(let i=0;i<p;i++)d[i]=r[i].get();return i(d)})}function useMapTransform(r,i,d,p){let w=(0,_.M)(()=>Object.keys(d)),E=(0,_.M)(()=>({}));for(let _ of w)E[_]=useTransform(r,i,d[_],p);return E}},0x43e307f2:(r,i,d)=>{let p=d(0xffac0b8c),_=d(0x151576334),w=d(0x10f7a5ace),E=d(0x15ba384d);function renderCanvas(r,i,d,w,E){let C=[].slice.call(arguments,1),I=C.length,R="function"==typeof C[I-1];if(!R&&!p())throw Error("Callback required as last argument");if(R){if(I<2)throw Error("Too few arguments provided");2===I?(E=d,d=i,i=w=void 0):3===I&&(i.getContext&&void 0===E?(E=w,w=void 0):(E=w,w=d,d=i,i=void 0))}else{if(I<1)throw Error("Too few arguments provided");return 1===I?(d=i,i=w=void 0):2!==I||i.getContext||(w=d,d=i,i=void 0),new Promise(function(p,E){try{let E=_.create(d,w);p(r(E,i,w))}catch(r){E(r)}})}try{let p=_.create(d,w);E(null,r(p,i,w))}catch(r){E(r)}}i.create=_.create,i.toCanvas=renderCanvas.bind(null,w.render),i.toDataURL=renderCanvas.bind(null,w.renderToDataURL),i.toString=renderCanvas.bind(null,function(r,i,d){return E.render(r,d)})},0xffac0b8c:r=>{r.exports=function(){return"function"==typeof Promise&&Promise.prototype&&Promise.prototype.then}},0x23233129c:(r,i,d)=>{let p=d(0x1ba025383).getSymbolSize;i.getRowColCoords=function(r){if(1===r)return[];let i=Math.floor(r/7)+2,d=p(r),_=145===d?26:2*Math.ceil((d-13)/(2*i-2)),w=[d-7];for(let r=1;r<i-1;r++)w[r]=w[r-1]-_;return w.push(6),w.reverse()},i.getPositions=function(r){let d=[],p=i.getRowColCoords(r),_=p.length;for(let r=0;r<_;r++)for(let i=0;i<_;i++)(0!==r||0!==i)&&(0!==r||i!==_-1)&&(r!==_-1||0!==i)&&d.push([p[r],p[i]]);return d}},0x4c110030:(r,i,d)=>{let p=d(0x1a393a399),_=["0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"," ","$","%","*","+","-",".","/",":"];function AlphanumericData(r){this.mode=p.ALPHANUMERIC,this.data=r}AlphanumericData.getBitsLength=function(r){return 11*Math.floor(r/2)+r%2*6},AlphanumericData.prototype.getLength=function(){return this.data.length},AlphanumericData.prototype.getBitsLength=function(){return AlphanumericData.getBitsLength(this.data.length)},AlphanumericData.prototype.write=function(r){let i;for(i=0;i+2<=this.data.length;i+=2){let d=45*_.indexOf(this.data[i]);d+=_.indexOf(this.data[i+1]),r.put(d,11)}this.data.length%2&&r.put(_.indexOf(this.data[i]),6)},r.exports=AlphanumericData},0x1f323624e:r=>{function BitBuffer(){this.buffer=[],this.length=0}BitBuffer.prototype={get:function(r){let i=Math.floor(r/8);return(this.buffer[i]>>>7-r%8&1)==1},put:function(r,i){for(let d=0;d<i;d++)this.putBit((r>>>i-d-1&1)==1)},getLengthInBits:function(){return this.length},putBit:function(r){let i=Math.floor(this.length/8);this.buffer.length<=i&&this.buffer.push(0),r&&(this.buffer[i]|=128>>>this.length%8),this.length++}},r.exports=BitBuffer},0x3e513ccd:r=>{function BitMatrix(r){if(!r||r<1)throw Error("BitMatrix size must be defined and greater than 0");this.size=r,this.data=new Uint8Array(r*r),this.reservedBit=new Uint8Array(r*r)}BitMatrix.prototype.set=function(r,i,d,p){let _=r*this.size+i;this.data[_]=d,p&&(this.reservedBit[_]=!0)},BitMatrix.prototype.get=function(r,i){return this.data[r*this.size+i]},BitMatrix.prototype.xor=function(r,i,d){this.data[r*this.size+i]^=d},BitMatrix.prototype.isReserved=function(r,i){return this.reservedBit[r*this.size+i]},r.exports=BitMatrix},0x4e9e1d0b:(r,i,d)=>{let p=d(0x1f5644800),_=d(0x1a393a399);function ByteData(r){this.mode=_.BYTE,this.data=new Uint8Array(p(r))}ByteData.getBitsLength=function(r){return 8*r},ByteData.prototype.getLength=function(){return this.data.length},ByteData.prototype.getBitsLength=function(){return ByteData.getBitsLength(this.data.length)},ByteData.prototype.write=function(r){for(let i=0,d=this.data.length;i<d;i++)r.put(this.data[i],8)},r.exports=ByteData},0x9828343b:(r,i,d)=>{let p=d(0xefaf1aa8),_=[1,1,1,1,1,1,1,1,1,1,2,2,1,2,2,4,1,2,4,4,2,4,4,4,2,4,6,5,2,4,6,6,2,5,8,8,4,5,8,8,4,5,8,11,4,8,10,11,4,9,12,16,4,9,16,16,6,10,12,18,6,10,17,16,6,11,16,19,6,13,18,21,7,14,21,25,8,16,20,25,8,17,23,25,9,17,23,34,9,18,25,30,10,20,27,32,12,21,29,35,12,23,34,37,12,25,34,40,13,26,35,42,14,28,38,45,15,29,40,48,16,31,43,51,17,33,45,54,18,35,48,57,19,37,51,60,19,38,53,63,20,40,56,66,21,43,59,70,22,45,62,74,24,47,65,77,25,49,68,81],w=[7,10,13,17,10,16,22,28,15,26,36,44,20,36,52,64,26,48,72,88,36,64,96,112,40,72,108,130,48,88,132,156,60,110,160,192,72,130,192,224,80,150,224,264,96,176,260,308,104,198,288,352,120,216,320,384,132,240,360,432,144,280,408,480,168,308,448,532,180,338,504,588,196,364,546,650,224,416,600,700,224,442,644,750,252,476,690,816,270,504,750,900,300,560,810,960,312,588,870,1050,336,644,952,1110,360,700,1020,1200,390,728,1050,1260,420,784,1140,1350,450,812,1200,1440,480,868,1290,1530,510,924,1350,1620,540,980,1440,1710,570,1036,1530,1800,570,1064,1590,1890,600,1120,1680,1980,630,1204,1770,2100,660,1260,1860,2220,720,1316,1950,2310,750,1372,2040,2430];i.getBlocksCount=function(r,i){switch(i){case p.L:return _[(r-1)*4+0];case p.M:return _[(r-1)*4+1];case p.Q:return _[(r-1)*4+2];case p.H:return _[(r-1)*4+3];default:return}},i.getTotalCodewordsCount=function(r,i){switch(i){case p.L:return w[(r-1)*4+0];case p.M:return w[(r-1)*4+1];case p.Q:return w[(r-1)*4+2];case p.H:return w[(r-1)*4+3];default:return}}},0xefaf1aa8:(r,i)=>{function fromString(r){if("string"!=typeof r)throw Error("Param is not a string");switch(r.toLowerCase()){case"l":case"low":return i.L;case"m":case"medium":return i.M;case"q":case"quartile":return i.Q;case"h":case"high":return i.H;default:throw Error("Unknown EC Level: "+r)}}i.L={bit:1},i.M={bit:0},i.Q={bit:3},i.H={bit:2},i.isValid=function(r){return r&&void 0!==r.bit&&r.bit>=0&&r.bit<4},i.from=function(r,d){if(i.isValid(r))return r;try{return fromString(r)}catch{return d}}},0xb26c82e5:(r,i,d)=>{let p=d(0x1ba025383).getSymbolSize;i.getPositions=function(r){let i=p(r);return[[0,0],[i-7,0],[0,i-7]]}},0x168bd417c:(r,i,d)=>{let p=d(0x1ba025383),_=p.getBCHDigit(1335);i.getEncodedBits=function(r,i){let d=r.bit<<3|i,w=d<<10;for(;p.getBCHDigit(w)-_>=0;)w^=1335<<p.getBCHDigit(w)-_;return(d<<10|w)^21522}},0xcc0da3de:(r,i)=>{let d=new Uint8Array(512),p=new Uint8Array(256),_=1;for(let r=0;r<255;r++)d[r]=_,p[_]=r,256&(_<<=1)&&(_^=285);for(let r=255;r<512;r++)d[r]=d[r-255];i.log=function(r){if(r<1)throw Error("log("+r+")");return p[r]},i.exp=function(r){return d[r]},i.mul=function(r,i){return 0===r||0===i?0:d[p[r]+p[i]]}},0x1ece03a24:(r,i,d)=>{let p=d(0x1a393a399),_=d(0x1ba025383);function KanjiData(r){this.mode=p.KANJI,this.data=r}KanjiData.getBitsLength=function(r){return 13*r},KanjiData.prototype.getLength=function(){return this.data.length},KanjiData.prototype.getBitsLength=function(){return KanjiData.getBitsLength(this.data.length)},KanjiData.prototype.write=function(r){let i;for(i=0;i<this.data.length;i++){let d=_.toSJIS(this.data[i]);if(d>=33088&&d<=40956)d-=33088;else if(d>=57408&&d<=60351)d-=49472;else throw Error("Invalid SJIS character: "+this.data[i]+`
Make sure your charset is UTF-8`);d=(d>>>8&255)*192+(255&d),r.put(d,13)}},r.exports=KanjiData},0x560c852d:(r,i)=>{i.Patterns={PATTERN000:0,PATTERN001:1,PATTERN010:2,PATTERN011:3,PATTERN100:4,PATTERN101:5,PATTERN110:6,PATTERN111:7};function getMaskAt(r,d,p){switch(r){case i.Patterns.PATTERN000:return(d+p)%2==0;case i.Patterns.PATTERN001:return d%2==0;case i.Patterns.PATTERN010:return p%3==0;case i.Patterns.PATTERN011:return(d+p)%3==0;case i.Patterns.PATTERN100:return(Math.floor(d/2)+Math.floor(p/3))%2==0;case i.Patterns.PATTERN101:return d*p%2+d*p%3==0;case i.Patterns.PATTERN110:return(d*p%2+d*p%3)%2==0;case i.Patterns.PATTERN111:return(d*p%3+(d+p)%2)%2==0;default:throw Error("bad maskPattern:"+r)}}i.isValid=function(r){return null!=r&&""!==r&&!isNaN(r)&&r>=0&&r<=7},i.from=function(r){return i.isValid(r)?parseInt(r,10):void 0},i.getPenaltyN1=function(r){let i=r.size,d=0,p=0,_=0,w=null,E=null;for(let C=0;C<i;C++){p=_=0,w=E=null;for(let I=0;I<i;I++){let i=r.get(C,I);i===w?p++:(p>=5&&(d+=3+(p-5)),w=i,p=1),(i=r.get(I,C))===E?_++:(_>=5&&(d+=3+(_-5)),E=i,_=1)}p>=5&&(d+=3+(p-5)),_>=5&&(d+=3+(_-5))}return d},i.getPenaltyN2=function(r){let i=r.size,d=0;for(let p=0;p<i-1;p++)for(let _=0;_<i-1;_++){let i=r.get(p,_)+r.get(p,_+1)+r.get(p+1,_)+r.get(p+1,_+1);(4===i||0===i)&&d++}return 3*d},i.getPenaltyN3=function(r){let i=r.size,d=0,p=0,_=0;for(let w=0;w<i;w++){p=_=0;for(let E=0;E<i;E++)p=p<<1&2047|r.get(w,E),E>=10&&(1488===p||93===p)&&d++,_=_<<1&2047|r.get(E,w),E>=10&&(1488===_||93===_)&&d++}return 40*d},i.getPenaltyN4=function(r){let i=0,d=r.data.length;for(let p=0;p<d;p++)i+=r.data[p];return 10*Math.abs(Math.ceil(100*i/d/5)-10)},i.applyMask=function(r,i){let d=i.size;for(let p=0;p<d;p++)for(let _=0;_<d;_++)i.isReserved(_,p)||i.xor(_,p,getMaskAt(r,_,p))},i.getBestMask=function(r,d){let p=Object.keys(i.Patterns).length,_=0,w=1/0;for(let E=0;E<p;E++){d(E),i.applyMask(E,r);let p=i.getPenaltyN1(r)+i.getPenaltyN2(r)+i.getPenaltyN3(r)+i.getPenaltyN4(r);i.applyMask(E,r),p<w&&(w=p,_=E)}return _}},0x1a393a399:(r,i,d)=>{let p=d(0x22b000023),_=d(0x16a863b9d);function fromString(r){if("string"!=typeof r)throw Error("Param is not a string");switch(r.toLowerCase()){case"numeric":return i.NUMERIC;case"alphanumeric":return i.ALPHANUMERIC;case"kanji":return i.KANJI;case"byte":return i.BYTE;default:throw Error("Unknown mode: "+r)}}i.NUMERIC={id:"Numeric",bit:1,ccBits:[10,12,14]},i.ALPHANUMERIC={id:"Alphanumeric",bit:2,ccBits:[9,11,13]},i.BYTE={id:"Byte",bit:4,ccBits:[8,16,16]},i.KANJI={id:"Kanji",bit:8,ccBits:[8,10,12]},i.MIXED={bit:-1},i.getCharCountIndicator=function(r,i){if(!r.ccBits)throw Error("Invalid mode: "+r);if(!p.isValid(i))throw Error("Invalid version: "+i);return i>=1&&i<10?r.ccBits[0]:i<27?r.ccBits[1]:r.ccBits[2]},i.getBestModeForData=function(r){return _.testNumeric(r)?i.NUMERIC:_.testAlphanumeric(r)?i.ALPHANUMERIC:_.testKanji(r)?i.KANJI:i.BYTE},i.toString=function(r){if(r&&r.id)return r.id;throw Error("Invalid mode")},i.isValid=function(r){return r&&r.bit&&r.ccBits},i.from=function(r,d){if(i.isValid(r))return r;try{return fromString(r)}catch{return d}}},0xe1038a6c:(r,i,d)=>{let p=d(0x1a393a399);function NumericData(r){this.mode=p.NUMERIC,this.data=r.toString()}NumericData.getBitsLength=function(r){return 10*Math.floor(r/3)+(r%3?r%3*3+1:0)},NumericData.prototype.getLength=function(){return this.data.length},NumericData.prototype.getBitsLength=function(){return NumericData.getBitsLength(this.data.length)},NumericData.prototype.write=function(r){let i,d;for(i=0;i+3<=this.data.length;i+=3)d=parseInt(this.data.substr(i,3),10),r.put(d,10);let p=this.data.length-i;p>0&&(d=parseInt(this.data.substr(i),10),r.put(d,3*p+1))},r.exports=NumericData},0x179edb2b0:(r,i,d)=>{let p=d(0xcc0da3de);i.mul=function(r,i){let d=new Uint8Array(r.length+i.length-1);for(let _=0;_<r.length;_++)for(let w=0;w<i.length;w++)d[_+w]^=p.mul(r[_],i[w]);return d},i.mod=function(r,i){let d=new Uint8Array(r);for(;d.length-i.length>=0;){let r=d[0];for(let _=0;_<i.length;_++)d[_]^=p.mul(i[_],r);let _=0;for(;_<d.length&&0===d[_];)_++;d=d.slice(_)}return d},i.generateECPolynomial=function(r){let d=new Uint8Array([1]);for(let _=0;_<r;_++)d=i.mul(d,new Uint8Array([1,p.exp(_)]));return d}},0x151576334:(r,i,d)=>{let p=d(0x1ba025383),_=d(0xefaf1aa8),w=d(0x1f323624e),E=d(0x3e513ccd),C=d(0x23233129c),I=d(0xb26c82e5),R=d(0x560c852d),k=d(0x9828343b),F=d(0xa245cca5),P=d(0x29a7ca56),M=d(0x168bd417c),N=d(0x1a393a399),D=d(0xe09180b0);function setupFinderPattern(r,i){let d=r.size,p=I.getPositions(i);for(let i=0;i<p.length;i++){let _=p[i][0],w=p[i][1];for(let i=-1;i<=7;i++)if(!(_+i<=-1)&&!(d<=_+i))for(let p=-1;p<=7;p++)w+p<=-1||d<=w+p||(i>=0&&i<=6&&(0===p||6===p)||p>=0&&p<=6&&(0===i||6===i)||i>=2&&i<=4&&p>=2&&p<=4?r.set(_+i,w+p,!0,!0):r.set(_+i,w+p,!1,!0))}}function setupTimingPattern(r){let i=r.size;for(let d=8;d<i-8;d++){let i=d%2==0;r.set(d,6,i,!0),r.set(6,d,i,!0)}}function setupAlignmentPattern(r,i){let d=C.getPositions(i);for(let i=0;i<d.length;i++){let p=d[i][0],_=d[i][1];for(let i=-2;i<=2;i++)for(let d=-2;d<=2;d++)-2===i||2===i||-2===d||2===d||0===i&&0===d?r.set(p+i,_+d,!0,!0):r.set(p+i,_+d,!1,!0)}}function setupVersionInfo(r,i){let d,p,_,w=r.size,E=P.getEncodedBits(i);for(let i=0;i<18;i++)d=Math.floor(i/3),p=i%3+w-8-3,_=(E>>i&1)==1,r.set(d,p,_,!0),r.set(p,d,_,!0)}function setupFormatInfo(r,i,d){let p,_,w=r.size,E=M.getEncodedBits(i,d);for(p=0;p<15;p++)_=(E>>p&1)==1,p<6?r.set(p,8,_,!0):p<8?r.set(p+1,8,_,!0):r.set(w-15+p,8,_,!0),p<8?r.set(8,w-p-1,_,!0):p<9?r.set(8,15-p-1+1,_,!0):r.set(8,15-p-1,_,!0);r.set(w-8,8,1,!0)}function setupData(r,i){let d=r.size,p=-1,_=d-1,w=7,E=0;for(let C=d-1;C>0;C-=2)for(6===C&&C--;;){for(let d=0;d<2;d++)if(!r.isReserved(_,C-d)){let p=!1;E<i.length&&(p=(i[E]>>>w&1)==1),r.set(_,C-d,p),-1==--w&&(E++,w=7)}if((_+=p)<0||d<=_){_-=p,p=-p;break}}}function createData(r,i,d){let _=new w;d.forEach(function(i){_.put(i.mode.bit,4),_.put(i.getLength(),N.getCharCountIndicator(i.mode,r)),i.write(_)});let E=(p.getSymbolTotalCodewords(r)-k.getTotalCodewordsCount(r,i))*8;for(_.getLengthInBits()+4<=E&&_.put(0,4);_.getLengthInBits()%8!=0;)_.putBit(0);let C=(E-_.getLengthInBits())/8;for(let r=0;r<C;r++)_.put(r%2?17:236,8);return createCodewords(_,r,i)}function createCodewords(r,i,d){let _,w,E=p.getSymbolTotalCodewords(i),C=E-k.getTotalCodewordsCount(i,d),I=k.getBlocksCount(i,d),R=E%I,P=I-R,M=Math.floor(E/I),N=Math.floor(C/I),D=N+1,V=M-N,z=new F(V),j=0,$=Array(I),G=Array(I),q=0,H=new Uint8Array(r.buffer);for(let r=0;r<I;r++){let i=r<P?N:D;$[r]=H.slice(j,j+i),G[r]=z.encode($[r]),j+=i,q=Math.max(q,i)}let Y=new Uint8Array(E),K=0;for(_=0;_<q;_++)for(w=0;w<I;w++)_<$[w].length&&(Y[K++]=$[w][_]);for(_=0;_<V;_++)for(w=0;w<I;w++)Y[K++]=G[w][_];return Y}function createSymbol(r,i,d,_){let w;if(Array.isArray(r))w=D.fromArray(r);else if("string"==typeof r){let p=i;if(!p){let i=D.rawSplit(r);p=P.getBestVersionForData(i,d)}w=D.fromString(r,p||40)}else throw Error("Invalid data");let C=P.getBestVersionForData(w,d);if(!C)throw Error("The amount of data is too big to be stored in a QR Code");if(i){if(i<C)throw Error(`
The chosen QR Code version cannot contain this amount of data.
Minimum version required to store current data is: `+C+`.
`)}else i=C;let I=createData(i,d,w),k=new E(p.getSymbolSize(i));return setupFinderPattern(k,i),setupTimingPattern(k),setupAlignmentPattern(k,i),setupFormatInfo(k,d,0),i>=7&&setupVersionInfo(k,i),setupData(k,I),isNaN(_)&&(_=R.getBestMask(k,setupFormatInfo.bind(null,k,d))),R.applyMask(_,k),setupFormatInfo(k,d,_),{modules:k,version:i,errorCorrectionLevel:d,maskPattern:_,segments:w}}i.create=function(r,i){let d,w;if(void 0===r||""===r)throw Error("No input text");let E=_.M;return void 0!==i&&(E=_.from(i.errorCorrectionLevel,_.M),d=P.from(i.version),w=R.from(i.maskPattern),i.toSJISFunc&&p.setToSJISFunction(i.toSJISFunc)),createSymbol(r,d,E,w)}},0xa245cca5:(r,i,d)=>{let p=d(0x179edb2b0);function ReedSolomonEncoder(r){this.genPoly=void 0,this.degree=r,this.degree&&this.initialize(this.degree)}ReedSolomonEncoder.prototype.initialize=function(r){this.degree=r,this.genPoly=p.generateECPolynomial(this.degree)},ReedSolomonEncoder.prototype.encode=function(r){if(!this.genPoly)throw Error("Encoder not initialized");let i=new Uint8Array(r.length+this.degree);i.set(r);let d=p.mod(i,this.genPoly),_=this.degree-d.length;if(_>0){let r=new Uint8Array(this.degree);return r.set(d,_),r}return d},r.exports=ReedSolomonEncoder},0x16a863b9d:(r,i)=>{let d="[0-9]+",p="(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+",_="(?:(?![A-Z0-9 $%*+\\-./:]|"+(p=p.replace(/u/g,"\\u"))+`)(?:.|[\r
]))+`;i.KANJI=RegExp(p,"g"),i.BYTE_KANJI=RegExp("[^A-Z0-9 $%*+\\-./:]+","g"),i.BYTE=RegExp(_,"g"),i.NUMERIC=RegExp(d,"g"),i.ALPHANUMERIC=RegExp("[A-Z $%*+\\-./:]+","g");let w=RegExp("^"+p+"$"),E=RegExp("^"+d+"$"),C=RegExp("^[A-Z0-9 $%*+\\-./:]+$");i.testKanji=function(r){return w.test(r)},i.testNumeric=function(r){return E.test(r)},i.testAlphanumeric=function(r){return C.test(r)}},0xe09180b0:(r,i,d)=>{let p=d(0x1a393a399),_=d(0xe1038a6c),w=d(0x4c110030),E=d(0x4e9e1d0b),C=d(0x1ece03a24),I=d(0x16a863b9d),R=d(0x1ba025383),k=d(0xe09cf4d9);function getStringByteLength(r){return unescape(encodeURIComponent(r)).length}function getSegments(r,i,d){let p,_=[];for(;null!==(p=r.exec(d));)_.push({data:p[0],index:p.index,mode:i,length:p[0].length});return _}function getSegmentsFromString(r){let i,d,_=getSegments(I.NUMERIC,p.NUMERIC,r),w=getSegments(I.ALPHANUMERIC,p.ALPHANUMERIC,r);return R.isKanjiModeEnabled()?(i=getSegments(I.BYTE,p.BYTE,r),d=getSegments(I.KANJI,p.KANJI,r)):(i=getSegments(I.BYTE_KANJI,p.BYTE,r),d=[]),_.concat(w,i,d).sort(function(r,i){return r.index-i.index}).map(function(r){return{data:r.data,mode:r.mode,length:r.length}})}function getSegmentBitsLength(r,i){switch(i){case p.NUMERIC:return _.getBitsLength(r);case p.ALPHANUMERIC:return w.getBitsLength(r);case p.KANJI:return C.getBitsLength(r);case p.BYTE:return E.getBitsLength(r)}}function mergeSegments(r){return r.reduce(function(r,i){let d=r.length-1>=0?r[r.length-1]:null;return d&&d.mode===i.mode?r[r.length-1].data+=i.data:r.push(i),r},[])}function buildNodes(r){let i=[];for(let d=0;d<r.length;d++){let _=r[d];switch(_.mode){case p.NUMERIC:i.push([_,{data:_.data,mode:p.ALPHANUMERIC,length:_.length},{data:_.data,mode:p.BYTE,length:_.length}]);break;case p.ALPHANUMERIC:i.push([_,{data:_.data,mode:p.BYTE,length:_.length}]);break;case p.KANJI:i.push([_,{data:_.data,mode:p.BYTE,length:getStringByteLength(_.data)}]);break;case p.BYTE:i.push([{data:_.data,mode:p.BYTE,length:getStringByteLength(_.data)}])}}return i}function buildGraph(r,i){let d={},_={start:{}},w=["start"];for(let E=0;E<r.length;E++){let C=r[E],I=[];for(let r=0;r<C.length;r++){let R=C[r],k=""+E+r;I.push(k),d[k]={node:R,lastCount:0},_[k]={};for(let r=0;r<w.length;r++){let E=w[r];d[E]&&d[E].node.mode===R.mode?(_[E][k]=getSegmentBitsLength(d[E].lastCount+R.length,R.mode)-getSegmentBitsLength(d[E].lastCount,R.mode),d[E].lastCount+=R.length):(d[E]&&(d[E].lastCount=R.length),_[E][k]=getSegmentBitsLength(R.length,R.mode)+4+p.getCharCountIndicator(R.mode,i))}}w=I}for(let r=0;r<w.length;r++)_[w[r]].end=0;return{map:_,table:d}}function buildSingleSegment(r,i){let d,I=p.getBestModeForData(r);if((d=p.from(i,I))!==p.BYTE&&d.bit<I.bit)throw Error('"'+r+'" cannot be encoded with mode '+p.toString(d)+`.
 Suggested mode is: `+p.toString(I));switch(d===p.KANJI&&!R.isKanjiModeEnabled()&&(d=p.BYTE),d){case p.NUMERIC:return new _(r);case p.ALPHANUMERIC:return new w(r);case p.KANJI:return new C(r);case p.BYTE:return new E(r)}}i.fromArray=function(r){return r.reduce(function(r,i){return"string"==typeof i?r.push(buildSingleSegment(i,null)):i.data&&r.push(buildSingleSegment(i.data,i.mode)),r},[])},i.fromString=function(r,d){let p=buildGraph(buildNodes(getSegmentsFromString(r,R.isKanjiModeEnabled())),d),_=k.find_path(p.map,"start","end"),w=[];for(let r=1;r<_.length-1;r++)w.push(p.table[_[r]].node);return i.fromArray(mergeSegments(w))},i.rawSplit=function(r){return i.fromArray(getSegmentsFromString(r,R.isKanjiModeEnabled()))}},0x1ba025383:(r,i)=>{let d,p=[0,26,44,70,100,134,172,196,242,292,346,404,466,532,581,655,733,815,901,991,1085,1156,1258,1364,1474,1588,1706,1828,1921,2051,2185,2323,2465,2611,2761,2876,3034,3196,3362,3532,3706];i.getSymbolSize=function(r){if(!r)throw Error('"version" cannot be null or undefined');if(r<1||r>40)throw Error('"version" should be in range from 1 to 40');return 4*r+17},i.getSymbolTotalCodewords=function(r){return p[r]},i.getBCHDigit=function(r){let i=0;for(;0!==r;)i++,r>>>=1;return i},i.setToSJISFunction=function(r){if("function"!=typeof r)throw Error('"toSJISFunc" is not a valid function.');d=r},i.isKanjiModeEnabled=function(){return void 0!==d},i.toSJIS=function(r){return d(r)}},0x22b000023:(r,i)=>{i.isValid=function(r){return!isNaN(r)&&r>=1&&r<=40}},0x29a7ca56:(r,i,d)=>{let p=d(0x1ba025383),_=d(0x9828343b),w=d(0xefaf1aa8),E=d(0x1a393a399),C=d(0x22b000023),I=p.getBCHDigit(7973);function getBestVersionForDataLength(r,d,p){for(let _=1;_<=40;_++)if(d<=i.getCapacity(_,p,r))return _}function getReservedBitsCount(r,i){return E.getCharCountIndicator(r,i)+4}function getTotalBitsFromDataArray(r,i){let d=0;return r.forEach(function(r){let p=getReservedBitsCount(r.mode,i);d+=p+r.getBitsLength()}),d}function getBestVersionForMixedData(r,d){for(let p=1;p<=40;p++)if(getTotalBitsFromDataArray(r,p)<=i.getCapacity(p,d,E.MIXED))return p}i.from=function(r,i){return C.isValid(r)?parseInt(r,10):i},i.getCapacity=function(r,i,d){if(!C.isValid(r))throw Error("Invalid QR Code version");void 0===d&&(d=E.BYTE);let w=(p.getSymbolTotalCodewords(r)-_.getTotalCodewordsCount(r,i))*8;if(d===E.MIXED)return w;let I=w-getReservedBitsCount(d,r);switch(d){case E.NUMERIC:return Math.floor(I/10*3);case E.ALPHANUMERIC:return Math.floor(I/11*2);case E.KANJI:return Math.floor(I/13);case E.BYTE:default:return Math.floor(I/8)}},i.getBestVersionForData=function(r,i){let d,p=w.from(i,w.M);if(Array.isArray(r)){if(r.length>1)return getBestVersionForMixedData(r,p);if(0===r.length)return 1;d=r[0]}else d=r;return getBestVersionForDataLength(d.mode,d.getLength(),p)},i.getEncodedBits=function(r){if(!C.isValid(r)||r<7)throw Error("Invalid QR Code version");let i=r<<12;for(;p.getBCHDigit(i)-I>=0;)i^=7973<<p.getBCHDigit(i)-I;return r<<12|i}},0x10f7a5ace:(r,i,d)=>{let p=d(0x6f3af2c3);function clearCanvas(r,i,d){r.clearRect(0,0,i.width,i.height),i.style||(i.style={}),i.height=d,i.width=d,i.style.height=d+"px",i.style.width=d+"px"}function getCanvasElement(){try{return document.createElement("canvas")}catch{throw Error("You need to specify a canvas element")}}i.render=function(r,i,d){let _=d,w=i;void 0!==_||i&&i.getContext||(_=i,i=void 0),i||(w=getCanvasElement()),_=p.getOptions(_);let E=p.getImageWidth(r.modules.size,_),C=w.getContext("2d"),I=C.createImageData(E,E);return p.qrToImageData(I.data,r,_),clearCanvas(C,w,E),C.putImageData(I,0,0),w},i.renderToDataURL=function(r,d,p){let _=p;void 0!==_||d&&d.getContext||(_=d,d=void 0),_||(_={});let w=i.render(r,d,_),E=_.type||"image/png",C=_.rendererOpts||{};return w.toDataURL(E,C.quality)}},0x15ba384d:(r,i,d)=>{let p=d(0x6f3af2c3);function getColorAttrib(r,i){let d=r.a/255,p=i+'="'+r.hex+'"';return d<1?p+" "+i+'-opacity="'+d.toFixed(2).slice(1)+'"':p}function svgCmd(r,i,d){let p=r+i;return void 0!==d&&(p+=" "+d),p}function qrToPath(r,i,d){let p="",_=0,w=!1,E=0;for(let C=0;C<r.length;C++){let I=Math.floor(C%i),R=Math.floor(C/i);I||w||(w=!0),r[C]?(E++,C>0&&I>0&&r[C-1]||(p+=w?svgCmd("M",I+d,.5+R+d):svgCmd("m",_,0),_=0,w=!1),I+1<i&&r[C+1]||(p+=svgCmd("h",E),E=0)):_++}return p}i.render=function(r,i,d){let _=p.getOptions(i),w=r.modules.size,E=r.modules.data,C=w+2*_.margin,I=_.color.light.a?"<path "+getColorAttrib(_.color.light,"fill")+' d="M0 0h'+C+"v"+C+'H0z"/>':"",R="<path "+getColorAttrib(_.color.dark,"stroke")+' d="'+qrToPath(E,w,_.margin)+'"/>',k='<svg xmlns="http://www.w3.org/2000/svg" '+(_.width?'width="'+_.width+'" height="'+_.width+'" ':"")+('viewBox="0 0 '+C+" ")+C+'" shape-rendering="crispEdges">'+I+R+`</svg>
`;return"function"==typeof d&&d(null,k),k}},0x6f3af2c3:(r,i)=>{function hex2rgba(r){if("number"==typeof r&&(r=r.toString()),"string"!=typeof r)throw Error("Color should be defined as hex string");let i=r.slice().replace("#","").split("");if(i.length<3||5===i.length||i.length>8)throw Error("Invalid hex color: "+r);(3===i.length||4===i.length)&&(i=Array.prototype.concat.apply([],i.map(function(r){return[r,r]}))),6===i.length&&i.push("F","F");let d=parseInt(i.join(""),16);return{r:d>>24&255,g:d>>16&255,b:d>>8&255,a:255&d,hex:"#"+i.slice(0,6).join("")}}i.getOptions=function(r){r||(r={}),r.color||(r.color={});let i=void 0===r.margin||null===r.margin||r.margin<0?4:r.margin,d=r.width&&r.width>=21?r.width:void 0,p=r.scale||4;return{width:d,scale:d?4:p,margin:i,color:{dark:hex2rgba(r.color.dark||"#000000ff"),light:hex2rgba(r.color.light||"#ffffffff")},type:r.type,rendererOpts:r.rendererOpts||{}}},i.getScale=function(r,i){return i.width&&i.width>=r+2*i.margin?i.width/(r+2*i.margin):i.scale},i.getImageWidth=function(r,d){let p=i.getScale(r,d);return Math.floor((r+2*d.margin)*p)},i.qrToImageData=function(r,d,p){let _=d.modules.size,w=d.modules.data,E=i.getScale(_,p),C=Math.floor((_+2*p.margin)*E),I=p.margin*E,R=[p.color.light,p.color.dark];for(let i=0;i<C;i++)for(let d=0;d<C;d++){let k=(i*C+d)*4,F=p.color.light;i>=I&&d>=I&&i<C-I&&d<C-I&&(F=R[+!!w[Math.floor((i-I)/E)*_+Math.floor((d-I)/E)]]),r[k++]=F.r,r[k++]=F.g,r[k++]=F.b,r[k]=F.a}}},0x11c9c0b6b:(r,i,d)=>{"use strict";d.d(i,{L:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("activity.views.create generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"activity.views.create",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to activity.views.create
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"activityViewsCreateFetcher",key:"createFetcherActivityViewsCreateFetcher",description:"activity.views.create generated fetcher"}},0x1aab3cd34:(r,i,d)=>{"use strict";d.d(i,{W:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("activity.views.delete generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"activity.views.delete",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to activity.views.delete
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"activityViewsDeleteFetcher",key:"createFetcherActivityViewsDeleteFetcher",description:"activity.views.delete generated fetcher"}},0x1ef5858aa:(r,i,d)=>{"use strict";d.d(i,{W:()=>R,h:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I={ViewNotFound:"view_not_found",InvalidArgs:"invalid_args",FeatureNotEnabled:"feature_not_enabled",InvalidName:"invalid_name",NameTooLong:"name_too_long",CannotUseDefaultViewName:"cannot_use_default_view_name",DuplicateName:"duplicate_name",CannotChangeDefaultViewName:"cannot_change_default_view_name",NameRequired:"name_required",CannotUpdateFiltersForDefaultView:"cannot_update_filters_for_default_view"},R=(0,w.A)("activity.views.update generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"activity.views.update",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to activity.views.update
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));R.meta={name:"activityViewsUpdateFetcher",key:"createFetcherActivityViewsUpdateFetcher",description:"activity.views.update generated fetcher"}},0x7d6482fb:(r,i,d)=>{"use strict";d.d(i,{l:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("activity.archive generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"activity.archive",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to activity.archive
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"activityArchiveFetcher",key:"createFetcherActivityArchiveFetcher",description:"activity.archive generated fetcher"}},0x1850461b6:(r,i,d)=>{"use strict";d.d(i,{t:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("activity.clearAll generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"activity.clearAll",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to activity.clearAll
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"activityClearAllFetcher",key:"createFetcherActivityClearAllFetcher",description:"activity.clearAll generated fetcher"}},0x1e228302:(r,i,d)=>{"use strict";d.d(i,{W:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("activity.unarchive generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"activity.unarchive",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to activity.unarchive
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"activityUnarchiveFetcher",key:"createFetcherActivityUnarchiveFetcher",description:"activity.unarchive generated fetcher"}},0x103563187:(r,i,d)=>{"use strict";d.d(i,{p:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("activity.views generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"activity.views",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to activity.views
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"activityViewsFetcher",key:"createFetcherActivityViewsFetcher",description:"activity.views generated fetcher"}},0x1260b6d6f:(r,i,d)=>{"use strict";d.d(i,{x:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("admin.advisor.recommendations.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"admin.advisor.recommendations.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to admin.advisor.recommendations.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"adminAdvisorRecommendationsListFetcher",key:"createFetcherAdminAdvisorRecommendationsListFetcher",description:"admin.advisor.recommendations.list generated fetcher"}},0x56774c4a:(r,i,d)=>{"use strict";d.d(i,{c:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("admin.apps.approved.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"admin.apps.approved.list",args:F,abortSignal:I,reason:R})).then(r=>{p((0,C.XK)(r))}).catch(r=>{(0,E.default)({getState:i}).error(`API call to admin.apps.approved.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"adminAppsApprovedListFetcher",key:"createFetcherAdminAppsApprovedListFetcher",description:"admin.apps.approved.list generated fetcher"}},0x24f86e105:(r,i,d)=>{"use strict";d.d(i,{F:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("admin.apps.installed.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"admin.apps.installed.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to admin.apps.installed.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"adminAppsInstalledListFetcher",key:"createFetcherAdminAppsInstalledListFetcher",description:"admin.apps.installed.list generated fetcher"}},0x2239e9204:(r,i,d)=>{"use strict";d.d(i,{m:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("admin.apps.internal.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"admin.apps.internal.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to admin.apps.internal.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"adminAppsInternalListFetcher",key:"createFetcherAdminAppsInternalListFetcher",description:"admin.apps.internal.list generated fetcher"}},0x16f7bb2f7:(r,i,d)=>{"use strict";d.d(i,{P:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("admin.apps.requests.cancel generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"admin.apps.requests.cancel",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to admin.apps.requests.cancel
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"adminAppsRequestsCancelFetcher",key:"createFetcherAdminAppsRequestsCancelFetcher",description:"admin.apps.requests.cancel generated fetcher"}},0x1afaf879:(r,i,d)=>{"use strict";d.d(i,{Z:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("admin.apps.requests.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"admin.apps.requests.list",args:F,abortSignal:I,reason:R})).then(r=>{p((0,C.XK)(r))}).catch(r=>{(0,E.default)({getState:i}).error(`API call to admin.apps.requests.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"adminAppsRequestsListFetcher",key:"createFetcherAdminAppsRequestsListFetcher",description:"admin.apps.requests.list generated fetcher"}},0x1ece8b190:(r,i,d)=>{"use strict";d.d(i,{G:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("admin.apps.restricted.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"admin.apps.restricted.list",args:F,abortSignal:I,reason:R})).then(r=>{p((0,C.XK)(r))}).catch(r=>{(0,E.default)({getState:i}).error(`API call to admin.apps.restricted.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"adminAppsRestrictedListFetcher",key:"createFetcherAdminAppsRestrictedListFetcher",description:"admin.apps.restricted.list generated fetcher"}},0x2f50ee4b:(r,i,d)=>{"use strict";d.d(i,{b:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("admin.apps.lookup generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"admin.apps.lookup",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to admin.apps.lookup
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"adminAppsLookupFetcher",key:"createFetcherAdminAppsLookupFetcher",description:"admin.apps.lookup generated fetcher"}},0x17c0fb409:(r,i,d)=>{"use strict";d.d(i,{Y:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("admin.functions.permissions.bulkSet generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"admin.functions.permissions.bulkSet",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to admin.functions.permissions.bulkSet
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"adminFunctionsPermissionsBulkSetFetcher",key:"createFetcherAdminFunctionsPermissionsBulkSetFetcher",description:"admin.functions.permissions.bulkSet generated fetcher"}},0x108ee299a:(r,i,d)=>{"use strict";d.d(i,{I:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("admin.functions.permissions.lookup generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"admin.functions.permissions.lookup",args:F,abortSignal:I,reason:R})).then(r=>{p((0,C.XK)(r))}).catch(r=>{(0,E.default)({getState:i}).error(`API call to admin.functions.permissions.lookup
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"adminFunctionsPermissionsLookupFetcher",key:"createFetcherAdminFunctionsPermissionsLookupFetcher",description:"admin.functions.permissions.lookup generated fetcher"}},0x37cf8160:(r,i,d)=>{"use strict";d.d(i,{e:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("admin.functions.permissions.set generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"admin.functions.permissions.set",args:F,abortSignal:I,reason:R})).then(r=>{p((0,C.XK)(r))}).catch(r=>{(0,E.default)({getState:i}).error(`API call to admin.functions.permissions.set
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"adminFunctionsPermissionsSetFetcher",key:"createFetcherAdminFunctionsPermissionsSetFetcher",description:"admin.functions.permissions.set generated fetcher"}},0x1d4e46096:(r,i,d)=>{"use strict";d.d(i,{q:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("admin.functions.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"admin.functions.list",args:F,abortSignal:I,reason:R})).then(r=>{p((0,C.XK)(r))}).catch(r=>{(0,E.default)({getState:i}).error(`API call to admin.functions.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"adminFunctionsListFetcher",key:"createFetcherAdminFunctionsListFetcher",description:"admin.functions.list generated fetcher"}},0x2285a4de7:(r,i,d)=>{"use strict";d.d(i,{D:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("admin.workflows.triggers.types.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"admin.workflows.triggers.types.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to admin.workflows.triggers.types.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"adminWorkflowsTriggersTypesListFetcher",key:"createFetcherAdminWorkflowsTriggersTypesListFetcher",description:"admin.workflows.triggers.types.list generated fetcher"}},0xc81e13df:(r,i,d)=>{"use strict";d.d(i,{p:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("admin.workflows.search generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"admin.workflows.search",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to admin.workflows.search
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"adminWorkflowsSearchFetcher",key:"createFetcherAdminWorkflowsSearchFetcher",description:"admin.workflows.search generated fetcher"}},0x2316c4def:(r,i,d)=>{"use strict";d.d(i,{D:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("ai.alpha.agents.threads.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"ai.alpha.agents.threads.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to ai.alpha.agents.threads.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"aiAlphaAgentsThreadsListFetcher",key:"createFetcherAiAlphaAgentsThreadsListFetcher",description:"ai.alpha.agents.threads.list generated fetcher"}},0x691f70dc:(r,i,d)=>{"use strict";d.d(i,{S:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("ai.alpha.digest.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"ai.alpha.digest.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to ai.alpha.digest.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"aiAlphaDigestListFetcher",key:"createFetcherAiAlphaDigestListFetcher",description:"ai.alpha.digest.list generated fetcher"}},0x543af8d2:(r,i,d)=>{"use strict";d.d(i,{k:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("ai.alpha.replies.get generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"ai.alpha.replies.get",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to ai.alpha.replies.get
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"aiAlphaRepliesGetFetcher",key:"createFetcherAiAlphaRepliesGetFetcher",description:"ai.alpha.replies.get generated fetcher"}},0x7ab9ae93:(r,i,d)=>{"use strict";d.d(i,{P:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("ai.alpha.slackiversary.fetch generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"ai.alpha.slackiversary.fetch",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to ai.alpha.slackiversary.fetch
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"aiAlphaSlackiversaryFetchFetcher",key:"createFetcherAiAlphaSlackiversaryFetchFetcher",description:"ai.alpha.slackiversary.fetch generated fetcher"}},0x1f9ab6622:(r,i,d)=>{"use strict";d.d(i,{z:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("ai.alpha.summarize.unreadsSnapshot generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"ai.alpha.summarize.unreadsSnapshot",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to ai.alpha.summarize.unreadsSnapshot
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"aiAlphaSummarizeUnreadsSnapshotFetcher",key:"createFetcherAiAlphaSummarizeUnreadsSnapshotFetcher",description:"ai.alpha.summarize.unreadsSnapshot generated fetcher"}},0x174e697:(r,i,d)=>{"use strict";d.d(i,{i:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("ai.alpha.today.suggestedTopics generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"ai.alpha.today.suggestedTopics",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to ai.alpha.today.suggestedTopics
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"aiAlphaTodaySuggestedTopicsFetcher",key:"createFetcherAiAlphaTodaySuggestedTopicsFetcher",description:"ai.alpha.today.suggestedTopics generated fetcher"}},0x16ccf7b31:(r,i,d)=>{"use strict";d.d(i,{V:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("ai.alpha.today.topics generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"ai.alpha.today.topics",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to ai.alpha.today.topics
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"aiAlphaTodayTopicsFetcher",key:"createFetcherAiAlphaTodayTopicsFetcher",description:"ai.alpha.today.topics generated fetcher"}},0x30929eb1:(r,i,d)=>{"use strict";d.d(i,{w:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("ai.setup.createChannel generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"ai.setup.createChannel",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to ai.setup.createChannel
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"aiSetupCreateChannelFetcher",key:"createFetcherAiSetupCreateChannelFetcher",description:"ai.setup.createChannel generated fetcher"}},0x1111a1f7d:(r,i,d)=>{"use strict";d.d(i,{b:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("apps.index.filters.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"apps.index.filters.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to apps.index.filters.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"appsIndexFiltersListFetcher",key:"createFetcherAppsIndexFiltersListFetcher",description:"apps.index.filters.list generated fetcher"}},0x6ef6ab73:(r,i,d)=>{"use strict";d.d(i,{X:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("apps.onboarding.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"apps.onboarding.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to apps.onboarding.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"appsOnboardingListFetcher",key:"createFetcherAppsOnboardingListFetcher",description:"apps.onboarding.list generated fetcher"}},0x1ebbb37ae:(r,i,d)=>{"use strict";d.d(i,{k:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("apps.recommendations.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"apps.recommendations.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to apps.recommendations.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"appsRecommendationsListFetcher",key:"createFetcherAppsRecommendationsListFetcher",description:"apps.recommendations.list generated fetcher"}},0x1863f1a23:(r,i,d)=>{"use strict";d.d(i,{F:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("apps.scopes.info generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"apps.scopes.info",args:F,abortSignal:I,reason:R})).then(r=>{p((0,C.XK)(r))}).catch(r=>{(0,E.default)({getState:i}).error(`API call to apps.scopes.info
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"appsScopesInfoFetcher",key:"createFetcherAppsScopesInfoFetcher",description:"apps.scopes.info generated fetcher"}},0x178d2d3fe:(r,i,d)=>{"use strict";d.d(i,{Y:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("apps.team.variables.get generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"apps.team.variables.get",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to apps.team.variables.get
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"appsTeamVariablesGetFetcher",key:"createFetcherAppsTeamVariablesGetFetcher",description:"apps.team.variables.get generated fetcher"}},0x318eaa1f:(r,i,d)=>{"use strict";d.d(i,{V:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("apps.user.connection.submit generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"apps.user.connection.submit",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to apps.user.connection.submit
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"appsUserConnectionSubmitFetcher",key:"createFetcherAppsUserConnectionSubmitFetcher",description:"apps.user.connection.submit generated fetcher"}},0xdb28a5b:(r,i,d)=>{"use strict";d.d(i,{j:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("auth.magicLogins.create generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"auth.magicLogins.create",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to auth.magicLogins.create
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"authMagicLoginsCreateFetcher",key:"createFetcherAuthMagicLoginsCreateFetcher",description:"auth.magicLogins.create generated fetcher"}},0x1eaa14f5a:(r,i,d)=>{"use strict";d.d(i,{d:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("calbootstrap.contactsList generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"calbootstrap.contactsList",args:F,abortSignal:I,reason:R})).then(r=>{p((0,C.XK)(r))}).catch(r=>{(0,E.default)({getState:i}).error(`API call to calbootstrap.contactsList
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"calbootstrapContactsListFetcher",key:"createFetcherCalbootstrapContactsListFetcher",description:"calbootstrap.contactsList generated fetcher"}},0xb37fe784:(r,i,d)=>{"use strict";d.d(i,{E:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("calendar.alerts.ack generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"calendar.alerts.ack",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to calendar.alerts.ack
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"calendarAlertsAckFetcher",key:"createFetcherCalendarAlertsAckFetcher",description:"calendar.alerts.ack generated fetcher"}},0xe9b1b521:(r,i,d)=>{"use strict";d.d(i,{l:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("calendar.alerts.snooze generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"calendar.alerts.snooze",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to calendar.alerts.snooze
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"calendarAlertsSnoozeFetcher",key:"createFetcherCalendarAlertsSnoozeFetcher",description:"calendar.alerts.snooze generated fetcher"}},0x66fff420:(r,i,d)=>{"use strict";d.d(i,{W:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("calendar.event.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"calendar.event.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to calendar.event.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"calendarEventListFetcher",key:"createFetcherCalendarEventListFetcher",description:"calendar.event.list generated fetcher"}},0x1b7b34aa1:(r,i,d)=>{"use strict";d.d(i,{l:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("calendar.event.rsvp generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"calendar.event.rsvp",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to calendar.event.rsvp
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"calendarEventRsvpFetcher",key:"createFetcherCalendarEventRsvpFetcher",description:"calendar.event.rsvp generated fetcher"}},0x22b1aafb8:(r,i,d)=>{"use strict";d.d(i,{R:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("calendar.event.setLocation generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"calendar.event.setLocation",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to calendar.event.setLocation
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"calendarEventSetLocationFetcher",key:"createFetcherCalendarEventSetLocationFetcher",description:"calendar.event.setLocation generated fetcher"}},0xd10fa901:(r,i,d)=>{"use strict";d.d(i,{b:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("calendar.user.status generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"calendar.user.status",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to calendar.user.status
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"calendarUserStatusFetcher",key:"createFetcherCalendarUserStatusFetcher",description:"calendar.user.status generated fetcher"}},0x7b72ca4b:(r,i,d)=>{"use strict";d.d(i,{r:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("client.dms generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"client.dms",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to client.dms
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"clientDmsFetcher",key:"createFetcherClientDmsFetcher",description:"client.dms generated fetcher"}},0x22ceff42e:(r,i,d)=>{"use strict";d.d(i,{E:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("client.extras generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"client.extras",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to client.extras
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"clientExtrasFetcher",key:"createFetcherClientExtrasFetcher",description:"client.extras generated fetcher"}},0x122323239:(r,i,d)=>{"use strict";d.d(i,{J:()=>R,O:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I={NotAllowed:"not_allowed",Ratelimited:"ratelimited",OnSlackStatusLookupFailed:"on_slack_status_lookup_failed",InvalidArguments:"invalid_arguments"},R=(0,w.A)("connectableContacts.lookup generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"connectableContacts.lookup",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to connectableContacts.lookup
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));R.meta={name:"connectableContactsLookupFetcher",key:"createFetcherConnectableContactsLookupFetcher",description:"connectableContacts.lookup generated fetcher"}},0x1bac5de2:(r,i,d)=>{"use strict";d.d(i,{V:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("conversations.genericInfo generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"conversations.genericInfo",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to conversations.genericInfo
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"conversationsGenericInfoFetcher",key:"createFetcherConversationsGenericInfoFetcher",description:"conversations.genericInfo generated fetcher"}},0x1fbfcdbbf:(r,i,d)=>{"use strict";d.d(i,{W:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("conversations.getGeneral generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"conversations.getGeneral",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to conversations.getGeneral
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"conversationsGetGeneralFetcher",key:"createFetcherConversationsGetGeneralFetcher",description:"conversations.getGeneral generated fetcher"}},0x2059de703:(r,i,d)=>{"use strict";d.d(i,{v:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("conversations.getJoinedChannels generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"conversations.getJoinedChannels",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to conversations.getJoinedChannels
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"conversationsGetJoinedChannelsFetcher",key:"createFetcherConversationsGetJoinedChannelsFetcher",description:"conversations.getJoinedChannels generated fetcher"}},0x1d841dfde:(r,i,d)=>{"use strict";d.d(i,{Z:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("conversations.ignoreInvite generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"conversations.ignoreInvite",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to conversations.ignoreInvite
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"conversationsIgnoreInviteFetcher",key:"createFetcherConversationsIgnoreInviteFetcher",description:"conversations.ignoreInvite generated fetcher"}},0x225920e4c:(r,i,d)=>{"use strict";d.d(i,{L:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("conversations.ignoreUser generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"conversations.ignoreUser",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to conversations.ignoreUser
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"conversationsIgnoreUserFetcher",key:"createFetcherConversationsIgnoreUserFetcher",description:"conversations.ignoreUser generated fetcher"}},0x35b0a79a:(r,i,d)=>{"use strict";d.d(i,{Q:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("conversations.joinConnectedShared generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"conversations.joinConnectedShared",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to conversations.joinConnectedShared
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"conversationsJoinConnectedSharedFetcher",key:"createFetcherConversationsJoinConnectedSharedFetcher",description:"conversations.joinConnectedShared generated fetcher"}},0x1bc42f556:(r,i,d)=>{"use strict";d.d(i,{K:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("conversations.joinPendingShared generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"conversations.joinPendingShared",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to conversations.joinPendingShared
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"conversationsJoinPendingSharedFetcher",key:"createFetcherConversationsJoinPendingSharedFetcher",description:"conversations.joinPendingShared generated fetcher"}},0x12c97f4e8:(r,i,d)=>{"use strict";d.d(i,{Y:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("conversations.revokeSharedInvite generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"conversations.revokeSharedInvite",args:F,abortSignal:I,reason:R})).then(r=>{p((0,C.XK)(r))}).catch(r=>{(0,E.default)({getState:i}).error(`API call to conversations.revokeSharedInvite
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"conversationsRevokeSharedInviteFetcher",key:"createFetcherConversationsRevokeSharedInviteFetcher",description:"conversations.revokeSharedInvite generated fetcher"}},0x19ff966f7:(r,i,d)=>{"use strict";d.d(i,{j:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("conversations.suggestions generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"conversations.suggestions",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to conversations.suggestions
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"conversationsSuggestionsFetcher",key:"createFetcherConversationsSuggestionsFetcher",description:"conversations.suggestions generated fetcher"}},0x10ba3b6ae:(r,i,d)=>{"use strict";d.d(i,{g:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("email.threads.share generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"email.threads.share",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to email.threads.share
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"emailThreadsShareFetcher",key:"createFetcherEmailThreadsShareFetcher",description:"email.threads.share generated fetcher"}},0x25110a0e:(r,i,d)=>{"use strict";d.d(i,{o:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("email.digest generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"email.digest",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to email.digest
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"emailDigestFetcher",key:"createFetcherEmailDigestFetcher",description:"email.digest generated fetcher"}},0x4ef35c57:(r,i,d)=>{"use strict";d.d(i,{n:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("enterprise.apps.search generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"enterprise.apps.search",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to enterprise.apps.search
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"enterpriseAppsSearchFetcher",key:"createFetcherEnterpriseAppsSearchFetcher",description:"enterprise.apps.search generated fetcher"}},0x1737b432f:(r,i,d)=>{"use strict";d.d(i,{X:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("enterpriseSearch.getConnectorFilters generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"enterpriseSearch.getConnectorFilters",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to enterpriseSearch.getConnectorFilters
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"enterpriseSearchGetConnectorFiltersFetcher",key:"createFetcherEnterpriseSearchGetConnectorFiltersFetcher",description:"enterpriseSearch.getConnectorFilters generated fetcher"}},0xb750639d:(r,i,d)=>{"use strict";d.d(i,{l:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("enterpriseSearch.searchFilterResults generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"enterpriseSearch.searchFilterResults",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to enterpriseSearch.searchFilterResults
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"enterpriseSearchSearchFilterResultsFetcher",key:"createFetcherEnterpriseSearchSearchFilterResultsFetcher",description:"enterpriseSearch.searchFilterResults generated fetcher"}},0x355f66a0:(r,i,d)=>{"use strict";d.d(i,{F:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("externalWorkspaces.invites.acceptanceEligibility generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"externalWorkspaces.invites.acceptanceEligibility",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to externalWorkspaces.invites.acceptanceEligibility
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"externalWorkspacesInvitesAcceptanceEligibilityFetcher",key:"createFetcherExternalWorkspacesInvitesAcceptanceEligibilityFetcher",description:"externalWorkspaces.invites.acceptanceEligibility generated fetcher"}},0x14b404ae5:(r,i,d)=>{"use strict";d.d(i,{l:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("externalWorkspaces.invites.ignore generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"externalWorkspaces.invites.ignore",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to externalWorkspaces.invites.ignore
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"externalWorkspacesInvitesIgnoreFetcher",key:"createFetcherExternalWorkspacesInvitesIgnoreFetcher",description:"externalWorkspaces.invites.ignore generated fetcher"}},0x777d8529:(r,i,d)=>{"use strict";d.d(i,{f:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("features.access.policies.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"features.access.policies.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to features.access.policies.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"featuresAccessPoliciesListFetcher",key:"createFetcherFeaturesAccessPoliciesListFetcher",description:"features.access.policies.list generated fetcher"}},0xe2f1f3f9:(r,i,d)=>{"use strict";d.d(i,{f:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("feedback.submitSalesforceFeedback generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"feedback.submitSalesforceFeedback",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to feedback.submitSalesforceFeedback
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"feedbackSubmitSalesforceFeedbackFetcher",key:"createFetcherFeedbackSubmitSalesforceFeedbackFetcher",description:"feedback.submitSalesforceFeedback generated fetcher"}},0x853132f8:(r,i,d)=>{"use strict";d.d(i,{n:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("feedback.submitSlackWrappedFeedback generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"feedback.submitSlackWrappedFeedback",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to feedback.submitSlackWrappedFeedback
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"feedbackSubmitSlackWrappedFeedbackFetcher",key:"createFetcherFeedbackSubmitSlackWrappedFeedbackFetcher",description:"feedback.submitSlackWrappedFeedback generated fetcher"}},0xd741f555:(r,i,d)=>{"use strict";d.d(i,{d:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("files.collections.delete generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"files.collections.delete",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to files.collections.delete
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"filesCollectionsDeleteFetcher",key:"createFetcherFilesCollectionsDeleteFetcher",description:"files.collections.delete generated fetcher"}},0x1b6608bb5:(r,i,d)=>{"use strict";d.d(i,{R:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("functions.workflows.executions.resume generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"functions.workflows.executions.resume",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to functions.workflows.executions.resume
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"functionsWorkflowsExecutionsResumeFetcher",key:"createFetcherFunctionsWorkflowsExecutionsResumeFetcher",description:"functions.workflows.executions.resume generated fetcher"}},0x1af17aa34:(r,i,d)=>{"use strict";d.d(i,{C:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("functions.workflows.versions.info generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"functions.workflows.versions.info",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to functions.workflows.versions.info
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"functionsWorkflowsVersionsInfoFetcher",key:"createFetcherFunctionsWorkflowsVersionsInfoFetcher",description:"functions.workflows.versions.info generated fetcher"}},0x206d6a214:(r,i,d)=>{"use strict";d.d(i,{i:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("functions.workflows.update generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"functions.workflows.update",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to functions.workflows.update
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"functionsWorkflowsUpdateFetcher",key:"createFetcherFunctionsWorkflowsUpdateFetcher",description:"functions.workflows.update generated fetcher"}},0x38e7a9b4:(r,i,d)=>{"use strict";d.d(i,{_:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("huddles.scheduled.cancel generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"huddles.scheduled.cancel",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to huddles.scheduled.cancel
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"huddlesScheduledCancelFetcher",key:"createFetcherHuddlesScheduledCancelFetcher",description:"huddles.scheduled.cancel generated fetcher"}},0x17f9c4cde:(r,i,d)=>{"use strict";d.d(i,{k:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("huddles.getTrackUrls generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"huddles.getTrackUrls",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to huddles.getTrackUrls
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"huddlesGetTrackUrlsFetcher",key:"createFetcherHuddlesGetTrackUrlsFetcher",description:"huddles.getTrackUrls generated fetcher"}},0xea868408:(r,i,d)=>{"use strict";d.d(i,{p:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("lists.edits.getLastForCell generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"lists.edits.getLastForCell",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to lists.edits.getLastForCell
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"listsEditsGetLastForCellFetcher",key:"createFetcherListsEditsGetLastForCellFetcher",description:"lists.edits.getLastForCell generated fetcher"}},0x2112dbd7e:(r,i,d)=>{"use strict";d.d(i,{c:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("meetings.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"meetings.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to meetings.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"meetingsListFetcher",key:"createFetcherMeetingsListFetcher",description:"meetings.list generated fetcher"}},0x3a565c4b:(r,i,d)=>{"use strict";d.d(i,{T:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("meetings.usersetdata generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"meetings.usersetdata",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to meetings.usersetdata
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"meetingsUsersetdataFetcher",key:"createFetcherMeetingsUsersetdataFetcher",description:"meetings.usersetdata generated fetcher"}},0x1588f52d7:(r,i,d)=>{"use strict";d.d(i,{z:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("megaphone.visualizer.spaces.get generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"megaphone.visualizer.spaces.get",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to megaphone.visualizer.spaces.get
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"megaphoneVisualizerSpacesGetFetcher",key:"createFetcherMegaphoneVisualizerSpacesGetFetcher",description:"megaphone.visualizer.spaces.get generated fetcher"}},0x1bfa44400:(r,i,d)=>{"use strict";d.d(i,{O:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("polls.create generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"polls.create",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to polls.create
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"pollsCreateFetcher",key:"createFetcherPollsCreateFetcher",description:"polls.create generated fetcher"}},0x81f3a3a7:(r,i,d)=>{"use strict";d.d(i,{j:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("recordChannels.open generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"recordChannels.open",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to recordChannels.open
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"recordChannelsOpenFetcher",key:"createFetcherRecordChannelsOpenFetcher",description:"recordChannels.open generated fetcher"}},0x6735e78b:(r,i,d)=>{"use strict";d.d(i,{B:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("records.share generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"records.share",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to records.share
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"recordsShareFetcher",key:"createFetcherRecordsShareFetcher",description:"records.share generated fetcher"}},0xe2e863bc:(r,i,d)=>{"use strict";d.d(i,{n:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("salesHome.admin.listOrgs generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"salesHome.admin.listOrgs",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to salesHome.admin.listOrgs
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"salesHomeAdminListOrgsFetcher",key:"createFetcherSalesHomeAdminListOrgsFetcher",description:"salesHome.admin.listOrgs generated fetcher"}},0x21f1cb409:(r,i,d)=>{"use strict";d.d(i,{J:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("salesHome.notifications.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"salesHome.notifications.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to salesHome.notifications.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"salesHomeNotificationsListFetcher",key:"createFetcherSalesHomeNotificationsListFetcher",description:"salesHome.notifications.list generated fetcher"}},0x1060d9639:(r,i,d)=>{"use strict";d.d(i,{A:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("search.autocomplete.topEmojis generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"search.autocomplete.topEmojis",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to search.autocomplete.topEmojis
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"searchAutocompleteTopEmojisFetcher",key:"createFetcherSearchAutocompleteTopEmojisFetcher",description:"search.autocomplete.topEmojis generated fetcher"}},0x1351cb3a3:(r,i,d)=>{"use strict";d.d(i,{Z:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("search.saved.create generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"search.saved.create",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to search.saved.create
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"searchSavedCreateFetcher",key:"createFetcherSearchSavedCreateFetcher",description:"search.saved.create generated fetcher"}},0x1bdccff26:(r,i,d)=>{"use strict";d.d(i,{a:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("sfdc.eacConfigs.get generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"sfdc.eacConfigs.get",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to sfdc.eacConfigs.get
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"sfdcEacConfigsGetFetcher",key:"createFetcherSfdcEacConfigsGetFetcher",description:"sfdc.eacConfigs.get generated fetcher"}},0x1ae67f482:(r,i,d)=>{"use strict";d.d(i,{H:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("sfdc.getReportAggregatesMetadata generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"sfdc.getReportAggregatesMetadata",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to sfdc.getReportAggregatesMetadata
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"sfdcGetReportAggregatesMetadataFetcher",key:"createFetcherSfdcGetReportAggregatesMetadataFetcher",description:"sfdc.getReportAggregatesMetadata generated fetcher"}},0x6663b28c:(r,i,d)=>{"use strict";d.d(i,{j:()=>I,s:()=>R});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I={NoValidReportIds:"no_valid_report_ids",InvalidRequest:"invalid_request",RequestLimitExceeded:"request_limit_exceeded",JobRunning:"job_running",SalesHomeUserConfigNotFound:"sales_home_user_config_not_found",TokenNotFound:"token_not_found",AccessTokenExchangeFailed:"access_token_exchange_failed",SalesforceOrgNotFound:"salesforce_org_not_found",ApiDisabled:"api_disabled",InvalidAccess:"invalid_access",ResourceNotFound:"resource_not_found",SalesforceTimeout:"salesforce_timeout",SalesforceRateLimited:"salesforce_rate_limited"},R=(0,w.A)("sfdc.getReportAggregates generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"sfdc.getReportAggregates",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to sfdc.getReportAggregates
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));R.meta={name:"sfdcGetReportAggregatesFetcher",key:"createFetcherSfdcGetReportAggregatesFetcher",description:"sfdc.getReportAggregates generated fetcher"}},0x1966cfa00:(r,i,d)=>{"use strict";d.d(i,{t:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("sharedInvites.canAccept generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"sharedInvites.canAccept",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to sharedInvites.canAccept
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"sharedInvitesCanAcceptFetcher",key:"createFetcherSharedInvitesCanAcceptFetcher",description:"sharedInvites.canAccept generated fetcher"}},0x993739b3:(r,i,d)=>{"use strict";d.d(i,{E$:()=>I,Pf:()=>R});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I={Verified:"verified",NotVerified:"not_verified",Suspicious:"suspicious"},R=(0,w.A)("sharedInvites.get generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"sharedInvites.get",args:F,abortSignal:I,reason:R,computeToken:!1})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to sharedInvites.get
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));R.meta={name:"sharedInvitesGetFetcher",key:"createFetcherSharedInvitesGetFetcher",description:"sharedInvites.get generated fetcher"}},0xaefa3f97:(r,i,d)=>{"use strict";d.d(i,{y:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("sharedInvites.ignoreInvite generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"sharedInvites.ignoreInvite",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to sharedInvites.ignoreInvite
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"sharedInvitesIgnoreInviteFetcher",key:"createFetcherSharedInvitesIgnoreInviteFetcher",description:"sharedInvites.ignoreInvite generated fetcher"}},0x24fe9b5e5:(r,i,d)=>{"use strict";d.d(i,{o:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("sharedInvites.ignoreUser generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"sharedInvites.ignoreUser",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to sharedInvites.ignoreUser
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"sharedInvitesIgnoreUserFetcher",key:"createFetcherSharedInvitesIgnoreUserFetcher",description:"sharedInvites.ignoreUser generated fetcher"}},0x18f0f676f:(r,i,d)=>{"use strict";d.d(i,{x:()=>C});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3);let C=(0,w.A)("sharedInvites.revoke generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:C,reason:I,...R}=d;r((0,_.apiCall)({method:"sharedInvites.revoke",args:R,abortSignal:C,reason:I})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to sharedInvites.revoke
						with reason ${I} failed, initiated by generated fetcher`),w(r)})}));C.meta={name:"sharedInvitesRevokeFetcher",key:"createFetcherSharedInvitesRevokeFetcher",description:"sharedInvites.revoke generated fetcher"}},0x4f496543:(r,i,d)=>{"use strict";d.d(i,{D:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("signup.checkSignupDomains generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"signup.checkSignupDomains",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to signup.checkSignupDomains
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"signupCheckSignupDomainsFetcher",key:"createFetcherSignupCheckSignupDomainsFetcher",description:"signup.checkSignupDomains generated fetcher"}},0x25313344c:(r,i,d)=>{"use strict";d.d(i,{b:()=>C});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3);let C=(0,w.A)("team.profile.getMetadata generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:C,reason:I,...R}=d;r((0,_.apiCall)({method:"team.profile.getMetadata",args:R,abortSignal:C,reason:I})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to team.profile.getMetadata
						with reason ${I} failed, initiated by generated fetcher`),w(r)})}));C.meta={name:"teamProfileGetMetadataFetcher",key:"createFetcherTeamProfileGetMetadataFetcher",description:"team.profile.getMetadata generated fetcher"}},0x20f7ce84e:(r,i,d)=>{"use strict";d.d(i,{j:()=>R,q:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I={InsufficientPermissions:"insufficient_permissions",Denied:"denied",TakenUrl:"taken_url",LongUrl:"long_url",BadUrl:"bad_url",NoUrl:"no_url",NoName:"no_name",TeamNameTooLong:"team_name_too_long",TeamNameHasUrl:"team_name_has_url",InvalidTeamName:"invalid_team_name",TeamNotFound:"team_not_found",TargetTeamIsOrg:"target_team_is_org",NameTakenInOrg:"name_taken_in_org",FailedToUpdateDescription:"failed_to_update_description",FailedToSetIcon:"failed_to_set_icon",MissingTargetTeam:"missing_target_team"},R=(0,w.A)("team.changeInfo generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"team.changeInfo",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to team.changeInfo
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));R.meta={name:"teamChangeInfoFetcher",key:"createFetcherTeamChangeInfoFetcher",description:"team.changeInfo generated fetcher"}},0x2312fb5b5:(r,i,d)=>{"use strict";d.d(i,{_:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("team.newHires generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"team.newHires",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to team.newHires
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"teamNewHiresFetcher",key:"createFetcherTeamNewHiresFetcher",description:"team.newHires generated fetcher"}},0xb5baa0eb:(r,i,d)=>{"use strict";d.d(i,{t:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("today.items.create generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"today.items.create",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to today.items.create
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"todayItemsCreateFetcher",key:"createFetcherTodayItemsCreateFetcher",description:"today.items.create generated fetcher"}},0x253ebd4ab:(r,i,d)=>{"use strict";d.d(i,{$:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("today.items.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"today.items.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to today.items.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"todayItemsListFetcher",key:"createFetcherTodayItemsListFetcher",description:"today.items.list generated fetcher"}},0x1246c2495:(r,i,d)=>{"use strict";d.d(i,{U:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("today.items.markRead generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"today.items.markRead",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to today.items.markRead
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"todayItemsMarkReadFetcher",key:"createFetcherTodayItemsMarkReadFetcher",description:"today.items.markRead generated fetcher"}},0x17f0c0ebe:(r,i,d)=>{"use strict";d.d(i,{N:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("today.items.markUnread generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"today.items.markUnread",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to today.items.markUnread
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"todayItemsMarkUnreadFetcher",key:"createFetcherTodayItemsMarkUnreadFetcher",description:"today.items.markUnread generated fetcher"}},0x18876ee2a:(r,i,d)=>{"use strict";d.d(i,{g:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("today.items.update generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"today.items.update",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to today.items.update
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"todayItemsUpdateFetcher",key:"createFetcherTodayItemsUpdateFetcher",description:"today.items.update generated fetcher"}},0x1365ece23:(r,i,d)=>{"use strict";d.d(i,{V:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("today.focus generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"today.focus",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to today.focus
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"todayFocusFetcher",key:"createFetcherTodayFocusFetcher",description:"today.focus generated fetcher"}},0x1e1a52712:(r,i,d)=>{"use strict";d.d(i,{x:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("today.ignoreChannels generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"today.ignoreChannels",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to today.ignoreChannels
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"todayIgnoreChannelsFetcher",key:"createFetcherTodayIgnoreChannelsFetcher",description:"today.ignoreChannels generated fetcher"}},0x8223febb:(r,i,d)=>{"use strict";d.d(i,{Y:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("today.unignoreChannels generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"today.unignoreChannels",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to today.unignoreChannels
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"todayUnignoreChannelsFetcher",key:"createFetcherTodayUnignoreChannelsFetcher",description:"today.unignoreChannels generated fetcher"}},0x985d2f1:(r,i,d)=>{"use strict";d.d(i,{f:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("userAlerts.ack generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"userAlerts.ack",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to userAlerts.ack
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"userAlertsAckFetcher",key:"createFetcherUserAlertsAckFetcher",description:"userAlerts.ack generated fetcher"}},0x1ac169e62:(r,i,d)=>{"use strict";d.d(i,{K:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("users.priority.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"users.priority.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to users.priority.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"usersPriorityListFetcher",key:"createFetcherUsersPriorityListFetcher",description:"users.priority.list generated fetcher"}},0x12065e6c5:(r,i,d)=>{"use strict";d.d(i,{y:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("users.slackConnect.orgInfo generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"users.slackConnect.orgInfo",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to users.slackConnect.orgInfo
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"usersSlackConnectOrgInfoFetcher",key:"createFetcherUsersSlackConnectOrgInfoFetcher",description:"users.slackConnect.orgInfo generated fetcher"}},0x21db007aa:(r,i,d)=>{"use strict";d.d(i,{Q:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("users.getDefaultWorkspace generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"users.getDefaultWorkspace",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to users.getDefaultWorkspace
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"usersGetDefaultWorkspaceFetcher",key:"createFetcherUsersGetDefaultWorkspaceFetcher",description:"users.getDefaultWorkspace generated fetcher"}},0x1e06556ec:(r,i,d)=>{"use strict";d.d(i,{C:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("users.isEarlyJoiner generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"users.isEarlyJoiner",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to users.isEarlyJoiner
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"usersIsEarlyJoinerFetcher",key:"createFetcherUsersIsEarlyJoinerFetcher",description:"users.isEarlyJoiner generated fetcher"}},0x152ff23a2:(r,i,d)=>{"use strict";d.d(i,{O:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("users.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"users.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to users.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"usersListFetcher",key:"createFetcherUsersListFetcher",description:"users.list generated fetcher"}},0x242b98f0:(r,i,d)=>{"use strict";d.d(i,{a:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("users.markAllRead generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"users.markAllRead",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to users.markAllRead
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"usersMarkAllReadFetcher",key:"createFetcherUsersMarkAllReadFetcher",description:"users.markAllRead generated fetcher"}},0x1f0286ef5:(r,i,d)=>{"use strict";d.d(i,{t:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("workflows.activity.get generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"workflows.activity.get",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to workflows.activity.get
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"workflowsActivityGetFetcher",key:"createFetcherWorkflowsActivityGetFetcher",description:"workflows.activity.get generated fetcher"}},0x15adbbf07:(r,i,d)=>{"use strict";d.d(i,{J:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("workflows.activity.list generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"workflows.activity.list",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to workflows.activity.list
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"workflowsActivityListFetcher",key:"createFetcherWorkflowsActivityListFetcher",description:"workflows.activity.list generated fetcher"}},0xced5313d:(r,i,d)=>{"use strict";d.d(i,{I:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("workflows.templates.listAsDecoratedWorkflows generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"workflows.templates.listAsDecoratedWorkflows",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to workflows.templates.listAsDecoratedWorkflows
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"workflowsTemplatesListAsDecoratedWorkflowsFetcher",key:"createFetcherWorkflowsTemplatesListAsDecoratedWorkflowsFetcher",description:"workflows.templates.listAsDecoratedWorkflows generated fetcher"}},0xa1c4a9a4:(r,i,d)=>{"use strict";d.d(i,{y:()=>I});var p=d(0xe874a88a),_=d(0x22a29f141),w=d(0x1dfdeb1c8),E=d(0x1ec68d6a3),C=d(0xe747dd27);let I=(0,w.A)("workflows.triggers.listRecentlyRunForUser generated fetcher",(r,i,d)=>new p.S((p,w)=>{let{abortSignal:I,reason:R,...k}=d,F=(0,C.VA)(k);r((0,_.apiCall)({method:"workflows.triggers.listRecentlyRunForUser",args:F,abortSignal:I,reason:R})).then(r=>{p(r)}).catch(r=>{(0,E.default)({getState:i}).error(`API call to workflows.triggers.listRecentlyRunForUser
						with reason ${R} failed, initiated by generated fetcher`),w(r)})}));I.meta={name:"workflowsTriggersListRecentlyRunForUserFetcher",key:"createFetcherWorkflowsTriggersListRecentlyRunForUserFetcher",description:"workflows.triggers.listRecentlyRunForUser generated fetcher"}},0x248e197a3:(r,i,d)=>{"use strict";d.d(i,{g$:()=>_,ml:()=>p});let p={All:"all",Active:"active",Archived:"archived"},_={Good:"good",Ok:"ok",Bad:"bad"}},0x1bf89bd2e:(r,i,d)=>{"use strict";d.d(i,{X:()=>p});let p={Birthday:"birthday",Default:"default",FocusTime:"focus_time",FromGmail:"from_gmail",OutOfOffice:"out_of_office",WorkingLocation:"working_location"}},0x1b587ee5a:(r,i,d)=>{"use strict";d.d(i,{$:()=>p});let p={NotSet:"not_set",Hangout:"hangout",Webex:"webex",Zoom:"zoom",Skype:"skype",MicrosoftTeams:"microsoft_teams",Bluejeans:"bluejeans",GoogleMeet:"google_meet",Chime:"chime",Slack:"slack",Huddle:"huddle"}},0x6b5a0b21:(r,i,d)=>{"use strict";d.d(i,{g:()=>p});let p={Accepted:"accepted",Declined:"declined",NeedsAction:"needs_action",Tentative:"tentative",None:"none"}},0x1c9df904f:(r,i,d)=>{"use strict";d.d(i,{q:()=>p});let p={InviteReceived:"invite_received",InviteRemoved:"invite_removed",InviteAccepted:"invite_accepted",InviteExpired:"invite_expired",InviteApproved:"invite_approved",InviteRejected:"invite_rejected",InviteAcknowledged:"invite_acknowledged"}},0x222aac130:(r,i,d)=>{"use strict";d.d(i,{H3:()=>w,gm:()=>E});var p,_,w=((p={}).ABOUT_SLACK="menuitem-about-slack",p.CHECK_FOR_UPDATES="menuitem-update-status",p.PREFERENCES="menuitem-preferences",p.SERVICES="menuitem-services",p.HIDE_SLACK="menuitem-hide-slack",p.HIDE_OTHERS="menuitem-hide-others",p.HISTORY="menuitem-history",p.SHOW_ALL="menuitem-show-all",p.QUIT="menuitem-quit",p.FILE_CLOSE="menuitem-file-close",p.UNDO="menuitem-undo",p.REDO="menuitem-redo",p.CUT="menuitem-cut",p.COPY="menuitem-copy",p.PASTE="menuitem-paste",p.PASTE_AS="menuitem-paste-as",p.DELETE="menuitem-delete",p.SELECT_ALL="menuitem-select-all",p.FIND="menuitem-find",p.SPEECH="menuitem-speech",p.START_SPEAKING="menuitem-start-speaking",p.STOP_SPEAKING="menuitem-stop-speaking",p.KEYBOARD_NAVIGATION="menuitem-keyboard-navigation",p.NEXT_SECTION="menuitem-next-section",p.PREVIOUS_SECTION="menuitem-previous-section",p.SELECTION_FIND="menuitem-selection-find",p.SETTINGS_EDITOR="menuitem-settings-editor",p.USE_LOCAL_ASSETS="menuitem-use-local-assets",p.TOGGLE_MAIN_PROCESS_INSPECTOR="menuitem-toggle-main-process-inspector",p.RELOAD_CURRENT="menuitem-reload-current",p.FORCE_RELOAD="menuitem-force-reload",p.TOGGLE_FULLSCREEN="menuitem-toggle-fullscreen",p.ZOOM_RESET="menuitem-zoom-reset",p.ZOOM_IN="menuitem-zoom-in",p.ZOOM_OUT="menuitem-zoom-out",p.ZOOM_IN_NUMPAD="menuitem-zoom-in-numpad",p.ZOOM_OUT_NUMPAD="menuitem-zoom-out-numpad",p.TOGGLE_WEBAPP_DEVTOOLS="menuitem-toggle-webapp-devtools",p.RELOAD_ALL="menuitem-reload-all",p.NAVIGATE_BACK="menuitem-navigate-back",p.NAVIGATE_FORWARD="menuitem-navigate-forward",p.WINDOW_MINIMIZE="menuitem-window-minimize",p.WINDOW_ZOOM="menuitem-window-perform-zoom",p.WINDOW_BRING_FRONT="menuitem-window-bring-front",p.TEAM_LIST_END_SEPARATOR="team-list-end-separator",p.SELECT_NEXT_TEAM="menuitem-select-next-team",p.SELECT_PREV_TEAM="menuitem-select-previous-team",p.SIGN_IN="menuitem-sign-in",p.KEYBOARD_SHORTCUT="menuitem-keyboard-shortcut",p.OPEN_HELP_CENTER="menuitem-open-help-center",p.REPORT_ISSUE="menuitem-report-issue",p.REVEAL_LOGS="menuitem-reveal-logs",p.COPY_INSTALLATION_ID="menuitem-copy-installation-id",p.RESET_APP_DATA="menuitem-reset-app-data",p.CLEAR_CACHE="menuitem-clear-cache",p.NET_LOG="menuitem-net-log",p.ELECTRON_DEBUG_LOG="menuitem-electron-log",p.RELEASE_NOTES="menuitem-release-notes",p.DEVELOPER="menuitem-developer",p.AUTO_HIDE_MENU_BAR="menuitem-auto-hide-menu-bar",p.TOGGLE_HARDWARE_ACCELERATION="menuitem-toggle-hardware-acceleration",p.WHATS_NEW="menuitem-whats-new",p.SHOW_MAIN_WINDOW="menuitem-show-main-window",p),E=((_={}).SLACK="menucategory-slack",_.FILE="menucategory-file",_.EDIT="menucategory-edit",_.VIEW="menucategory-view",_.JUMP_TO="menucategory-jump-to",_.HISTORY="menucategory-history",_.CONVERSATION="menucategory-conversation",_.WINDOW="menucategory-window",_.HELP="menucategory-help",_);Object.values(E).reduce((r,i,d)=>(r[i]=d,r),{})},0x5751fd9e:(r,i,d)=>{"use strict";d.d(i,{JL:()=>arc,rL:()=>pie});var p=Math.PI,_=2*p,w=_-1e-6;function Path(){this._x0=this._y0=this._x1=this._y1=null,this._=""}function path_path(){return new Path}Path.prototype=path_path.prototype={constructor:Path,moveTo:function(r,i){this._+="M"+(this._x0=this._x1=+r)+","+(this._y0=this._y1=+i)},closePath:function(){null!==this._x1&&(this._x1=this._x0,this._y1=this._y0,this._+="Z")},lineTo:function(r,i){this._+="L"+(this._x1=+r)+","+(this._y1=+i)},quadraticCurveTo:function(r,i,d,p){this._+="Q"+ +r+","+ +i+","+(this._x1=+d)+","+(this._y1=+p)},bezierCurveTo:function(r,i,d,p,_,w){this._+="C"+ +r+","+ +i+","+ +d+","+ +p+","+(this._x1=+_)+","+(this._y1=+w)},arcTo:function(r,i,d,_,w){r*=1,i*=1,d*=1,_*=1,w*=1;var E=this._x1,C=this._y1,I=d-r,R=_-i,k=E-r,F=C-i,P=k*k+F*F;if(w<0)throw Error("negative radius: "+w);if(null===this._x1)this._+="M"+(this._x1=r)+","+(this._y1=i);else if(P>1e-6)if(Math.abs(F*I-R*k)>1e-6&&w){var M=d-E,N=_-C,D=I*I+R*R,V=Math.sqrt(D),z=Math.sqrt(P),j=w*Math.tan((p-Math.acos((D+P-(M*M+N*N))/(2*V*z)))/2),$=j/z,G=j/V;Math.abs($-1)>1e-6&&(this._+="L"+(r+$*k)+","+(i+$*F)),this._+="A"+w+","+w+",0,0,"+ +(F*M>k*N)+","+(this._x1=r+G*I)+","+(this._y1=i+G*R)}else this._+="L"+(this._x1=r)+","+(this._y1=i)},arc:function(r,i,d,E,C,I){r*=1,i*=1,d*=1,I=!!I;var R=d*Math.cos(E),k=d*Math.sin(E),F=r+R,P=i+k,M=1^I,N=I?E-C:C-E;if(d<0)throw Error("negative radius: "+d);null===this._x1?this._+="M"+F+","+P:(Math.abs(this._x1-F)>1e-6||Math.abs(this._y1-P)>1e-6)&&(this._+="L"+F+","+P),d&&(N<0&&(N=N%_+_),N>w?this._+="A"+d+","+d+",0,1,"+M+","+(r-R)+","+(i-k)+"A"+d+","+d+",0,1,"+M+","+(this._x1=F)+","+(this._y1=P):N>1e-6&&(this._+="A"+d+","+d+",0,"+ +(N>=p)+","+M+","+(this._x1=r+d*Math.cos(C))+","+(this._y1=i+d*Math.sin(C))))},rect:function(r,i,d,p){this._+="M"+(this._x0=this._x1=+r)+","+(this._y0=this._y1=+i)+"h"+ +d+"v"+ +p+"h"+-d+"Z"},toString:function(){return this._}};let E=path_path;function src_constant(r){return function(){return r}}var C=Math.abs,I=Math.atan2,R=Math.cos,k=Math.max,F=Math.min,P=Math.sin,M=Math.sqrt,N=Math.PI,D=N/2,V=2*N;function acos(r){return r>1?0:r<-1?N:Math.acos(r)}function asin(r){return r>=1?D:r<=-1?-D:Math.asin(r)}function arcInnerRadius(r){return r.innerRadius}function arcOuterRadius(r){return r.outerRadius}function arcStartAngle(r){return r.startAngle}function arcEndAngle(r){return r.endAngle}function arcPadAngle(r){return r&&r.padAngle}function intersect(r,i,d,p,_,w,E,C){var I=d-r,R=p-i,k=E-_,F=C-w,P=(k*(i-w)-F*(r-_))/(F*I-k*R);return[r+P*I,i+P*R]}function cornerTangents(r,i,d,p,_,w,E){var C=r-d,I=i-p,R=(E?w:-w)/M(C*C+I*I),F=R*I,P=-R*C,N=r+F,D=i+P,V=d+F,z=p+P,j=(N+V)/2,$=(D+z)/2,G=V-N,q=z-D,H=G*G+q*q,Y=_-w,K=N*z-V*D,X=(q<0?-1:1)*M(k(0,Y*Y*H-K*K)),Q=(K*q-G*X)/H,ee=(-K*G-q*X)/H,er=(K*q+G*X)/H,ea=(-K*G+q*X)/H,en=Q-j,ei=ee-$,es=er-j,eo=ea-$;return en*en+ei*ei>es*es+eo*eo&&(Q=er,ee=ea),{cx:Q,cy:ee,x01:-F,y01:-P,x11:Q*(_/Y-1),y11:ee*(_/Y-1)}}function arc(){var r=arcInnerRadius,i=arcOuterRadius,d=src_constant(0),p=null,_=arcStartAngle,w=arcEndAngle,k=arcPadAngle,z=null;function arc(){var j,$,G=+r.apply(this,arguments),q=+i.apply(this,arguments),H=_.apply(this,arguments)-D,Y=w.apply(this,arguments)-D,K=C(Y-H),X=Y>H;if(z||(z=j=E()),q<G&&($=q,q=G,G=$),q>1e-12)if(K>V-1e-12)z.moveTo(q*R(H),q*P(H)),z.arc(0,0,q,H,Y,!X),G>1e-12&&(z.moveTo(G*R(Y),G*P(Y)),z.arc(0,0,G,Y,H,X));else{var Q,ee,er=H,ea=Y,en=H,ei=Y,es=K,eo=K,el=k.apply(this,arguments)/2,ec=el>1e-12&&(p?+p.apply(this,arguments):M(G*G+q*q)),ed=F(C(q-G)/2,+d.apply(this,arguments)),eh=ed,eu=ed;if(ec>1e-12){var ef=asin(ec/G*P(el)),ep=asin(ec/q*P(el));(es-=2*ef)>1e-12?(ef*=X?1:-1,en+=ef,ei-=ef):(es=0,en=ei=(H+Y)/2),(eo-=2*ep)>1e-12?(ep*=X?1:-1,er+=ep,ea-=ep):(eo=0,er=ea=(H+Y)/2)}var em=q*R(er),eg=q*P(er),e_=G*R(ei),ey=G*P(ei);if(ed>1e-12){var ev=q*R(ea),ex=q*P(ea),eb=G*R(en),eA=G*P(en);if(K<N){var ew=es>1e-12?intersect(em,eg,eb,eA,ev,ex,e_,ey):[e_,ey],eE=em-ew[0],eS=eg-ew[1],eT=ev-ew[0],eC=ex-ew[1],eI=1/P(acos((eE*eT+eS*eC)/(M(eE*eE+eS*eS)*M(eT*eT+eC*eC)))/2),eR=M(ew[0]*ew[0]+ew[1]*ew[1]);eh=F(ed,(G-eR)/(eI-1)),eu=F(ed,(q-eR)/(eI+1))}}eo>1e-12?eu>1e-12?(Q=cornerTangents(eb,eA,em,eg,q,eu,X),ee=cornerTangents(ev,ex,e_,ey,q,eu,X),z.moveTo(Q.cx+Q.x01,Q.cy+Q.y01),eu<ed?z.arc(Q.cx,Q.cy,eu,I(Q.y01,Q.x01),I(ee.y01,ee.x01),!X):(z.arc(Q.cx,Q.cy,eu,I(Q.y01,Q.x01),I(Q.y11,Q.x11),!X),z.arc(0,0,q,I(Q.cy+Q.y11,Q.cx+Q.x11),I(ee.cy+ee.y11,ee.cx+ee.x11),!X),z.arc(ee.cx,ee.cy,eu,I(ee.y11,ee.x11),I(ee.y01,ee.x01),!X))):(z.moveTo(em,eg),z.arc(0,0,q,er,ea,!X)):z.moveTo(em,eg),G>1e-12&&es>1e-12?eh>1e-12?(Q=cornerTangents(e_,ey,ev,ex,G,-eh,X),ee=cornerTangents(em,eg,eb,eA,G,-eh,X),z.lineTo(Q.cx+Q.x01,Q.cy+Q.y01),eh<ed?z.arc(Q.cx,Q.cy,eh,I(Q.y01,Q.x01),I(ee.y01,ee.x01),!X):(z.arc(Q.cx,Q.cy,eh,I(Q.y01,Q.x01),I(Q.y11,Q.x11),!X),z.arc(0,0,G,I(Q.cy+Q.y11,Q.cx+Q.x11),I(ee.cy+ee.y11,ee.cx+ee.x11),X),z.arc(ee.cx,ee.cy,eh,I(ee.y11,ee.x11),I(ee.y01,ee.x01),!X))):z.arc(0,0,G,ei,en,X):z.lineTo(e_,ey)}else z.moveTo(0,0);if(z.closePath(),j)return z=null,j+""||null}return arc.centroid=function(){var d=(+r.apply(this,arguments)+ +i.apply(this,arguments))/2,p=(+_.apply(this,arguments)+ +w.apply(this,arguments))/2-N/2;return[R(p)*d,P(p)*d]},arc.innerRadius=function(i){return arguments.length?(r="function"==typeof i?i:src_constant(+i),arc):r},arc.outerRadius=function(r){return arguments.length?(i="function"==typeof r?r:src_constant(+r),arc):i},arc.cornerRadius=function(r){return arguments.length?(d="function"==typeof r?r:src_constant(+r),arc):d},arc.padRadius=function(r){return arguments.length?(p=null==r?null:"function"==typeof r?r:src_constant(+r),arc):p},arc.startAngle=function(r){return arguments.length?(_="function"==typeof r?r:src_constant(+r),arc):_},arc.endAngle=function(r){return arguments.length?(w="function"==typeof r?r:src_constant(+r),arc):w},arc.padAngle=function(r){return arguments.length?(k="function"==typeof r?r:src_constant(+r),arc):k},arc.context=function(r){return arguments.length?(z=null==r?null:r,arc):z},arc}function Linear(r){this._context=r}function descending(r,i){return i<r?-1:i>r?1:i>=r?0:NaN}function identity(r){return r}function pie(){var r=identity,i=descending,d=null,p=src_constant(0),_=src_constant(V),w=src_constant(0);function pie(E){var C,I,R,k,F,P=E.length,M=0,N=Array(P),D=Array(P),z=+p.apply(this,arguments),j=Math.min(V,Math.max(-V,_.apply(this,arguments)-z)),$=Math.min(Math.abs(j)/P,w.apply(this,arguments)),G=$*(j<0?-1:1);for(C=0;C<P;++C)(F=D[N[C]=C]=+r(E[C],C,E))>0&&(M+=F);for(null!=i?N.sort(function(r,d){return i(D[r],D[d])}):null!=d&&N.sort(function(r,i){return d(E[r],E[i])}),C=0,R=M?(j-P*G)/M:0;C<P;++C,z=k)k=z+((F=D[I=N[C]])>0?F*R:0)+G,D[I]={data:E[I],index:C,value:F,startAngle:z,endAngle:k,padAngle:$};return D}return pie.value=function(i){return arguments.length?(r="function"==typeof i?i:src_constant(+i),pie):r},pie.sortValues=function(r){return arguments.length?(i=r,d=null,pie):i},pie.sort=function(r){return arguments.length?(d=r,i=null,pie):d},pie.startAngle=function(r){return arguments.length?(p="function"==typeof r?r:src_constant(+r),pie):p},pie.endAngle=function(r){return arguments.length?(_="function"==typeof r?r:src_constant(+r),pie):_},pie.padAngle=function(r){return arguments.length?(w="function"==typeof r?r:src_constant(+r),pie):w},pie}function Radial(r){this._curve=r}function radial_curveRadial(r){function radial(i){return new Radial(r(i))}return radial._curve=r,radial}Linear.prototype={areaStart:function(){this._line=0},areaEnd:function(){this._line=NaN},lineStart:function(){this._point=0},lineEnd:function(){(this._line||0!==this._line&&1===this._point)&&this._context.closePath(),this._line=1-this._line},point:function(r,i){switch(r*=1,i*=1,this._point){case 0:this._point=1,this._line?this._context.lineTo(r,i):this._context.moveTo(r,i);break;case 1:this._point=2;default:this._context.lineTo(r,i)}}},radial_curveRadial(function(r){return new Linear(r)}),Radial.prototype={areaStart:function(){this._curve.areaStart()},areaEnd:function(){this._curve.areaEnd()},lineStart:function(){this._curve.lineStart()},lineEnd:function(){this._curve.lineEnd()},point:function(r,i){this._curve.point(i*Math.sin(r),-(i*Math.cos(r)))}},Array.prototype.slice;function noop(){}function point(r,i,d){r._context.bezierCurveTo((2*r._x0+r._x1)/3,(2*r._y0+r._y1)/3,(r._x0+2*r._x1)/3,(r._y0+2*r._y1)/3,(r._x0+4*r._x1+i)/6,(r._y0+4*r._y1+d)/6)}function Basis(r){this._context=r}function Bundle(r,i){this._basis=new Basis(r),this._beta=i}function cardinal_point(r,i,d){r._context.bezierCurveTo(r._x1+r._k*(r._x2-r._x0),r._y1+r._k*(r._y2-r._y0),r._x2+r._k*(r._x1-i),r._y2+r._k*(r._y1-d),r._x2,r._y2)}function Cardinal(r,i){this._context=r,this._k=(1-i)/6}function CardinalClosed(r,i){this._context=r,this._k=(1-i)/6}function CardinalOpen(r,i){this._context=r,this._k=(1-i)/6}function catmullRom_point(r,i,d){var p=r._x1,_=r._y1,w=r._x2,E=r._y2;if(r._l01_a>1e-12){var C=2*r._l01_2a+3*r._l01_a*r._l12_a+r._l12_2a,I=3*r._l01_a*(r._l01_a+r._l12_a);p=(p*C-r._x0*r._l12_2a+r._x2*r._l01_2a)/I,_=(_*C-r._y0*r._l12_2a+r._y2*r._l01_2a)/I}if(r._l23_a>1e-12){var R=2*r._l23_2a+3*r._l23_a*r._l12_a+r._l12_2a,k=3*r._l23_a*(r._l23_a+r._l12_a);w=(w*R+r._x1*r._l23_2a-i*r._l12_2a)/k,E=(E*R+r._y1*r._l23_2a-d*r._l12_2a)/k}r._context.bezierCurveTo(p,_,w,E,r._x2,r._y2)}function CatmullRom(r,i){this._context=r,this._alpha=i}function CatmullRomClosed(r,i){this._context=r,this._alpha=i}function CatmullRomOpen(r,i){this._context=r,this._alpha=i}function slope3(r,i,d){var p=r._x1-r._x0,_=i-r._x1,w=(r._y1-r._y0)/(p||_<0&&-0),E=(d-r._y1)/(_||p<0&&-0);return((w<0?-1:1)+(E<0?-1:1))*Math.min(Math.abs(w),Math.abs(E),.5*Math.abs((w*_+E*p)/(p+_)))||0}function slope2(r,i){var d=r._x1-r._x0;return d?(3*(r._y1-r._y0)/d-i)/2:i}function monotone_point(r,i,d){var p=r._x0,_=r._y0,w=r._x1,E=r._y1,C=(w-p)/3;r._context.bezierCurveTo(p+C,_+C*i,w-C,E-C*d,w,E)}function MonotoneX(r){this._context=r}function ReflectContext(r){this._context=r}function controlPoints(r){var i,d,p=r.length-1,_=Array(p),w=Array(p),E=Array(p);for(_[0]=0,w[0]=2,E[0]=r[0]+2*r[1],i=1;i<p-1;++i)_[i]=1,w[i]=4,E[i]=4*r[i]+2*r[i+1];for(_[p-1]=2,w[p-1]=7,E[p-1]=8*r[p-1]+r[p],i=1;i<p;++i)d=_[i]/w[i-1],w[i]-=d,E[i]-=d*E[i-1];for(_[p-1]=E[p-1]/w[p-1],i=p-2;i>=0;--i)_[i]=(E[i]-_[i+1])/w[i];for(i=0,w[p-1]=(r[p]+_[p-1])/2;i<p-1;++i)w[i]=2*r[i+1]-_[i+1];return[_,w]}Basis.prototype={areaStart:function(){this._line=0},areaEnd:function(){this._line=NaN},lineStart:function(){this._x0=this._x1=this._y0=this._y1=NaN,this._point=0},lineEnd:function(){switch(this._point){case 3:point(this,this._x1,this._y1);case 2:this._context.lineTo(this._x1,this._y1)}(this._line||0!==this._line&&1===this._point)&&this._context.closePath(),this._line=1-this._line},point:function(r,i){switch(r*=1,i*=1,this._point){case 0:this._point=1,this._line?this._context.lineTo(r,i):this._context.moveTo(r,i);break;case 1:this._point=2;break;case 2:this._point=3,this._context.lineTo((5*this._x0+this._x1)/6,(5*this._y0+this._y1)/6);default:point(this,r,i)}this._x0=this._x1,this._x1=r,this._y0=this._y1,this._y1=i}},Bundle.prototype={lineStart:function(){this._x=[],this._y=[],this._basis.lineStart()},lineEnd:function(){var r=this._x,i=this._y,d=r.length-1;if(d>0)for(var p,_=r[0],w=i[0],E=r[d]-_,C=i[d]-w,I=-1;++I<=d;)p=I/d,this._basis.point(this._beta*r[I]+(1-this._beta)*(_+p*E),this._beta*i[I]+(1-this._beta)*(w+p*C));this._x=this._y=null,this._basis.lineEnd()},point:function(r,i){this._x.push(+r),this._y.push(+i)}},function custom(r){function bundle(i){return 1===r?new Basis(i):new Bundle(i,r)}return bundle.beta=function(r){return custom(+r)},bundle}(.85),Cardinal.prototype={areaStart:function(){this._line=0},areaEnd:function(){this._line=NaN},lineStart:function(){this._x0=this._x1=this._x2=this._y0=this._y1=this._y2=NaN,this._point=0},lineEnd:function(){switch(this._point){case 2:this._context.lineTo(this._x2,this._y2);break;case 3:cardinal_point(this,this._x1,this._y1)}(this._line||0!==this._line&&1===this._point)&&this._context.closePath(),this._line=1-this._line},point:function(r,i){switch(r*=1,i*=1,this._point){case 0:this._point=1,this._line?this._context.lineTo(r,i):this._context.moveTo(r,i);break;case 1:this._point=2,this._x1=r,this._y1=i;break;case 2:this._point=3;default:cardinal_point(this,r,i)}this._x0=this._x1,this._x1=this._x2,this._x2=r,this._y0=this._y1,this._y1=this._y2,this._y2=i}},function custom(r){function cardinal(i){return new Cardinal(i,r)}return cardinal.tension=function(r){return custom(+r)},cardinal}(0),CardinalClosed.prototype={areaStart:noop,areaEnd:noop,lineStart:function(){this._x0=this._x1=this._x2=this._x3=this._x4=this._x5=this._y0=this._y1=this._y2=this._y3=this._y4=this._y5=NaN,this._point=0},lineEnd:function(){switch(this._point){case 1:this._context.moveTo(this._x3,this._y3),this._context.closePath();break;case 2:this._context.lineTo(this._x3,this._y3),this._context.closePath();break;case 3:this.point(this._x3,this._y3),this.point(this._x4,this._y4),this.point(this._x5,this._y5)}},point:function(r,i){switch(r*=1,i*=1,this._point){case 0:this._point=1,this._x3=r,this._y3=i;break;case 1:this._point=2,this._context.moveTo(this._x4=r,this._y4=i);break;case 2:this._point=3,this._x5=r,this._y5=i;break;default:cardinal_point(this,r,i)}this._x0=this._x1,this._x1=this._x2,this._x2=r,this._y0=this._y1,this._y1=this._y2,this._y2=i}},function custom(r){function cardinal(i){return new CardinalClosed(i,r)}return cardinal.tension=function(r){return custom(+r)},cardinal}(0),CardinalOpen.prototype={areaStart:function(){this._line=0},areaEnd:function(){this._line=NaN},lineStart:function(){this._x0=this._x1=this._x2=this._y0=this._y1=this._y2=NaN,this._point=0},lineEnd:function(){(this._line||0!==this._line&&3===this._point)&&this._context.closePath(),this._line=1-this._line},point:function(r,i){switch(r*=1,i*=1,this._point){case 0:this._point=1;break;case 1:this._point=2;break;case 2:this._point=3,this._line?this._context.lineTo(this._x2,this._y2):this._context.moveTo(this._x2,this._y2);break;case 3:this._point=4;default:cardinal_point(this,r,i)}this._x0=this._x1,this._x1=this._x2,this._x2=r,this._y0=this._y1,this._y1=this._y2,this._y2=i}},function custom(r){function cardinal(i){return new CardinalOpen(i,r)}return cardinal.tension=function(r){return custom(+r)},cardinal}(0),CatmullRom.prototype={areaStart:function(){this._line=0},areaEnd:function(){this._line=NaN},lineStart:function(){this._x0=this._x1=this._x2=this._y0=this._y1=this._y2=NaN,this._l01_a=this._l12_a=this._l23_a=this._l01_2a=this._l12_2a=this._l23_2a=this._point=0},lineEnd:function(){switch(this._point){case 2:this._context.lineTo(this._x2,this._y2);break;case 3:this.point(this._x2,this._y2)}(this._line||0!==this._line&&1===this._point)&&this._context.closePath(),this._line=1-this._line},point:function(r,i){if(r*=1,i*=1,this._point){var d=this._x2-r,p=this._y2-i;this._l23_a=Math.sqrt(this._l23_2a=Math.pow(d*d+p*p,this._alpha))}switch(this._point){case 0:this._point=1,this._line?this._context.lineTo(r,i):this._context.moveTo(r,i);break;case 1:this._point=2;break;case 2:this._point=3;default:catmullRom_point(this,r,i)}this._l01_a=this._l12_a,this._l12_a=this._l23_a,this._l01_2a=this._l12_2a,this._l12_2a=this._l23_2a,this._x0=this._x1,this._x1=this._x2,this._x2=r,this._y0=this._y1,this._y1=this._y2,this._y2=i}},function custom(r){function catmullRom(i){return r?new CatmullRom(i,r):new Cardinal(i,0)}return catmullRom.alpha=function(r){return custom(+r)},catmullRom}(.5),CatmullRomClosed.prototype={areaStart:noop,areaEnd:noop,lineStart:function(){this._x0=this._x1=this._x2=this._x3=this._x4=this._x5=this._y0=this._y1=this._y2=this._y3=this._y4=this._y5=NaN,this._l01_a=this._l12_a=this._l23_a=this._l01_2a=this._l12_2a=this._l23_2a=this._point=0},lineEnd:function(){switch(this._point){case 1:this._context.moveTo(this._x3,this._y3),this._context.closePath();break;case 2:this._context.lineTo(this._x3,this._y3),this._context.closePath();break;case 3:this.point(this._x3,this._y3),this.point(this._x4,this._y4),this.point(this._x5,this._y5)}},point:function(r,i){if(r*=1,i*=1,this._point){var d=this._x2-r,p=this._y2-i;this._l23_a=Math.sqrt(this._l23_2a=Math.pow(d*d+p*p,this._alpha))}switch(this._point){case 0:this._point=1,this._x3=r,this._y3=i;break;case 1:this._point=2,this._context.moveTo(this._x4=r,this._y4=i);break;case 2:this._point=3,this._x5=r,this._y5=i;break;default:catmullRom_point(this,r,i)}this._l01_a=this._l12_a,this._l12_a=this._l23_a,this._l01_2a=this._l12_2a,this._l12_2a=this._l23_2a,this._x0=this._x1,this._x1=this._x2,this._x2=r,this._y0=this._y1,this._y1=this._y2,this._y2=i}},function custom(r){function catmullRom(i){return r?new CatmullRomClosed(i,r):new CardinalClosed(i,0)}return catmullRom.alpha=function(r){return custom(+r)},catmullRom}(.5),CatmullRomOpen.prototype={areaStart:function(){this._line=0},areaEnd:function(){this._line=NaN},lineStart:function(){this._x0=this._x1=this._x2=this._y0=this._y1=this._y2=NaN,this._l01_a=this._l12_a=this._l23_a=this._l01_2a=this._l12_2a=this._l23_2a=this._point=0},lineEnd:function(){(this._line||0!==this._line&&3===this._point)&&this._context.closePath(),this._line=1-this._line},point:function(r,i){if(r*=1,i*=1,this._point){var d=this._x2-r,p=this._y2-i;this._l23_a=Math.sqrt(this._l23_2a=Math.pow(d*d+p*p,this._alpha))}switch(this._point){case 0:this._point=1;break;case 1:this._point=2;break;case 2:this._point=3,this._line?this._context.lineTo(this._x2,this._y2):this._context.moveTo(this._x2,this._y2);break;case 3:this._point=4;default:catmullRom_point(this,r,i)}this._l01_a=this._l12_a,this._l12_a=this._l23_a,this._l01_2a=this._l12_2a,this._l12_2a=this._l23_2a,this._x0=this._x1,this._x1=this._x2,this._x2=r,this._y0=this._y1,this._y1=this._y2,this._y2=i}},function custom(r){function catmullRom(i){return r?new CatmullRomOpen(i,r):new CardinalOpen(i,0)}return catmullRom.alpha=function(r){return custom(+r)},catmullRom}(.5),MonotoneX.prototype={areaStart:function(){this._line=0},areaEnd:function(){this._line=NaN},lineStart:function(){this._x0=this._x1=this._y0=this._y1=this._t0=NaN,this._point=0},lineEnd:function(){switch(this._point){case 2:this._context.lineTo(this._x1,this._y1);break;case 3:monotone_point(this,this._t0,slope2(this,this._t0))}(this._line||0!==this._line&&1===this._point)&&this._context.closePath(),this._line=1-this._line},point:function(r,i){var d=NaN;if(i*=1,(r*=1)!==this._x1||i!==this._y1){switch(this._point){case 0:this._point=1,this._line?this._context.lineTo(r,i):this._context.moveTo(r,i);break;case 1:this._point=2;break;case 2:this._point=3,monotone_point(this,slope2(this,d=slope3(this,r,i)),d);break;default:monotone_point(this,this._t0,d=slope3(this,r,i))}this._x0=this._x1,this._x1=r,this._y0=this._y1,this._y1=i,this._t0=d}}},((function(r){this._context=new ReflectContext(r)}).prototype=Object.create(MonotoneX.prototype)).point=function(r,i){MonotoneX.prototype.point.call(this,i,r)},ReflectContext.prototype={moveTo:function(r,i){this._context.moveTo(i,r)},closePath:function(){this._context.closePath()},lineTo:function(r,i){this._context.lineTo(i,r)},bezierCurveTo:function(r,i,d,p,_,w){this._context.bezierCurveTo(i,r,p,d,w,_)}}},0x14d52fedb:(r,i,d)=>{"use strict";d.d(i,{A:()=>p});let p=(0,d(0xb595c55c).A)("floor")},0x97d7363f:(r,i,d)=>{"use strict";d.d(i,{A:()=>lodash_es_sortedUniq});var p=d(0x168cf0441);let _baseSortedUniq=function(r,i){for(var d=-1,_=r.length,w=0,E=[];++d<_;){var C=r[d],I=i?i(C):C;if(!d||!(0,p.A)(I,R)){var R=I;E[w++]=0===C?0:C}}return E},lodash_es_sortedUniq=function(r){return r&&r.length?_baseSortedUniq(r):[]}},0x1ca528d26:(r,i,d)=>{"use strict";d.d(i,{A:()=>I});var p=d(0x152d4868a),_=d(0x21b3c8033),w=d(0xe76086ae),E=d(0x1144c65c4),C=d(0x20bafd237);let I=(0,_.A)(function(r){var i=(0,C.A)(r);return i="function"==typeof i?i:void 0,(0,w.A)((0,p.A)(r,1,E.A,!0),void 0,i)})},0x6c595717:(r,i,d)=>{"use strict";let p;d.d(i,{rH:()=>x});let e=()=>{let r=performance.getEntriesByType("navigation")[0];if(r&&r.responseStart>0&&r.responseStart<performance.now())return r},o=r=>{let i=r.nodeName;return 1===r.nodeType?i.toLowerCase():i.toUpperCase().replace(/^#/,"")},_=new WeakMap;function s(r,i){return _.get(r)||_.set(r,new i),_.get(r)}let w=-1,f=r=>{addEventListener("pageshow",i=>{i.persisted&&(w=i.timeStamp,r(i))},!0)},u=(r,i,d,p)=>{let _,w;return E=>{let C;i.value>=0&&(E||p)&&((w=i.value-(_??0))||void 0===_)&&(_=i.value,i.delta=w,C=i.value,i.rating=C>d[1]?"poor":C>d[0]?"needs-improvement":"good",r(i))}},l=()=>{let r=e();return r?.activationStart??0},h=(r,i=-1)=>{let d=e(),p="navigate";return w>=0?p="back-forward-cache":d&&(document.prerendering||l()>0?p="prerender":document.wasDiscarded?p="restore":d.type&&(p=d.type.replace(/_/g,"-"))),{name:r,value:i,rating:"good",delta:0,entries:[],id:`v5-${Date.now()}-${Math.floor(0x82f79cd8fff*Math.random())+1e12}`,navigationType:p}},m=(r,i,d={})=>{try{if(PerformanceObserver.supportedEntryTypes.includes(r)){let p=new PerformanceObserver(r=>{Promise.resolve().then(()=>{i(r.getEntries())})});return p.observe({type:r,buffered:!0,...d}),p}}catch{}},E=-1,C=new Set,v=()=>"hidden"!==document.visibilityState||document.prerendering?1/0:0,b=r=>{if("hidden"===document.visibilityState){if("visibilitychange"===r.type)for(let r of C)r();isFinite(E)||(E="visibilitychange"===r.type?r.timeStamp:0,removeEventListener("prerenderingchange",b,!0))}},I=0,R=1/0,k=0,B=r=>{for(let i of r)i.interactionId&&(R=Math.min(R,i.interactionId),I=(k=Math.max(k,i.interactionId))?(k-R)/7+1:0)},O=()=>p?I:performance.interactionCount??0,F=0;let A=class A{l=[];h=new Map;m;p;v(){F=O(),this.l.length=0,this.h.clear()}M(){let r=Math.min(this.l.length-1,Math.floor((O()-F)/50));return this.l[r]}u(r){if(this.m?.(r),!r.interactionId&&"first-input"!==r.entryType)return;let i=this.l.at(-1),d=this.h.get(r.interactionId);if(d||this.l.length<10||r.duration>i.T){if(d?r.duration>d.T?(d.entries=[r],d.T=r.duration):r.duration===d.T&&r.startTime===d.entries[0].startTime&&d.entries.push(r):(d={id:r.interactionId,entries:[r],T:r.duration},this.h.set(d.id,d),this.l.push(d)),this.l.sort((r,i)=>i.T-r.T),this.l.length>10)for(let r of this.l.splice(10))this.h.delete(r.id);this.p?.(d)}}};let W=r=>{var i;let d,p=globalThis.requestIdleCallback||setTimeout;"hidden"===document.visibilityState?r():(i=r,d=!1,addEventListener("visibilitychange",r=()=>{d||(i(),d=!0)},{once:!0,capture:!0}),p(()=>{r(),removeEventListener("visibilitychange",r,{capture:!0})}))},P=[200,500],x=(r,i={})=>{let d=s(i=Object.assign({},i),A),_=[],w=[],I=0,R=new WeakMap,k=new WeakMap,F=!1,g=()=>{F||(W(y),F=!0)},y=()=>{let r=d.l.map(r=>R.get(r.entries[0])),i=w.length-50;w=w.filter((d,p)=>p>=i||r.includes(d));let p=new Set;for(let r of w)for(let i of v(r.startTime,r.processingEnd))p.add(i);let E=_.length-1-50;_=_.filter((r,i)=>r.startTime>I&&i>E||p.has(r)),F=!1};d.m=r=>{let i,d=r.startTime+r.duration;I=Math.max(I,r.processingEnd);for(let p=w.length-1;p>=0;p--){let _=w[p];if(8>=Math.abs(d-_.renderTime)){(i=_).startTime=Math.min(r.startTime,i.startTime),i.processingStart=Math.min(r.processingStart,i.processingStart),i.processingEnd=Math.max(r.processingEnd,i.processingEnd),i.entries.push(r);break}}i||(i={startTime:r.startTime,processingStart:r.processingStart,processingEnd:r.processingEnd,renderTime:d,entries:[r]},w.push(i)),(r.interactionId||"first-input"===r.entryType)&&R.set(r,i),g()},d.p=r=>{if(!k.get(r)){let d=r.entries[0].target;if(d){let p=i.generateTarget?.(d)??(r=>{let i="";try{for(;9!==r?.nodeType;){let d=r,p=d.id?"#"+d.id:[o(d),...Array.from(d.classList).sort()].join(".");if(i.length+p.length>99)return i||p;if(i=i?p+">"+i:p,d.id)break;r=d.parentNode}}catch{}return i})(d);k.set(r,p)}}};let v=(r,i)=>{let d=[];for(let p of _)if(!(p.startTime+p.duration<r)){if(p.startTime>i)break;d.push(p)}return d};m("long-animation-frame",r=>{_=_.concat(r),g()}),((r,i={})=>{var d;if(!globalThis.PerformanceEventTiming||!("interactionId"in PerformanceEventTiming.prototype))return;let _=(()=>{if(E<0){let r=l();E=(document.prerendering?void 0:globalThis.performance.getEntriesByType("visibility-state").filter(i=>"hidden"===i.name&&i.startTime>r)[0]?.startTime)??v(),addEventListener("visibilitychange",b,!0),addEventListener("prerenderingchange",b,!0),f(()=>{setTimeout(()=>{E=v()})})}return{get firstHiddenTime(){return E},onHidden(r){C.add(r)}}})();d=()=>{"interactionCount"in performance||p||(p=m("event",B,{type:"event",buffered:!0,durationThreshold:0}));let d,w=h("INP"),E=s(i,A),a=r=>{W(()=>{for(let i of r)E.u(i);let i=E.M();i&&i.T!==w.value&&(w.value=i.T,w.entries=i.entries,d())})},C=m("event",a,{durationThreshold:i.durationThreshold??40});d=u(r,w,P,i.reportAllChanges),C&&(C.observe({type:"first-input",buffered:!0}),_.onHidden(()=>{a(C.takeRecords()),d(!0)}),f(()=>{E.v(),d=u(r,w=h("INP"),P,i.reportAllChanges)}))},document.prerendering?addEventListener("prerenderingchange",()=>d(),!0):d()})(i=>{let p,_,w,E,C,I,F,P,M;r((p=i.entries[0],_=R.get(p),w=p.processingStart,E=Math.max(p.startTime+p.duration,w),C=Math.min(_.processingEnd,E),I=_.entries.sort((r,i)=>r.processingStart-i.processingStart),F=v(p.startTime,C),P=d.h.get(p.interactionId),(r=>{if(!r.longAnimationFrameEntries?.length)return;let i=r.interactionTime,d=r.inputDelay,p=r.processingDuration,_,w,E=0,C=0,I=0,R=0;for(let I of r.longAnimationFrameEntries)for(let r of(C=C+I.startTime+I.duration-I.styleAndLayoutStart,I.scripts)){let I=r.startTime+r.duration;if(I<i)continue;let k=I-Math.max(i,r.startTime),F=r.duration?k/r.duration*r.forcedStyleAndLayoutDuration:0;E+=k-F,C+=F,k>R&&(w=r.startTime<i+d?"input-delay":r.startTime>=i+d+p?"presentation-delay":"processing-duration",_=r,R=k)}let k=r.longAnimationFrameEntries.at(-1),F=k?k.startTime+k.duration:0;F>=i+d+p&&(I=r.nextPaintTime-F),_&&w&&(r.longestScript={entry:_,subpart:w,intersectingDuration:R}),r.totalScriptDuration=E,r.totalStyleAndLayoutDuration=C,r.totalPaintDuration=I,r.totalUnattributedDuration=r.nextPaintTime-i-E-C-I})(M={interactionTarget:k.get(P),interactionType:p.name.startsWith("key")?"keyboard":"pointer",interactionTime:p.startTime,nextPaintTime:E,processedEventEntries:I,longAnimationFrameEntries:F,inputDelay:w-p.startTime,processingDuration:C-w,presentationDelay:E-C,loadState:(r=>{if("loading"===document.readyState)return"loading";{let i=e();if(i){if(r<i.domInteractive)return"loading";if(0===i.domContentLoadedEventStart||r<i.domContentLoadedEventStart)return"dom-interactive";if(0===i.domComplete||r<i.domComplete)return"dom-content-loaded"}}return"complete"})(p.startTime),longestScript:void 0,totalScriptDuration:void 0,totalStyleAndLayoutDuration:void 0,totalPaintDuration:void 0,totalUnattributedDuration:void 0}),Object.assign(i,{attribution:M})))},i)}}}]);
//# sourceMappingURL=https://slack.com/source-maps/bv1-13/gantry-v2-async-gantry-v2-vendors-async-client.3df98b7ae05053584d00.min.js.map