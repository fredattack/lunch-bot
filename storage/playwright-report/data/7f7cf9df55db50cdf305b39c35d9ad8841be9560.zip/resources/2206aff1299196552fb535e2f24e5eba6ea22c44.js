(globalThis.webpackChunkwebapp=globalThis.webpackChunkwebapp||[]).push([["effect-renderer"],{0x17bae25b2:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>EffectRenderer});var i=r(0xe34cd03),o=r(0x1289871b1),a=r(0x1047389d9),s=r(0x19f9de028),n=r(0x67a17711),l=r(0xc369e6e0),u=r(0x1564d7324),f=r(0xb44ce653),m=r(0x633177a3),c=r(0xe4c0faec),h=r(0x7e6714d6);r(0x49cd54a7);var d=r(0x866fcb20),_=r(0x12bb1ab53),g=r(0x2310d95fe),x=r(0x1cab58f69),v=r(0x170f28e85);let b=self.WorkerGlobalScope&&self instanceof WorkerGlobalScope;function makeSelfieSegmentationFileURL(e){return new URL(e,self.origin).toString()}let E={"selfie_segmentation_solution_wasm_bin.js":makeSelfieSegmentationFileURL(n),"selfie_segmentation_solution_simd_wasm_bin.js":makeSelfieSegmentationFileURL(a),"selfie_segmentation_solution_wasm_bin.wasm":makeSelfieSegmentationFileURL(l),"selfie_segmentation_solution_simd_wasm_bin.wasm":makeSelfieSegmentationFileURL(s),"selfie_segmentation_landscape.tflite":makeSelfieSegmentationFileURL(o),"selfie_segmentation.binarypb":makeSelfieSegmentationFileURL(u)};b&&(self.document=self);let EffectRenderer=class EffectRenderer{mode;modelP;model;selfie;selfieResult;canvas;video;width;height;gl;identityProgram;bilateralProgram;blurProgram;bgProgram;attributes;resizeCanvas;resizeCtx;constructor({mode:e,video:t,width:r,height:o}){this.mode=e,this.video=t,this.width=r,this.height=o,this.canvas=self.OffscreenCanvas?new OffscreenCanvas(this.width,this.height):document.createElement("canvas"),this.canvas.width=this.width,this.canvas.height=this.height;const a=this.canvas.getContext("webgl");if(!a)throw Error("Could not get webgl context");a.pixelStorei(a.UNPACK_FLIP_Y_WEBGL,!0),this.gl=a,b?(this.selfie=new i.SelfieSegmentation({locateFile:e=>E[e]}),this.selfie.setOptions({modelSelection:1}),this.selfie.onResults(e=>{this.selfieResult=e.segmentationMask})):(f.jh6("webgl"),this.modelP=f.ox(c,void 0),this.modelP.then(e=>{this.model=e})),this.identityProgram=(0,m.rC)(a,v,x),this.bilateralProgram=(0,m.rC)(a,v,_),this.blurProgram=(0,m.rC)(a,v,g),this.bgProgram=(0,m.rC)(a,v,d),this.attributes=this.initAttributes(),this.resizeCanvas=self.OffscreenCanvas?new OffscreenCanvas(this.width,this.height):document.createElement("canvas"),this.resizeCanvas.width=this.width,this.resizeCanvas.height=this.height;const s=this.resizeCanvas.getContext("2d");if(!s)throw Error("Could not get resize context");this.resizeCtx=s}initAttributes(){let e=this.gl,t=e.getAttribLocation(this.blurProgram,"a_position"),r=e.createBuffer();if(!r)throw Error("GL: Failed to create buffer positionBuffer");e.bindBuffer(e.ARRAY_BUFFER,r),e.bufferData(e.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),e.STATIC_DRAW);let i=e.getAttribLocation(this.blurProgram,"a_texCoord"),o=e.createBuffer();if(!o)throw Error("GL: Failed to create buffer texCoordBuffer");return e.bindBuffer(e.ARRAY_BUFFER,o),e.bufferData(e.ARRAY_BUFFER,new Float32Array([0,0,1,0,0,1,0,1,1,0,1,1]),e.STATIC_DRAW),[{buffer:r,location:t},{buffer:o,location:i}]}setMode(e){this.mode=e}setBg(e){let{x:t,y:r,width:i,height:o}=(0,h.v9)({sourceWidth:e.width,sourceHeight:e.height,targetWidth:this.width,targetHeight:this.height});this.resizeCtx.clearRect(0,0,this.width,this.height),this.resizeCtx.drawImage(e,t,r,i,o)}setDimensions(e,t){this.width=e,this.height=t,this.canvas.width=e,this.canvas.height=t,this.resizeCanvas.width=e,this.resizeCanvas.height=t}initPredict(){this.model&&f.DZQ(()=>{this.model.predict(f.Ul9([1,144,256,3]))})}async render(){if(!b&&this.video instanceof HTMLVideoElement&&this.video.readyState<this.video.HAVE_CURRENT_DATA||!this.model&&!b)return;let e=await this.predict();if(!e)return;let t=this.getMaskTexture(e),r=this.bilateral(t);return"blur"===this.mode?this.drawBlur(r):"bg"===this.mode&&this.drawBg(r),this.canvas}async predict(){if(b&&this.selfie){let e=await createImageBitmap(this.video,{resizeWidth:256,resizeHeight:144});return await this.selfie.send({image:e}),this.selfieResult}if(!this.model)return;let e=f.DZQ(()=>{let e=f.TaL.fromPixels(this.video),t=f.Slp.resizeBilinear(e,[144,256]).expandDims(0),r=f.wgE(t,"float32").div(256),i=this.model.predict(r);return f.lDo(i.softmax().squeeze(),2,2)[0].squeeze().mul(256)}),t=new Uint8ClampedArray(e.dataSync());return f.ASo(e),t}getMaskTexture(e){let t=this.gl,r=(0,m.sZ)(t,t.LINEAR);return e instanceof ImageBitmap?t.texImage2D(t.TEXTURE_2D,0,t.ALPHA,t.ALPHA,t.UNSIGNED_BYTE,e):t.texImage2D(t.TEXTURE_2D,0,t.ALPHA,256,144,0,t.ALPHA,t.UNSIGNED_BYTE,e),r}bilateral(e){let t=this.gl,r=(0,m.TD)(t,256,144,t.LINEAR);t.useProgram(this.bilateralProgram),t.viewport(0,0,256,144),t.clearColor(0,0,1,1),t.clear(t.COLOR_BUFFER_BIT),(0,m.f6)(t,this.attributes),t.uniform2f(t.getUniformLocation(this.bilateralProgram,"u_unit"),1/this.width,1/this.height),b&&(t.uniform1i(t.getUniformLocation(this.bilateralProgram,"u_invert"),1),t.uniform1i(t.getUniformLocation(this.bilateralProgram,"u_flip"),1)),t.uniform1i(t.getUniformLocation(this.bilateralProgram,"u_ramp"),+("bg"===this.mode)),t.activeTexture(t.TEXTURE0),t.bindTexture(t.TEXTURE_2D,e),t.uniform1i(t.getUniformLocation(this.bilateralProgram,"u_mask"),0);let i=(0,m.oN)(t);return t.bindFramebuffer(t.FRAMEBUFFER,i),t.framebufferTexture2D(t.FRAMEBUFFER,t.COLOR_ATTACHMENT0,t.TEXTURE_2D,r,0),t.drawArrays(t.TRIANGLES,0,6),t.bindFramebuffer(t.FRAMEBUFFER,null),r}blur(e,t,r=!1){let i,o,a=this.gl;a.useProgram(this.blurProgram),a.viewport(0,0,this.width,this.height),a.clearColor(0,0,1,1),a.clear(a.COLOR_BUFFER_BIT),(0,m.f6)(a,this.attributes);let s=(0,m.TD)(a,this.width,this.height),n=(0,m.TD)(a,this.width,this.height),l=(0,m.oN)(a);for(let u=0;u<8;u++){i=u%2?s:n,o=u%2?n:s;let f=u%2?(8-u)/this.width:0,m=u%2?0:(8-u)/this.height;a.uniform2f(a.getUniformLocation(this.blurProgram,"u_direction"),f,m),a.uniform1i(a.getUniformLocation(this.blurProgram,"u_invert"),+r),a.activeTexture(a.TEXTURE0),a.bindTexture(a.TEXTURE_2D,0===u?e:i),a.uniform1i(a.getUniformLocation(this.blurProgram,"u_video"),0),a.activeTexture(a.TEXTURE1),a.bindTexture(a.TEXTURE_2D,t),a.uniform1i(a.getUniformLocation(this.blurProgram,"u_mask"),1),a.bindFramebuffer(a.FRAMEBUFFER,l),a.framebufferTexture2D(a.FRAMEBUFFER,a.COLOR_ATTACHMENT0,a.TEXTURE_2D,o,0),a.drawArrays(a.TRIANGLES,0,6)}return a.bindFramebuffer(a.FRAMEBUFFER,null),o}drawBlur(e){let t=this.gl,r=(0,m.sZ)(t);t.texImage2D(t.TEXTURE_2D,0,t.RGBA,t.RGBA,t.UNSIGNED_BYTE,this.video);let i=this.blur(r,e);t.useProgram(this.identityProgram),t.viewport(0,0,this.width,this.height),t.clearColor(0,0,1,1),t.clear(t.COLOR_BUFFER_BIT),(0,m.f6)(t,this.attributes),t.activeTexture(t.TEXTURE0),t.bindTexture(t.TEXTURE_2D,i),t.uniform1i(t.getUniformLocation(this.identityProgram,"u_in"),0),t.drawArrays(t.TRIANGLES,0,6)}drawBg(e){let t=this.gl,r=(0,m.sZ)(t);t.texImage2D(t.TEXTURE_2D,0,t.RGBA,t.RGBA,t.UNSIGNED_BYTE,this.video);let i=(0,m.sZ)(t);t.texImage2D(t.TEXTURE_2D,0,t.RGBA,t.RGBA,t.UNSIGNED_BYTE,this.resizeCanvas);let o=this.blur(i,e,!0);t.useProgram(this.bgProgram),t.viewport(0,0,this.width,this.height),t.clearColor(0,0,1,1),t.clear(t.COLOR_BUFFER_BIT),(0,m.f6)(t,this.attributes);let a=(0,m.TD)(t,this.width,this.height),s=(0,m.TD)(t,this.width,this.height),n=t.createFramebuffer();for(let i=0;i<8;i++){let l=i%2?a:s,u=i%2?s:a,f=i%2?(8-i)/this.width:0,m=i%2?0:(8-i)/this.height;t.uniform2f(t.getUniformLocation(this.bgProgram,"u_direction"),f,m),t.activeTexture(t.TEXTURE0),t.bindTexture(t.TEXTURE_2D,r),t.uniform1i(t.getUniformLocation(this.bgProgram,"u_video"),0),t.activeTexture(t.TEXTURE1),t.bindTexture(t.TEXTURE_2D,o),t.uniform1i(t.getUniformLocation(this.bgProgram,"u_bg"),1),t.activeTexture(t.TEXTURE2),t.bindTexture(t.TEXTURE_2D,e),t.uniform1i(t.getUniformLocation(this.bgProgram,"u_mask"),2),t.activeTexture(t.TEXTURE3),t.bindTexture(t.TEXTURE_2D,0===i?e:l),t.uniform1i(t.getUniformLocation(this.bgProgram,"u_in"),3);let c=7===i?null:n;t.uniform1i(t.getUniformLocation(this.bgProgram,"u_out"),+!c),t.bindFramebuffer(t.FRAMEBUFFER,c),c&&t.framebufferTexture2D(t.FRAMEBUFFER,t.COLOR_ATTACHMENT0,t.TEXTURE_2D,u,0),t.drawArrays(t.TRIANGLES,0,6)}}};EffectRenderer.displayName="EffectRenderer"},0x633177a3:(e,t,r)=>{"use strict";function compileShader(e,t,r){let i=e.createShader(r);if(!i)throw Error("GL: Failed to create shader");if(e.shaderSource(i,t),e.compileShader(i),!e.getShaderParameter(i,e.COMPILE_STATUS))throw Error(`GL: Failed to compile shader
${e.getShaderInfoLog(i)}`);return i}function createProgram(e,t,r){let i=e.createProgram();if(!i)throw Error("GL: Failed to create WebGL program");let o=compileShader(e,t,e.VERTEX_SHADER),a=compileShader(e,r,e.FRAGMENT_SHADER);if(e.attachShader(i,o),e.attachShader(i,a),e.linkProgram(i),!e.getProgramParameter(i,e.LINK_STATUS))throw Error(`GL: Failed to link program
${e.getProgramInfoLog(i)}`);return i}function createTexture(e,t=e.NEAREST){let r=e.createTexture();if(!r)throw Error("GL: Failed to create texture");return e.bindTexture(e.TEXTURE_2D,r),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,t),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,t),r}function createEmptyTexture(e,t,r,i=e.NEAREST){let o=createTexture(e,i);return e.texImage2D(e.TEXTURE_2D,0,e.RGBA,t,r,0,e.RGBA,e.UNSIGNED_BYTE,null),o}function createFramebuffer(e){let t=e.createFramebuffer();if(!t)throw Error("GL: Failed to create framebuffer");return t}function bindVertexAttribBuffers(e,t){t.forEach(t=>{e.enableVertexAttribArray(t.location),e.bindBuffer(e.ARRAY_BUFFER,t.buffer),e.vertexAttribPointer(t.location,2,e.FLOAT,!1,0,0)})}r.d(t,{TD:()=>createEmptyTexture,f6:()=>bindVertexAttribBuffers,oN:()=>createFramebuffer,rC:()=>createProgram,sZ:()=>createTexture})},0xe4c0faec:(e,t,r)=>{"use strict";e.exports=r.p+"model32-2a8ae1f.tfjson"},0x49cd54a7:(e,t,r)=>{"use strict";e.exports=r.p+"weights32-0a2efa5.tfbin"},0x866fcb20:e=>{"use strict";e.exports=`precision mediump float;

uniform sampler2D u_video;
uniform sampler2D u_bg;
uniform sampler2D u_mask;
uniform sampler2D u_in;

uniform vec2 u_direction;
uniform bool u_out;

varying vec2 v_texCoord;

float weight(in float x) {
	return -(1.0 / pow(1.0-0.48, 2.0)) * pow(x-0.48, 2.0) + 1.0;
}

// http://rastergrid.com/blog/2010/09/efficient-gaussian-blur-with-linear-sampling/
vec4 blur() {
	vec4 color = vec4(0.0);
	vec2 u = u_direction * weight(texture2D(u_mask, v_texCoord).a);
	vec2 off1 = vec2(1.411764705882353) * u;
	vec2 off2 = vec2(3.2941176470588234) * u;
	vec2 off3 = vec2(5.176470588235294) * u;
	color += texture2D(u_in, v_texCoord) * 0.1964825501511404;
	color += texture2D(u_in, v_texCoord + off1) * 0.2969069646728344;
	color += texture2D(u_in, v_texCoord - off1) * 0.2969069646728344;
	color += texture2D(u_in, v_texCoord + off2) * 0.09447039785044732;
	color += texture2D(u_in, v_texCoord - off2) * 0.09447039785044732;
	color += texture2D(u_in, v_texCoord + off3) * 0.010381362401148057;
	color += texture2D(u_in, v_texCoord - off3) * 0.010381362401148057;
	return color;
}

void main() {
	vec4 blurred = blur();
	if (u_out) {
		float va = 1.0 - texture2D(u_mask, v_texCoord).a;
		float ba = 1.0 - va;
		float wa = max(blurred.a - ba, 0.0);

		vec4 mixed = vec4(texture2D(u_video, v_texCoord).rgb, 1.0) * va + vec4(texture2D(u_bg, v_texCoord).rgb, 1.0) * ba;
		vec4 wrap = vec4(texture2D(u_bg, v_texCoord).rgb * wa, 1.0);

		gl_FragColor = vec4(1.0) - (vec4(1.0) - mixed) * (vec4(1.0) - wrap);
	} else {
		gl_FragColor = blurred;
	}
}
`},0x12bb1ab53:e=>{"use strict";e.exports=`// Bilateral filter. Based on https://www.shadertoy.com/view/4dfGDH#

precision mediump float;

// Blur parameters (see https://en.wikipedia.org/wiki/Bilateral_filter#Parameters)
// Gaussian (spatial) parameter: amount of blur
#define SIGMA 4.0
// Bilateral (range) paramter: amount of edge retention
#define BSIGMA 1.0

#define MSIZE 15

uniform sampler2D u_mask;
uniform vec2 u_unit;
uniform bool u_flip;
uniform bool u_invert;
uniform bool u_ramp;

varying vec2 v_texCoord;

float normpdf(in float x, in float sigma) {
	return 0.39894*exp(-0.5*x*x/(sigma*sigma))/sigma;
}

float ramp(in float a, in float lower, in float upper) {
	return max(0.0, min(1.0, (a - lower) / (upper - lower)));
}

float sample(vec2 coord) {
	float a = texture2D(u_mask, coord).a;
	if (u_ramp) return ramp(a, 0.2, 0.6);
	else return a;
}

void main() {
	vec2 vt = v_texCoord;
	if (u_flip) vt = vec2(vt.x, 1.0 - vt.y);

	// Color of current pixel
	float c = sample(vt);

	// Initialize kernel
	const int kSize = (MSIZE - 1) / 2;
	float kernel[MSIZE];
	float bfinal_colour = 0.0;

	// Normalization sum
	float bZ = 0.0;

	// Create the 1-D kernel
	for (int j = 0; j <= kSize; ++j) {
		kernel[kSize+j] = kernel[kSize-j] = normpdf(float(j), SIGMA);
	}

	float cc;
	float gfactor;
	float bfactor;
	float bZnorm = 1.0 / normpdf(0.0, BSIGMA);
	// Iterate over neighbouring pixels
	for (int i = -kSize; i <= kSize; ++i)
	{
		for (int j = -kSize; j <= kSize; ++j)
		{
			// Color of neighbouring pixel
			vec2 coord = vt + vec2(float(i), float(j)) * u_unit;
			cc = sample(coord);

			// Compute Gaussian and bilateral weights
			gfactor = kernel[kSize+j] * kernel[kSize+i];
			bfactor = normpdf(cc-c, BSIGMA) * bZnorm * gfactor;
			bZ += bfactor;

			bfinal_colour += bfactor * cc;
		}
	}

	float normalized = bfinal_colour / bZ;
	float inverted = u_invert ? 1.0 - normalized : normalized;
	gl_FragColor = vec4(1.0, 0.0, 0.0, inverted);
}
`},0x2310d95fe:e=>{"use strict";e.exports=`precision mediump float;

uniform sampler2D u_video;
uniform sampler2D u_mask;

uniform vec2 u_direction;
uniform bool u_invert;

varying vec2 v_texCoord;

float sample(vec2 coord) {
	if (u_invert) return 1.0 - texture2D(u_mask, coord).a;
	return texture2D(u_mask, coord).a;
}

// http://rastergrid.com/blog/2010/09/efficient-gaussian-blur-with-linear-sampling/
// Weighted Gaussian blur with mask avoidance
vec4 blur() {
	vec4 color = vec4(0.0);
	vec2 u = u_direction * sample(v_texCoord);
	vec2 off1 = vec2(1.411764705882353) * u;
	vec2 off2 = vec2(3.2941176470588234) * u;
	vec2 off3 = vec2(5.176470588235294) * u;
	color += texture2D(u_video, v_texCoord) * 0.1964825501511404;
	color += texture2D(u_video, v_texCoord + off1) * texture2D(u_mask, v_texCoord + off1).a * 0.2969069646728344;
	color += texture2D(u_video, v_texCoord - off1) * texture2D(u_mask, v_texCoord - off1).a * 0.2969069646728344;
	color += texture2D(u_video, v_texCoord + off2) * texture2D(u_mask, v_texCoord + off2).a * 0.09447039785044732;
	color += texture2D(u_video, v_texCoord - off2) * texture2D(u_mask, v_texCoord - off2).a * 0.09447039785044732;
	color += texture2D(u_video, v_texCoord + off3) * texture2D(u_mask, v_texCoord + off3).a * 0.010381362401148057;
	color += texture2D(u_video, v_texCoord - off3) * texture2D(u_mask, v_texCoord - off3).a * 0.010381362401148057;
	return color / color.a;
}

void main() {
	vec4 blurred = blur();
	gl_FragColor = blurred;
}
`},0x1cab58f69:e=>{"use strict";e.exports=`// Draws a texture

precision mediump float;

uniform sampler2D u_in;

varying vec2 v_texCoord;

void main() {
	gl_FragColor = texture2D(u_in, v_texCoord);
}
`},0x170f28e85:e=>{"use strict";e.exports=`precision mediump float;

attribute vec2 a_position;
attribute vec2 a_texCoord;

varying vec2 v_texCoord;

void main() {
	gl_Position = vec4(a_position, 0.0, 1.0);
	v_texCoord = a_texCoord;
}
`},0x195a704a0:()=>{},0xc555ac2b:()=>{},0xca07503f:()=>{},0x63afd605:()=>{},0x5395223a:()=>{},0x2919665f:()=>{}}]);
//# sourceMappingURL=https://slack.com/source-maps/bv1-13/gantry-v2-async-effect-renderer.611cd2386a0c74a0cea7.min.js.map